import { Request } from "express";
import admin from "firebase-admin";
import { storage } from "../storage";
import { User, UserType } from "@shared/schema";

// Function to initialize Firebase Admin if it hasn't been already
export function initializeFirebaseAdmin() {
  if (!admin.apps.length) {
    try {
      // First try to use the service account JSON
      if (process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
        console.log("Initializing Firebase Admin with service account JSON");
        const serviceAccount = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON);
        admin.initializeApp({
          credential: admin.credential.cert(serviceAccount),
        });
      } 
      // Fallback to individual credential variables
      else if (process.env.FIREBASE_PRIVATE_KEY && process.env.FIREBASE_CLIENT_EMAIL) {
        console.log("Initializing Firebase Admin with individual credential variables");
        admin.initializeApp({
          credential: admin.credential.cert({
            projectId: process.env.VITE_FIREBASE_PROJECT_ID,
            clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
            privateKey: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
          }),
        });
      }
      // No valid credentials found
      else {
        throw new Error("No Firebase Admin credentials available");
      }
      
      console.log("Firebase Admin initialized successfully");
    } catch (error) {
      console.error("Firebase Admin initialization error:", error);
      // In development mode, continue without Firebase Admin
      if (process.env.NODE_ENV !== "production") {
        console.log("Continuing in development mode without Firebase Admin");
      }
    }
  }
  return admin;
}

// Extract token from Authorization header
export function extractTokenFromHeader(req: Request): string | null {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  return authHeader.split('Bearer ')[1];
}

// Verify Firebase token and return Firebase UID
export async function verifyFirebaseToken(token: string): Promise<string | null> {
  try {
    // Initialize Firebase Admin if needed
    const adminApp = initializeFirebaseAdmin();
    
    // Skip token verification in development if Firebase Admin is not properly configured
    if (process.env.NODE_ENV !== "production" && 
        !process.env.FIREBASE_SERVICE_ACCOUNT_JSON && 
        (!process.env.FIREBASE_CLIENT_EMAIL || !process.env.FIREBASE_PRIVATE_KEY)) {
      console.log("Skipping token verification in development mode");
      // For development, use a mock verification that extracts the UID from the token
      // This is not secure and should ONLY be used in development
      try {
        // Base64 decode the payload part of the JWT
        const tokenParts = token.split('.');
        if (tokenParts.length !== 3) {
          console.error("Invalid token format");
          return null;
        }
        
        // Pad the base64 string properly for decoding
        const base64Payload = tokenParts[1].replace(/-/g, '+').replace(/_/g, '/');
        const paddedBase64Payload = base64Payload.padEnd(
          base64Payload.length + (4 - (base64Payload.length % 4)) % 4, 
          '='
        );
        
        const decoded = JSON.parse(Buffer.from(paddedBase64Payload, 'base64').toString());
        console.log("Development mode mock verification:", decoded);
        return decoded.user_id || decoded.sub;
      } catch (e) {
        console.error("Failed to parse development token:", e);
        return null;
      }
    }
    
    // Verify the token with Firebase Admin
    const decodedToken = await adminApp.auth().verifyIdToken(token);
    const uid = decodedToken.uid;
    return uid;
  } catch (error) {
    console.error("Error verifying Firebase token:", error);
    return null;
  }
}

// Get user from Firebase token
export async function getUserFromToken(token: string): Promise<User | null> {
  if (!token) return null;
  
  try {
    // Handle test user login for test-firebase-uid-* tokens in development mode
    if (process.env.NODE_ENV !== "production" && token.startsWith('test-firebase-uid-')) {
      console.log("Test user login requested with token:", token);
      
      // For test users, the token itself is the firebaseUid
      const firebaseUid = token;
      
      // Check if test user exists in the database
      let user = await storage.getUserByFirebaseUid(firebaseUid);
      
      // If the test user doesn't exist yet, create it
      if (!user) {
        console.log("Creating test user with UID:", firebaseUid);
        let userType: UserType;
        let name: string;
        
        if (firebaseUid === 'test-firebase-uid-petowner') {
          userType = UserType.PET_OWNER;
          name = "Test Pet Owner";
        } else if (firebaseUid === 'test-firebase-uid-provider') {
          userType = UserType.SERVICE_PROVIDER;
          name = "Test Service Provider";
        } else if (firebaseUid === 'test-firebase-uid-shelter') {
          userType = UserType.SHELTER;
          name = "Test Shelter";
        } else {
          userType = UserType.PET_OWNER;
          name = "Custom Test User";
        }
        
        // Create the user with Firebase UID
        user = await storage.createUser({
          name,
          email: `${firebaseUid}@example.com`,
          username: firebaseUid,
          firebaseUid,
          password: "test-password", // Placeholder password
          userType,
          isActive: true
        });
        
        // Create the specific profile based on user type
        if (userType === UserType.PET_OWNER) {
          await storage.createPetOwner({ userId: user.id });
        } else if (userType === UserType.SERVICE_PROVIDER) {
          await storage.createServiceProvider({ 
            userId: user.id,
            businessName: "Test Service",
            category: "Pet Grooming"
          });
        } else if (userType === UserType.SHELTER) {
          await storage.createShelter({ 
            userId: user.id,
            organizationName: "Test Shelter"
          });
        }
        
        console.log("Created new test user:", user);
      }
      
      return user;
    }
    
    // Normal Firebase token verification flow for real tokens
    const firebaseUid = await verifyFirebaseToken(token);
    if (!firebaseUid) {
      console.error("Failed to verify Firebase token", token.substring(0, 10) + '...');
      return null;
    }
    
    // Try to find user by Firebase UID
    let user = await storage.getUserByFirebaseUid(firebaseUid);
    
    // If user is found but not active in our database
    // This can happen when a user is deleted in Firebase but not fully in our database
    // We'll reactivate them instead of returning null
    if (user && !user.isActive) {
      console.log("User is marked as inactive in our database. Reactivating:", firebaseUid);
      user = await storage.updateUser(user.id, { isActive: true });
    }
    
    // If in development mode and we're using token verification but user doesn't exist yet,
    // let's create the user in the database from token data for testing
    if (!user && process.env.NODE_ENV !== "production") {
      try {
        // Extract user info from token
        const tokenParts = token.split('.');
        if (tokenParts.length === 3) {
          const base64Payload = tokenParts[1].replace(/-/g, '+').replace(/_/g, '/');
          const paddedBase64Payload = base64Payload.padEnd(
            base64Payload.length + (4 - (base64Payload.length % 4)) % 4, 
            '='
          );
          
          const decoded = JSON.parse(Buffer.from(paddedBase64Payload, 'base64').toString());
          
          if (decoded.email) {
            console.log("Creating user from token for development:", decoded.email);
            
            // Try to extract user type from the token if available
            let userType = UserType.PET_OWNER; // Default to pet owner
            if (decoded.claims && decoded.claims.userType) {
              userType = decoded.claims.userType;
            }
            
            try {
              // Check if user exists by email first
              const existingUser = await storage.getUserByEmail(decoded.email);
              if (existingUser) {
                // Update the existing user with Firebase UID if needed
                if (!existingUser.firebaseUid || existingUser.firebaseUid !== firebaseUid) {
                  user = await storage.updateUser(existingUser.id, {
                    firebaseUid,
                    isActive: true
                  });
                } else {
                  user = existingUser;
                }
              } else {
                // Create new user with Firebase UID
                user = await storage.createUser({
                  name: decoded.name || decoded.email.split('@')[0], // Use name from token or the part before @ as name
                  email: decoded.email,
                  username: decoded.email.split('@')[0] + '-' + Date.now().toString().slice(-4), // Make username unique
                  firebaseUid,
                  password: "firebase-auth", // Placeholder password
                  userType,
                  isActive: true
                });
              }
            } catch (err) {
              console.error("Failed to create/update user:", err);
              throw err;
            }
            
            // Create the appropriate profile based on user type
            if (user && userType === UserType.PET_OWNER) {
              await storage.createPetOwner({ userId: user.id });
            } else if (user && userType === UserType.SERVICE_PROVIDER) {
              await storage.createServiceProvider({ 
                userId: user.id,
                businessName: decoded.name || "New Service Provider",
                category: "other"
              });
            } else if (user && userType === UserType.SHELTER) {
              await storage.createShelter({ 
                userId: user.id,
                organizationName: decoded.name || "New Shelter"
              });
            }
            
            console.log("Created new user from token:", user);
          }
        }
      } catch (createError) {
        console.error("Error creating user from token:", createError);
      }
    }
    
    // If user is still not found, then they might exist in Firebase but not in our database
    // This is a rare case but can happen if the user was deleted from our database but not from Firebase
    if (!user) {
      console.log("User exists in Firebase but not in our database:", firebaseUid);
      return null;
    }
    
    return user;
  } catch (error) {
    console.error("Error getting user from token:", error);
    return null;
  }
}

// Middleware to add authentication to routes
export async function requireAuth(req: Request): Promise<User | null> {
  const token = extractTokenFromHeader(req);
  if (!token) return null;
  
  return await getUserFromToken(token);
}