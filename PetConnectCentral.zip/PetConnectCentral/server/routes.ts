import type { Express, Request, Response, NextFunction } from "express";
import express from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { 
  UserType, 
  PetHealthMetric, 
  NotificationPreference, 
  Pet,
  PetWeightHistory,
  ReminderNotification,
  InsertPetWeightHistory,
  InsertPetHealthMetric,
  InsertNotificationPreference,
  InsertReminderNotification,
  InsertProviderSetting,
  InsertServiceBooking,
  InsertServiceReview,
  ProviderSetting,
  ServiceBooking,
  ServiceReview,
  Service,
  InsertService,
  users
} from "@shared/schema";
import { getUserFromToken, extractTokenFromHeader, initializeFirebaseAdmin } from "./utils/token-handler";
import { upload, handleMulterErrors, getFileUrl } from "./utils/upload-handler";
import path from "path";
import { db } from "./db";
import { eq } from "drizzle-orm";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);
  
  // Serve static files from the public directory
  app.use('/uploads', express.static(path.join(process.cwd(), 'public', 'uploads')));
  
  // File upload endpoint with authentication
  app.post('/api/upload', async (req: Request, res: Response, next: NextFunction) => {
    try {
      // Extract the token using the utility function
      const token = extractTokenFromHeader(req);
      
      if (!token) {
        console.log('No authentication token provided for upload');
        // Continue anyway in development for testing, but log the warning
        if (process.env.NODE_ENV === 'production') {
          return res.status(401).json({ error: 'Authentication required' });
        }
      } else {
        // Verify the user from token
        const user = await getUserFromToken(token);
        
        if (!user && process.env.NODE_ENV === 'production') {
          return res.status(401).json({ error: 'Invalid authentication token' });
        }
        
        // Store user ID in request for potential usage
        (req as any).userId = user?.id;
      }
      
      // Continue with file upload after authentication check
      next();
    } catch (error) {
      console.error('Authentication error in upload:', error);
      return res.status(500).json({ error: 'Authentication failed' });
    }
  }, upload.single('image'), handleMulterErrors, (req: Request, res: Response) => {
    try {
      if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
      }
      
      // Return the URL to the uploaded file
      const imageUrl = getFileUrl(req.file.filename);
      res.json({ 
        imageUrl,
        userId: (req as any).userId // Include the authenticated user ID if available
      });
    } catch (error) {
      console.error('Error handling file upload:', error);
      res.status(500).json({ error: 'Failed to process uploaded file' });
    }
  });
  
  // Get user by Firebase UID
  app.get("/api/users/firebase/:firebaseUid", async (req, res) => {
    try {
      const { firebaseUid } = req.params;
      const user = await storage.getUserByFirebaseUid(firebaseUid);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      res.json(user);
    } catch (error) {
      console.error(`Error fetching user by Firebase UID ${req.params.firebaseUid}:`, error);
      res.status(500).json({ error: "Failed to fetch user" });
    }
  });
  
  // Register user with Firebase credentials
  app.post("/api/firebase-register", async (req, res) => {
    try {
      const { name, email, firebaseUid, userType } = req.body;
      
      // Check if user already exists by firebaseUid first
      let existingUser = await storage.getUserByFirebaseUid(firebaseUid);
      if (existingUser) {
        console.log(`User with Firebase UID ${firebaseUid} already exists, returning existing user`);
        return res.json(existingUser); // Return existing user
      }
      
      // Also check if a user with the same email exists
      // This could happen if a user tries to register with an email that's already in use
      try {
        const [existingEmailUser] = await db.select().from(users).where(eq(users.email, email));
        if (existingEmailUser) {
          console.log(`User with email ${email} already exists, updating with new Firebase UID`);
          
          // Update the existing user with the new Firebase UID
          const [updatedUser] = await db
            .update(users)
            .set({ 
              firebaseUid,
              name: name || existingEmailUser.name, // Keep existing name if no new name provided
              isActive: true
            })
            .where(eq(users.id, existingEmailUser.id))
            .returning();
          
          return res.json(updatedUser);
        }
      } catch (emailCheckError) {
        console.error("Error checking for existing email:", emailCheckError);
        // Continue with normal registration flow
      }
      
      // Generate a unique username if email is already used as username
      let username = email;
      let usernameAttempt = 1;
      let isUsernameUnique = false;
      
      while (!isUsernameUnique) {
        try {
          // Check if username exists
          const [userWithUsername] = await db.select().from(users).where(eq(users.username, username));
          
          if (!userWithUsername) {
            isUsernameUnique = true;
          } else {
            // Append a number to make username unique
            username = `${email}_${usernameAttempt}`;
            usernameAttempt++;
          }
        } catch (error) {
          console.error("Error checking username uniqueness:", error);
          // If there's an error, use a timestamp to ensure uniqueness
          username = `${email}_${Date.now()}`;
          isUsernameUnique = true;
        }
      }
      
      // Create new user with unique username
      const newUser = await storage.createUser({
        name,
        email,
        firebaseUid,
        userType,
        username, // Now using potentially modified username
        password: "firebase-auth", // Placeholder since Firebase handles auth
        isActive: true // Ensure user is active by default
      });
      
      // Create user profile based on user type
      switch (userType) {
        case UserType.PET_OWNER:
          await storage.createPetOwner({ userId: newUser.id });
          break;
        case UserType.SERVICE_PROVIDER:
          await storage.createServiceProvider({ 
            userId: newUser.id,
            businessName: name,
            category: "other"
          });
          break;
        case UserType.SHELTER:
          await storage.createShelter({
            userId: newUser.id,
            organizationName: name
          });
          break;
      }
      
      console.log(`Successfully registered Firebase user with ID: ${newUser.id}, type: ${userType}`);
      res.status(201).json(newUser);
    } catch (error) {
      console.error("Error registering Firebase user:", error);
      res.status(500).json({ error: "Failed to register user" });
    }
  });
  
  // Handle Firebase user deletion synchronization
  app.post("/api/firebase-user-deleted", async (req, res) => {
    try {
      const { firebaseUid } = req.body;
      
      if (!firebaseUid) {
        return res.status(400).json({ error: "Firebase UID is required" });
      }
      
      // Check if user exists in our database
      const user = await storage.getUserByFirebaseUid(firebaseUid);
      
      if (!user) {
        return res.status(404).json({ error: "User not found in database" });
      }
      
      console.log(`Firebase user with UID ${firebaseUid} was deleted, removing from database...`);
      
      // Delete user from database using the existing endpoint logic
      // This handles all the cascading deletes for related entities
      if (user.userType === UserType.PET_OWNER) {
        // Get pet owner
        const petOwner = await storage.getPetOwner(user.id);
        
        if (petOwner) {
          // Delete favorites
          const favorites = await storage.getFavoritesByPetOwnerId(petOwner.id);
          for (const favorite of favorites) {
            await storage.deleteFavorite(favorite.id);
          }
          
          // Delete appointments
          const appointments = await storage.getAppointmentsByUserId(user.id);
          for (const appointment of appointments) {
            await storage.updateAppointmentStatus(appointment.id, "cancelled");
          }
          
          // Delete pets 
          const pets = await storage.getPetsByOwnerId(user.id);
          for (const pet of pets) {
            await storage.deletePet(pet.id);
          }
        }
      } else if (user.userType === UserType.SERVICE_PROVIDER) {
        // Get service provider
        const serviceProvider = await storage.getServiceProvider(user.id);
        
        if (serviceProvider) {
          // Update appointments
          const appointments = await storage.getAppointmentsByProviderId(serviceProvider.id);
          for (const appointment of appointments) {
            await storage.updateAppointmentStatus(appointment.id, "cancelled");
          }
          
          // Delete services
          const services = await storage.getServicesByProviderId(serviceProvider.id);
          for (const service of services) {
            await storage.deleteService(service.id);
          }
        }
      } else if (user.userType === UserType.SHELTER) {
        // Get shelter
        const shelter = await storage.getShelter(user.id);
        
        if (shelter) {
          // Update appointments
          const appointments = await storage.getAppointmentsByShelterId(shelter.id);
          for (const appointment of appointments) {
            await storage.updateAppointmentStatus(appointment.id, "cancelled");
          }
          
          // Delete pets
          const pets = await storage.getPetsByShelterId(shelter.id);
          for (const pet of pets) {
            await storage.deletePet(pet.id);
          }
        }
      }
      
      // Mark user as inactive in our database
      await storage.updateUser(user.id, { 
        isActive: false
        // isDeleted: true  // Commented out until schema migration
      });
      
      console.log(`User ${user.id} with Firebase UID ${firebaseUid} marked as deleted in database`);
      res.status(200).json({ message: "User deleted successfully" });
      
    } catch (error) {
      console.error("Error processing Firebase user deletion:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });
  
  // Test login route for development
  app.post('/api/test-login', async (req, res) => {
    // Only available in development
    if (process.env.NODE_ENV === 'production') {
      return res.status(404).json({ error: 'Not found' });
    }
    
    try {
      const { testUid } = req.body;
      
      if (!testUid) {
        return res.status(400).json({ error: 'Test UID is required' });
      }
      
      // Set the token in a request header so it can be processed by the existing token handler
      req.headers.authorization = `Bearer ${testUid}`;
      
      // Use the token handler to get or create the user
      const user = await getUserFromToken(testUid);
      
      if (!user) {
        return res.status(401).json({ error: 'Authentication failed' });
      }
      
      // Get additional profile data based on user type
      let profileData = {};
      
      if (user.userType === UserType.PET_OWNER) {
        const petOwner = await storage.getPetOwner(user.id);
        if (petOwner) {
          profileData = { petOwner };
        }
      } else if (user.userType === UserType.SERVICE_PROVIDER) {
        const serviceProvider = await storage.getServiceProvider(user.id);
        if (serviceProvider) {
          profileData = { serviceProvider };
        }
      } else if (user.userType === UserType.SHELTER) {
        const shelter = await storage.getShelter(user.id);
        if (shelter) {
          profileData = { shelter };
        }
      }
      
      // Return the user with profile data
      res.status(200).json({
        ...user,
        ...profileData
      });
      
    } catch (error) {
      console.error('Error in test-login:', error);
      res.status(500).json({ error: 'Failed to login with test UID' });
    }
  });
  
  // Get current user profile
  app.get("/api/user/profile", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      console.log("Firebase token received:", token);
      
      // Use the token handler to extract and validate the user
      const user = await getUserFromToken(token);
      
      if (!user) {
        console.log("No user found for token");
        return res.status(404).json({ error: "User not found" });
      }
      
      // Get user profile data based on user type
      let profileData: any = { ...user };
      
      switch (user.userType) {
        case UserType.PET_OWNER:
          const petOwner = await storage.getPetOwner(user.id);
          if (petOwner) profileData = { ...profileData, ...petOwner };
          break;
          
        case UserType.SERVICE_PROVIDER:
          const serviceProvider = await storage.getServiceProvider(user.id);
          if (serviceProvider) profileData = { ...profileData, ...serviceProvider };
          break;
          
        case UserType.SHELTER:
          const shelter = await storage.getShelter(user.id);
          if (shelter) profileData = { ...profileData, ...shelter };
          break;
      }
      
      res.json(profileData);
    } catch (error) {
      console.error("Error fetching user profile:", error);
      res.status(500).json({ error: "Failed to fetch profile" });
    }
  });
  
  // Update user role/type
  app.put("/api/user/role", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      console.log("Firebase token received for role update:", token);
      
      // Use the token handler to extract and validate the user
      const user = await getUserFromToken(token);
      
      if (!user) {
        console.log("No user found for role update");
        return res.status(404).json({ error: "User not found" });
      }
      
      const { userType } = req.body;
      if (!userType || !Object.values(UserType).includes(userType)) {
        return res.status(400).json({ error: "Invalid user type" });
      }
      
      // Update user type
      const updatedUser = await storage.updateUserType(user.id, userType);
      
      res.json(updatedUser);
    } catch (error) {
      console.error("Error updating user role:", error);
      res.status(500).json({ error: "Failed to update user role" });
    }
  });

  // Get all service providers
  app.get("/api/service-providers", async (req, res) => {
    try {
      const providers = await storage.getAllServiceProviders();
      
      // Get the corresponding user data for each provider
      const providersWithDetails = await Promise.all(
        providers.map(async (provider) => {
          const user = await storage.getUser(provider.userId);
          return {
            ...provider,
            name: user?.name,
            email: user?.email,
            location: user?.location,
          };
        })
      );
      
      res.json(providersWithDetails);
    } catch (error) {
      console.error("Error fetching service providers:", error);
      res.status(500).json({ error: "Failed to fetch service providers" });
    }
  });

  // Get service providers by category
  app.get("/api/service-providers/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const providers = await storage.getServiceProvidersByCategory(category);
      
      // Get the corresponding user data for each provider
      const providersWithDetails = await Promise.all(
        providers.map(async (provider) => {
          const user = await storage.getUser(provider.userId);
          return {
            ...provider,
            name: user?.name,
            email: user?.email,
            location: user?.location,
          };
        })
      );
      
      res.json(providersWithDetails);
    } catch (error) {
      console.error(`Error fetching service providers in category ${req.params.category}:`, error);
      res.status(500).json({ error: "Failed to fetch service providers by category" });
    }
  });

  // Get services by provider ID
  app.get("/api/services/provider/:providerId", async (req, res) => {
    try {
      const providerId = parseInt(req.params.providerId);
      const services = await storage.getServicesByProviderId(providerId);
      res.json(services);
    } catch (error) {
      console.error(`Error fetching services for provider ${req.params.providerId}:`, error);
      res.status(500).json({ error: "Failed to fetch services" });
    }
  });

  // Get services by category
  app.get("/api/services/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const services = await storage.getServicesByCategory(category);
      res.json(services);
    } catch (error) {
      console.error(`Error fetching services in category ${req.params.category}:`, error);
      res.status(500).json({ error: "Failed to fetch services by category" });
    }
  });

  // Get all services
  app.get("/api/services", async (req, res) => {
    try {
      const services = await storage.getAllServices();
      res.json(services);
    } catch (error) {
      console.error("Error fetching all services:", error);
      res.status(500).json({ error: "Failed to fetch services" });
    }
  });

  // Get all shelters
  app.get("/api/shelters", async (req, res) => {
    try {
      const shelters = await storage.getAllShelters();
      
      // Get the corresponding user data for each shelter
      const sheltersWithDetails = await Promise.all(
        shelters.map(async (shelter) => {
          const user = await storage.getUser(shelter.userId);
          return {
            ...shelter,
            name: user?.name,
            email: user?.email,
            location: user?.location,
          };
        })
      );
      
      res.json(sheltersWithDetails);
    } catch (error) {
      console.error("Error fetching shelters:", error);
      res.status(500).json({ error: "Failed to fetch shelters" });
    }
  });

  // Get all pets
  app.get("/api/pets", async (req, res) => {
    try {
      const pets = await storage.getAllPets();
      
      // Get the corresponding shelter data for each pet with a shelterId
      const petsWithShelterDetails = await Promise.all(
        pets.map(async (pet) => {
          if (pet.shelterId) {
            const shelter = await storage.getShelter(pet.shelterId);
            return {
              ...pet,
              shelterName: shelter?.organizationName,
            };
          }
          return pet;
        })
      );
      
      res.json(petsWithShelterDetails);
    } catch (error) {
      console.error("Error fetching pets:", error);
      res.status(500).json({ error: "Failed to fetch pets" });
    }
  });

  // Get pets by shelter ID
  app.get("/api/pets/shelter/:shelterId", async (req, res) => {
    try {
      const shelterId = parseInt(req.params.shelterId);
      const pets = await storage.getPetsByShelterId(shelterId);
      res.json(pets);
    } catch (error) {
      console.error(`Error fetching pets for shelter ${req.params.shelterId}:`, error);
      res.status(500).json({ error: "Failed to fetch pets by shelter" });
    }
  });
  
  // Get featured pets
  app.get("/api/pets/featured", async (req, res) => {
    try {
      const featuredPets = await storage.getFeaturedPets();
      
      // Get the corresponding shelter data for each pet
      const petsWithShelterDetails = await Promise.all(
        featuredPets.map(async (pet) => {
          if (pet.shelterId) {
            const shelter = await storage.getShelter(pet.shelterId);
            return {
              ...pet,
              shelterName: shelter?.organizationName,
            };
          }
          return pet;
        })
      );
      
      res.json(petsWithShelterDetails);
    } catch (error) {
      console.error("Error fetching featured pets:", error);
      res.status(500).json({ error: "Failed to fetch featured pets" });
    }
  });
  
  // Get recommended pets - currently returns featured pets as a placeholder
  app.get("/api/pets/recommended", async (req, res) => {
    try {
      // In a real implementation, this would use user preferences and algorithm
      // For now, just return a subset of featured pets as recommendations
      const featuredPets = await storage.getFeaturedPets();
      const recommendedPets = featuredPets.slice(0, 3); // Take up to 3 pets
      
      res.json(recommendedPets);
    } catch (error) {
      console.error("Error fetching recommended pets:", error);
      res.status(500).json({ error: "Failed to fetch recommended pets" });
    }
  });
  
  // Search pets with filters
  app.get("/api/pets/search", async (req, res) => {
    try {
      const { type, breed, age, size } = req.query;
      
      const filters: any = {};
      if (type) filters.type = type as string;
      if (breed) filters.breed = breed as string;
      if (age) filters.age = parseInt(age as string);
      if (size) filters.size = size as string;
      
      const pets = await storage.searchPets(filters);
      
      // Get the corresponding shelter data for each pet
      const petsWithShelterDetails = await Promise.all(
        pets.map(async (pet) => {
          if (pet.shelterId) {
            const shelter = await storage.getShelter(pet.shelterId);
            return {
              ...pet,
              shelterName: shelter?.organizationName,
            };
          }
          return pet;
        })
      );
      
      res.json(petsWithShelterDetails);
    } catch (error) {
      console.error("Error searching pets:", error);
      res.status(500).json({ error: "Failed to search pets" });
    }
  });
  
  // Get a single pet by ID
  app.get("/api/pets/:id", async (req, res) => {
    try {
      const petId = parseInt(req.params.id);
      const pet = await storage.getPet(petId);
      
      if (!pet) {
        return res.status(404).json({ error: "Pet not found" });
      }
      
      // Get shelter details if applicable
      let petWithDetails = { ...pet };
      
      if (pet.shelterId) {
        const shelter = await storage.getShelter(pet.shelterId);
        if (shelter) {
          const user = await storage.getUser(shelter.userId);
          // Create a new object with additional shelter details
          // TypeScript doesn't allow extra properties, so we use type assertion
          petWithDetails = {
            ...petWithDetails,
            // Using as any to avoid TypeScript errors
            shelterContact: user?.email,
          } as any;
          // Add shelter name separately to avoid TypeScript errors
          (petWithDetails as any).shelterName = shelter.organizationName;
          (petWithDetails as any).shelterLocation = user?.location;
        }
      }
      
      res.json(petWithDetails);
    } catch (error) {
      console.error(`Error fetching pet with ID ${req.params.id}:`, error);
      res.status(500).json({ error: "Failed to fetch pet details" });
    }
  });
  
  // Create a new pet
  app.post("/api/pets", async (req, res) => {
    try {
      console.log("Received pet creation request with body:", JSON.stringify(req.body));
      
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        console.log("Authorization header missing or invalid");
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      console.log("Using token:", token);
      const user = await getUserFromToken(token);
      
      if (!user) {
        console.log("User not found for token:", token);
        return res.status(404).json({ error: "User not found" });
      }
      
      console.log("Found user:", JSON.stringify(user));

      // For development: allow all user types to add pets
      if (process.env.NODE_ENV !== 'production') {
        console.log("Development mode: allowing all user types to add pets");
        
        // Create the pet based on user type
        let petData = { ...req.body };
        
        if (user.userType === UserType.SHELTER) {
          // Get the shelter ID from the user
          const shelter = await storage.getShelter(user.id);
          if (shelter) {
            petData.shelterId = shelter.id;
            petData.ownerId = null; // Shelter pets don't have owners initially
          }
        } else if (user.userType === UserType.PET_OWNER) {
          // For pet owners, set the owner ID but clear shelter ID
          const petOwner = await storage.getPetOwner(user.id);
          if (petOwner) {
            petData.ownerId = petOwner.id;
            petData.shelterId = null; // Not a shelter pet
          }
        } else if (user.userType === UserType.SERVICE_PROVIDER) {
          // Service providers can add pets as if they're pet owners
          petData.ownerId = user.id;
          petData.shelterId = null; // Not a shelter pet
        }
        
        console.log("Creating pet with data:", JSON.stringify(petData));
        
        const newPet = await storage.createPet(petData);
        console.log("Pet created successfully:", JSON.stringify(newPet));
        
        res.status(201).json(newPet);
        return;
      }
      
      // In production: shelters and pet owners can create pets
      if (user.userType !== UserType.SHELTER && user.userType !== UserType.PET_OWNER) {
        console.log("User is not a shelter or pet owner, user type:", user.userType);
        return res.status(403).json({ error: "Only shelters and pet owners can create pets" });
      }
      
      // Handle both shelters and pet owners
      let petData = { ...req.body };
      
      if (user.userType === UserType.SHELTER) {
        // Get the shelter ID
        const shelter = await storage.getShelter(user.id);
        if (!shelter) {
          console.log("Shelter profile not found for user ID:", user.id);
          return res.status(404).json({ error: "Shelter profile not found" });
        }
        
        console.log("Found shelter:", JSON.stringify(shelter));
        
        // Create the pet with the shelter ID
        petData = {
          ...petData,
          shelterId: shelter.id,
          ownerId: null // Shelter pets don't have owners initially
        };
      } else if (user.userType === UserType.PET_OWNER) {
        // Get the pet owner ID
        const petOwner = await storage.getPetOwner(user.id);
        if (!petOwner) {
          console.log("Pet owner profile not found for user ID:", user.id);
          return res.status(404).json({ error: "Pet owner profile not found" });
        }
        
        console.log("Found pet owner:", JSON.stringify(petOwner));
        
        // Create the pet with the owner ID
        petData = {
          ...petData,
          ownerId: petOwner.id,
          shelterId: null // Not a shelter pet
        };
      }
      
      console.log("Creating pet with data:", JSON.stringify(petData));
      
      const newPet = await storage.createPet(petData);
      console.log("Pet created successfully:", JSON.stringify(newPet));
      
      res.status(201).json(newPet);
    } catch (error) {
      console.error("Error creating pet:", error);
      res.status(500).json({ error: "Failed to create pet" });
    }
  });
  
  // Update an existing pet - GDPR compliant edit functionality
  app.put("/api/pets/:id", async (req, res) => {
    try {
      const petId = parseInt(req.params.id);
      console.log(`Received pet update request for ID ${petId} with body:`, JSON.stringify(req.body));
      
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        console.log("Authorization header missing or invalid");
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      
      if (!user) {
        console.log("User not found for token");
        return res.status(404).json({ error: "User not found" });
      }
      
      // Get the pet to update
      const existingPet = await storage.getPet(petId);
      if (!existingPet) {
        return res.status(404).json({ error: "Pet not found" });
      }
      
      // Check if the user has permission to update this pet
      if (process.env.NODE_ENV !== 'production') {
        console.log("Development mode: checking owner permissions");
        console.log(`User ID: ${user.id}, User Type: ${user.userType}`);
        console.log(`Pet Owner ID: ${existingPet.ownerId}, Pet Shelter ID: ${existingPet.shelterId}`);
        
        // For development purposes, allow any authenticated user to update pets
        // This makes testing easier
        console.log("Development mode - allowing update for testing purposes");
      } else {
        console.log("Production mode: checking permissions");
        // In production, check if user is the pet owner or the shelter that listed the pet
        if (user.userType === UserType.PET_OWNER) {
          const petOwner = await storage.getPetOwner(user.id);
          if (!petOwner || existingPet.ownerId !== petOwner.id) {
            console.log(`Permission denied: User's pet owner ID (${petOwner?.id}) doesn't match pet's owner ID (${existingPet.ownerId})`);
            return res.status(403).json({ error: "You can only update your own pets" });
          }
        } else if (user.userType === UserType.SHELTER) {
          const shelter = await storage.getShelter(user.id);
          if (!shelter || shelter.id !== existingPet.shelterId) {
            console.log(`Permission denied: User's shelter ID (${shelter?.id}) doesn't match pet's shelter ID (${existingPet.shelterId})`);
            return res.status(403).json({ error: "Shelters can only update their own listed pets" });
          }
        } else if (user.userType === UserType.SERVICE_PROVIDER) {
          // Service providers can update pet info if they're providing services for the pet
          console.log("Allowing service provider to update pet");
        } else {
          console.log(`Permission denied: User type ${user.userType} is not allowed to update pets`);
          return res.status(403).json({ error: "Only authorized users can update pets" });
        }
      }
      
      // Update the pet (keep shelterId and ID the same)
      const petData = {
        ...req.body,
        id: petId,
        shelterId: existingPet.shelterId
      };
      
      // Perform the update using the storage function
      const updatedPet = await storage.updatePet(petId, petData);
      console.log("Pet updated successfully:", JSON.stringify(updatedPet));
      
      res.json(updatedPet);
    } catch (error) {
      console.error(`Error updating pet with ID ${req.params.id}:`, error);
      res.status(500).json({ error: "Failed to update pet" });
    }
  });
  
  // Delete a pet - GDPR compliant data removal
  app.delete("/api/pets/:id", async (req, res) => {
    try {
      const petId = parseInt(req.params.id);
      console.log(`Received pet deletion request for ID ${petId}`);
      
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        console.log("Authorization header missing or invalid");
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      
      if (!user) {
        console.log("User not found for token");
        return res.status(404).json({ error: "User not found" });
      }
      
      // Get the pet to delete
      const existingPet = await storage.getPet(petId);
      if (!existingPet) {
        return res.status(404).json({ error: "Pet not found" });
      }
      
      // Check if the user has permission to delete this pet
      if (process.env.NODE_ENV !== 'production') {
        console.log("Development mode: checking owner permissions for deletion");
        console.log(`User ID: ${user.id}, User Type: ${user.userType}`);
        console.log(`Pet Owner ID: ${existingPet.ownerId}, Pet Shelter ID: ${existingPet.shelterId}`);
        
        // For development purposes, allow any authenticated user to delete pets
        // This makes testing easier
        console.log("Development mode - allowing deletion for testing purposes");
      } else {
        console.log("Production mode: checking permissions for deletion");
        // In production, check if user is the pet owner or the shelter that listed the pet
        if (user.userType === UserType.PET_OWNER) {
          const petOwner = await storage.getPetOwner(user.id);
          if (!petOwner || existingPet.ownerId !== petOwner.id) {
            console.log(`Permission denied: User's pet owner ID (${petOwner?.id}) doesn't match pet's owner ID (${existingPet.ownerId})`);
            return res.status(403).json({ error: "You can only delete your own pets" });
          }
        } else if (user.userType === UserType.SHELTER) {
          const shelter = await storage.getShelter(user.id);
          if (!shelter || shelter.id !== existingPet.shelterId) {
            console.log(`Permission denied: User's shelter ID (${shelter?.id}) doesn't match pet's shelter ID (${existingPet.shelterId})`);
            return res.status(403).json({ error: "Shelters can only delete their own listed pets" });
          }
        } else if (user.userType === UserType.SERVICE_PROVIDER) {
          // Service providers can delete pet info if they're providing services for the pet
          console.log("Allowing service provider to delete pet");
        } else {
          console.log(`Permission denied: User type ${user.userType} is not allowed to delete pets`);
          return res.status(403).json({ error: "Only authorized users can delete pets" });
        }
      }
      
      // Perform the deletion using the storage function
      await storage.deletePet(petId);
      console.log(`Successfully deleted pet with ID ${petId}`);
      
      res.status(204).send();
    } catch (error) {
      console.error(`Error deleting pet with ID ${req.params.id}:`, error);
      res.status(500).json({ error: "Failed to delete pet" });
    }
  });

  // Pet Behavior Record routes
  
  // Get pet behavior record by ID
  app.get("/api/pet-behavior-records/:id", async (req, res) => {
    try {
      const recordId = parseInt(req.params.id);
      const record = await storage.getPetBehaviorRecord(recordId);
      
      if (!record) {
        return res.status(404).json({ error: "Pet behavior record not found" });
      }
      
      // Extract token and validate user has access to this pet's records
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      // Get the pet to check ownership
      const pet = await storage.getPet(record.petId);
      if (!pet) {
        return res.status(404).json({ error: "Associated pet not found" });
      }
      
      // Check if user has access to this pet's records
      if (user.userType === UserType.PET_OWNER && pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You don't have permission to access this record" });
      }
      
      res.json(record);
    } catch (error) {
      console.error("Error fetching pet behavior record:", error);
      res.status(500).json({ error: "Failed to fetch pet behavior record" });
    }
  });
  
  // Get behavior records for a specific pet
  app.get("/api/pets/:petId/behavior-records", async (req, res) => {
    try {
      const petId = parseInt(req.params.petId);
      const pet = await storage.getPet(petId);
      
      if (!pet) {
        return res.status(404).json({ error: "Pet not found" });
      }
      
      // Extract token and validate user has access to this pet's records
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      // Check if user has access to this pet's records
      if (user.userType === UserType.PET_OWNER && pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You don't have permission to access these records" });
      }
      
      const records = await storage.getPetBehaviorRecordsByPetId(petId);
      res.json(records);
    } catch (error) {
      console.error("Error fetching pet behavior records:", error);
      res.status(500).json({ error: "Failed to fetch pet behavior records" });
    }
  });
  
  // Create a new pet behavior record
  app.post("/api/pet-behavior-records", async (req, res) => {
    try {
      // Extract token and validate user
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const { petId, recordDate, behaviorType, description, triggerFactors, intervention, trainerName, progressStatus } = req.body;
      
      // Check if pet exists and user has access
      const pet = await storage.getPet(petId);
      if (!pet) {
        return res.status(404).json({ error: "Pet not found" });
      }
      
      // Check if user has permission to add records for this pet
      if (user.userType === UserType.PET_OWNER && pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You don't have permission to add records for this pet" });
      }
      
      // Create the record
      const newRecord = await storage.createPetBehaviorRecord({
        petId,
        recordDate,
        behaviorType,
        description,
        triggerFactors,
        intervention,
        trainerName,
        progressStatus
      });
      
      res.status(201).json(newRecord);
    } catch (error) {
      console.error("Error creating pet behavior record:", error);
      res.status(500).json({ error: "Failed to create pet behavior record" });
    }
  });
  
  // Update a pet behavior record
  app.put("/api/pet-behavior-records/:id", async (req, res) => {
    try {
      const recordId = parseInt(req.params.id);
      const record = await storage.getPetBehaviorRecord(recordId);
      
      if (!record) {
        return res.status(404).json({ error: "Pet behavior record not found" });
      }
      
      // Extract token and validate user
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      // Get the pet to check ownership
      const pet = await storage.getPet(record.petId);
      if (!pet) {
        return res.status(404).json({ error: "Associated pet not found" });
      }
      
      // Check if user has permission to update this record
      if (user.userType === UserType.PET_OWNER && pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You don't have permission to update this record" });
      }
      
      // Update the record
      const { recordDate, behaviorType, description, triggerFactors, intervention, trainerName, progressStatus } = req.body;
      
      const updatedRecord = await storage.updatePetBehaviorRecord(recordId, {
        recordDate,
        behaviorType,
        description,
        triggerFactors,
        intervention,
        trainerName,
        progressStatus
      });
      
      res.json(updatedRecord);
    } catch (error) {
      console.error("Error updating pet behavior record:", error);
      res.status(500).json({ error: "Failed to update pet behavior record" });
    }
  });
  
  // Soft delete a pet behavior record
  app.delete("/api/pet-behavior-records/:id", async (req, res) => {
    try {
      const recordId = parseInt(req.params.id);
      const record = await storage.getPetBehaviorRecord(recordId);
      
      if (!record) {
        return res.status(404).json({ error: "Pet behavior record not found" });
      }
      
      // Extract token and validate user
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      // Get the pet to check ownership
      const pet = await storage.getPet(record.petId);
      if (!pet) {
        return res.status(404).json({ error: "Associated pet not found" });
      }
      
      // Check if user has permission to delete this record
      if (user.userType === UserType.PET_OWNER && pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You don't have permission to delete this record" });
      }
      
      // Soft delete the record
      await storage.softDeletePetBehaviorRecord(recordId);
      
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting pet behavior record:", error);
      res.status(500).json({ error: "Failed to delete pet behavior record" });
    }
  });

  // Pet Document routes
  
  // Get document by ID
  app.get("/api/pet-documents/:id", async (req, res) => {
    try {
      const documentId = parseInt(req.params.id);
      const document = await storage.getPetDocument(documentId);
      
      if (!document) {
        return res.status(404).json({ error: "Pet document not found" });
      }
      
      // Extract token and validate user has access to this pet's documents
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      // Get the pet to check ownership
      const pet = await storage.getPet(document.petId);
      if (!pet) {
        return res.status(404).json({ error: "Associated pet not found" });
      }
      
      // Check if user has access to this pet's documents
      if (user.userType === UserType.PET_OWNER && pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You don't have permission to access this document" });
      }
      
      res.json(document);
    } catch (error) {
      console.error("Error fetching pet document:", error);
      res.status(500).json({ error: "Failed to fetch pet document" });
    }
  });
  
  // Get all documents for a specific pet
  app.get("/api/pets/:petId/documents", async (req, res) => {
    try {
      const petId = parseInt(req.params.petId);
      const pet = await storage.getPet(petId);
      
      if (!pet) {
        return res.status(404).json({ error: "Pet not found" });
      }
      
      // Extract token and validate user has access to this pet's documents
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      // Check if user has access to this pet's documents
      if (user.userType === UserType.PET_OWNER && pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You don't have permission to access these documents" });
      }
      
      const documents = await storage.getPetDocumentsByPetId(petId);
      res.json(documents);
    } catch (error) {
      console.error("Error fetching pet documents:", error);
      res.status(500).json({ error: "Failed to fetch pet documents" });
    }
  });
  
  // Get documents related to a specific health record
  app.get("/api/health-records/:recordId/documents", async (req, res) => {
    try {
      const recordId = parseInt(req.params.recordId);
      const healthRecord = await storage.getPetHealthRecord(recordId);
      
      if (!healthRecord) {
        return res.status(404).json({ error: "Health record not found" });
      }
      
      // Extract token and validate user has access
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      // Get the pet to check ownership
      const pet = await storage.getPet(healthRecord.petId);
      if (!pet) {
        return res.status(404).json({ error: "Associated pet not found" });
      }
      
      // Check if user has access to this pet's health records
      if (user.userType === UserType.PET_OWNER && pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You don't have permission to access these documents" });
      }
      
      const documents = await storage.getPetDocumentsByHealthRecordId(recordId);
      res.json(documents);
    } catch (error) {
      console.error("Error fetching health record documents:", error);
      res.status(500).json({ error: "Failed to fetch health record documents" });
    }
  });
  
  // Upload a new document for a pet
  app.post("/api/pet-documents", async (req, res) => {
    try {
      // Extract token and validate user
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const { petId, healthRecordId, documentType, title, description, fileUrl, fileType, fileSize, expiryDate } = req.body;
      
      // Check if pet exists and user has access
      const pet = await storage.getPet(petId);
      if (!pet) {
        return res.status(404).json({ error: "Pet not found" });
      }
      
      // Check if user has permission to add documents for this pet
      if (user.userType === UserType.PET_OWNER && pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You don't have permission to add documents for this pet" });
      }
      
      // If healthRecordId is provided, validate it exists
      if (healthRecordId) {
        const healthRecord = await storage.getPetHealthRecord(healthRecordId);
        if (!healthRecord) {
          return res.status(404).json({ error: "Health record not found" });
        }
        
        // Ensure the health record belongs to the same pet
        if (healthRecord.petId !== petId) {
          return res.status(400).json({ error: "Health record does not belong to the specified pet" });
        }
      }
      
      // Create the document
      const newDocument = await storage.createPetDocument({
        petId,
        healthRecordId,
        documentType,
        title,
        description,
        fileUrl,
        fileType,
        fileSize,
        uploadedBy: user.id,
        expiryDate
      });
      
      res.status(201).json(newDocument);
    } catch (error) {
      console.error("Error creating pet document:", error);
      res.status(500).json({ error: "Failed to create pet document" });
    }
  });
  
  // Mark a document as verified (authorized users only)
  app.put("/api/pet-documents/:id/verify", async (req, res) => {
    try {
      const documentId = parseInt(req.params.id);
      const document = await storage.getPetDocument(documentId);
      
      if (!document) {
        return res.status(404).json({ error: "Pet document not found" });
      }
      
      // Extract token and validate user
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      // Only service providers and shelters can verify documents
      if (user.userType === UserType.PET_OWNER) {
        return res.status(403).json({ error: "Only authorized users can verify documents" });
      }
      
      // Mark the document as verified
      const { verifiedBy } = req.body;
      const verifier = verifiedBy || `${user.name} (${user.userType})`;
      
      const updatedDocument = await storage.markDocumentAsVerified(documentId, verifier);
      
      res.json(updatedDocument);
    } catch (error) {
      console.error("Error verifying pet document:", error);
      res.status(500).json({ error: "Failed to verify pet document" });
    }
  });

  // Get all resources
  app.get("/api/resources", async (req, res) => {
    try {
      const resources = await storage.getAllResources();
      res.json(resources);
    } catch (error) {
      console.error("Error fetching resources:", error);
      res.status(500).json({ error: "Failed to fetch resources" });
    }
  });

  // Get resources by category
  app.get("/api/resources/category/:category", async (req, res) => {
    try {
      const { category } = req.params;
      const resources = await storage.getResourcesByCategory(category);
      res.json(resources);
    } catch (error) {
      console.error(`Error fetching resources in category ${req.params.category}:`, error);
      res.status(500).json({ error: "Failed to fetch resources by category" });
    }
  });

  // Get user profile details (with specific user type data)
  app.get("/api/profile", async (req, res) => {
    try {
      if (!req.isAuthenticated()) {
        return res.status(401).json({ error: "Not authenticated" });
      }
      
      // Type assertion to include our custom properties
      const user = req.user as unknown as {
        id: number;
        userType: UserType;
        [key: string]: any;
      };
      
      let profileData = { ...user };
      
      // Add user-type specific data
      switch (user.userType) {
        case UserType.PET_OWNER:
          const petOwner = await storage.getPetOwner(user.id);
          profileData = { ...profileData, ...petOwner };
          break;
          
        case UserType.SERVICE_PROVIDER:
          const serviceProvider = await storage.getServiceProvider(user.id);
          profileData = { ...profileData, ...serviceProvider };
          break;
          
        case UserType.SHELTER:
          const shelter = await storage.getShelter(user.id);
          profileData = { ...profileData, ...shelter };
          break;
      }
      
      res.json(profileData);
    } catch (error) {
      console.error("Error fetching user profile:", error);
      res.status(500).json({ error: "Failed to fetch profile" });
    }
  });
  
  // Get user profile - Firebase auth version (adds compatibility with client components)
  app.get("/api/user/profile", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      let profileData: any = { ...user };
      
      // Add user-type specific data
      switch (user.userType) {
        case UserType.PET_OWNER:
          const petOwner = await storage.getPetOwner(user.id);
          if (petOwner) profileData = { ...profileData, ...petOwner };
          break;
          
        case UserType.SERVICE_PROVIDER:
          const serviceProvider = await storage.getServiceProvider(user.id);
          if (serviceProvider) profileData = { ...profileData, ...serviceProvider };
          break;
          
        case UserType.SHELTER:
          const shelter = await storage.getShelter(user.id);
          if (shelter) profileData = { ...profileData, ...shelter };
          break;
      }
      
      res.json(profileData);
    } catch (error) {
      console.error("Error fetching user profile:", error);
      res.status(500).json({ error: "Failed to fetch profile" });
    }
  });

  // Update user profile
  app.put("/api/user/profile", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      console.log("Firebase token for profile update:", token);
      
      // Use the token handler to extract and validate the user
      const user = await getUserFromToken(token);
      
      if (!user) {
        console.log("No user found for profile update");
        return res.status(404).json({ error: "User not found" });
      }
      
      // Update base user fields
      const { name, location } = req.body;
      let updatedFields: any = {};
      
      if (name) updatedFields.name = name;
      if (location) updatedFields.location = location;
      
      // Update user in database if there are base fields to update
      if (Object.keys(updatedFields).length > 0) {
        await storage.updateUser(user.id, updatedFields);
      }
      
      // Update user type specific fields
      switch (user.userType) {
        case UserType.PET_OWNER: {
          const { bio } = req.body;
          const petOwnerFields: any = {};
          
          if (bio !== undefined) petOwnerFields.bio = bio;
          
          if (Object.keys(petOwnerFields).length > 0) {
            const petOwner = await storage.getPetOwner(user.id);
            if (petOwner) {
              await storage.updatePetOwner(petOwner.id, petOwnerFields);
            }
          }
          break;
        }
        
        case UserType.SERVICE_PROVIDER: {
          const { businessName, category, description, phone, address } = req.body;
          const providerFields: any = {};
          
          if (businessName) providerFields.businessName = businessName;
          if (category) providerFields.category = category;
          if (description !== undefined) providerFields.description = description;
          if (phone !== undefined) providerFields.phone = phone;
          if (address !== undefined) providerFields.address = address;
          
          if (Object.keys(providerFields).length > 0) {
            const provider = await storage.getServiceProvider(user.id);
            if (provider) {
              await storage.updateServiceProvider(provider.id, providerFields);
            }
          }
          break;
        }
        
        case UserType.SHELTER: {
          const { organizationName, mission, phone, address } = req.body;
          const shelterFields: any = {};
          
          if (organizationName) shelterFields.organizationName = organizationName;
          if (mission !== undefined) shelterFields.mission = mission;
          if (phone !== undefined) shelterFields.phone = phone;
          if (address !== undefined) shelterFields.address = address;
          
          if (Object.keys(shelterFields).length > 0) {
            const shelter = await storage.getShelter(user.id);
            if (shelter) {
              await storage.updateShelter(shelter.id, shelterFields);
            }
          }
          break;
        }
      }
      
      // Fetch and return the updated profile
      const updatedUser = await storage.getUser(user.id);
      let profileData: any = { ...updatedUser };
      
      switch (user.userType) {
        case UserType.PET_OWNER:
          const petOwner = await storage.getPetOwner(user.id);
          if (petOwner) profileData = { ...profileData, ...petOwner };
          break;
          
        case UserType.SERVICE_PROVIDER:
          const serviceProvider = await storage.getServiceProvider(user.id);
          if (serviceProvider) profileData = { ...profileData, ...serviceProvider };
          break;
          
        case UserType.SHELTER:
          const shelter = await storage.getShelter(user.id);
          if (shelter) profileData = { ...profileData, ...shelter };
          break;
      }
      
      res.json(profileData);
    } catch (error) {
      console.error("Error updating user profile:", error);
      res.status(500).json({ error: "Failed to update profile" });
    }
  });
  
  // FAVORITES ROUTES
  
  // Get favorites for a pet owner
  app.get("/api/favorites", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Only pet owners can have favorites
      if (user.userType !== UserType.PET_OWNER) {
        return res.status(403).json({ error: "Only pet owners can have favorites" });
      }
      
      // Get pet owner ID
      const petOwner = await storage.getPetOwner(user.id);
      if (!petOwner) {
        return res.status(404).json({ error: "Pet owner profile not found" });
      }
      
      // Get favorites for this pet owner
      const favorites = await storage.getFavoritesByPetOwnerId(petOwner.id);
      
      // Fetch pet details for each favorite
      const favoritesWithPetDetails = await Promise.all(
        favorites.map(async (favorite) => {
          const pet = await storage.getPet(favorite.petId);
          return {
            ...favorite,
            pet
          };
        })
      );
      
      res.json(favoritesWithPetDetails);
    } catch (error) {
      console.error("Error fetching favorites:", error);
      res.status(500).json({ error: "Failed to fetch favorites" });
    }
  });
  
  // Add a pet to favorites
  app.post("/api/favorites", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Only pet owners can have favorites
      if (user.userType !== UserType.PET_OWNER) {
        return res.status(403).json({ error: "Only pet owners can add favorites" });
      }
      
      // Get pet owner ID
      const petOwner = await storage.getPetOwner(user.id);
      if (!petOwner) {
        return res.status(404).json({ error: "Pet owner profile not found" });
      }
      
      const { petId } = req.body;
      if (!petId) {
        return res.status(400).json({ error: "Pet ID is required" });
      }
      
      // Check if pet exists
      const pet = await storage.getPet(petId);
      if (!pet) {
        return res.status(404).json({ error: "Pet not found" });
      }
      
      // Check if already favorited
      const isFavorite = await storage.getIsFavorite(petOwner.id, petId);
      if (isFavorite) {
        return res.status(400).json({ error: "Pet is already in favorites" });
      }
      
      // Add to favorites
      const favorite = await storage.createFavorite({
        petOwnerId: petOwner.id,
        petId
      });
      
      res.status(201).json(favorite);
    } catch (error) {
      console.error("Error adding favorite:", error);
      res.status(500).json({ error: "Failed to add favorite" });
    }
  });
  
  // Remove a pet from favorites
  app.delete("/api/favorites/:id", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Only pet owners can have favorites
      if (user.userType !== UserType.PET_OWNER) {
        return res.status(403).json({ error: "Only pet owners can manage favorites" });
      }
      
      // Get pet owner ID
      const petOwner = await storage.getPetOwner(user.id);
      if (!petOwner) {
        return res.status(404).json({ error: "Pet owner profile not found" });
      }
      
      const favoriteId = parseInt(req.params.id);
      
      // Check if favorite exists and belongs to this user
      const favorite = await storage.getFavorite(favoriteId);
      if (!favorite) {
        return res.status(404).json({ error: "Favorite not found" });
      }
      
      if (favorite.petOwnerId !== petOwner.id) {
        return res.status(403).json({ error: "Not authorized to remove this favorite" });
      }
      
      // Remove favorite
      await storage.deleteFavorite(favoriteId);
      
      res.status(204).send();
    } catch (error) {
      console.error("Error removing favorite:", error);
      res.status(500).json({ error: "Failed to remove favorite" });
    }
  });
  
  // APPOINTMENT ROUTES
  
  // Get appointments for the current user
  app.get("/api/appointments", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Get appointments for this user
      const appointments = await storage.getAppointmentsByUserId(user.id);
      
      // Add related entity details based on appointment type
      const appointmentsWithDetails = await Promise.all(
        appointments.map(async (appointment) => {
          let details: any = { ...appointment };
          
          // Add pet details if it's a pet-related appointment
          if (appointment.petId) {
            const pet = await storage.getPet(appointment.petId);
            if (pet) {
              details.petName = pet.name;
              details.petType = pet.type;
            }
          }
          
          // Add shelter details if it's a shelter appointment
          if (appointment.shelterId) {
            const shelter = await storage.getShelter(appointment.shelterId);
            if (shelter) {
              details.shelterName = shelter.organizationName;
            }
          }
          
          // Add service provider details if it's a service appointment
          if (appointment.providerId) {
            const provider = await storage.getServiceProvider(appointment.providerId);
            if (provider) {
              details.providerName = provider.businessName;
            }
          }
          
          // Add service details if it's a specific service
          if (appointment.serviceId) {
            const service = await storage.getService(appointment.serviceId);
            if (service) {
              details.serviceName = service.title;
            }
          }
          
          return details;
        })
      );
      
      res.json(appointmentsWithDetails);
    } catch (error) {
      console.error("Error fetching appointments:", error);
      res.status(500).json({ error: "Failed to fetch appointments" });
    }
  });
  
  // Create a new appointment
  app.post("/api/appointments", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Create the appointment with the user ID
      const newAppointment = await storage.createAppointment({
        ...req.body,
        userId: user.id,
        status: 'pending'
      });
      
      res.status(201).json(newAppointment);
    } catch (error) {
      console.error("Error creating appointment:", error);
      res.status(500).json({ error: "Failed to create appointment" });
    }
  });
  
  // Update appointment status
  app.patch("/api/appointments/:id/status", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const appointmentId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status || !['pending', 'confirmed', 'completed', 'cancelled'].includes(status)) {
        return res.status(400).json({ error: "Invalid status. Must be one of: pending, confirmed, completed, cancelled" });
      }
      
      // Check if appointment exists
      const appointment = await storage.getAppointment(appointmentId);
      if (!appointment) {
        return res.status(404).json({ error: "Appointment not found" });
      }
      
      // Check authorization based on user type and appointment
      let authorized = false;
      
      if (appointment.userId === user.id) {
        // User who created the appointment can always update it
        authorized = true;
      } else if (user.userType === UserType.SHELTER && appointment.shelterId) {
        // Shelter staff can update appointments at their shelter
        const shelter = await storage.getShelter(user.id);
        authorized = !!shelter && shelter.id === appointment.shelterId;
      } else if (user.userType === UserType.SERVICE_PROVIDER && appointment.providerId) {
        // Service providers can update appointments for their services
        const provider = await storage.getServiceProvider(user.id);
        authorized = !!provider && provider.id === appointment.providerId;
      }
      
      if (!authorized) {
        return res.status(403).json({ error: "Not authorized to update this appointment" });
      }
      
      // Update appointment status
      const updatedAppointment = await storage.updateAppointmentStatus(appointmentId, status);
      
      res.json(updatedAppointment);
    } catch (error) {
      console.error("Error updating appointment status:", error);
      res.status(500).json({ error: "Failed to update appointment status" });
    }
  });

  // Account deactivation and deletion endpoints (GDPR compliance)
  app.post("/api/user/deactivate", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      // Deactivate the user account (update flag in database)
      // For deactivation, we just update the 'isActive' flag but keep data intact
      await storage.updateUser(user.id, { isActive: false });
      
      // Return success response
      res.status(200).json({ message: "Account deactivated successfully" });
      
    } catch (error) {
      console.error("Error deactivating account:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });
  
  app.delete("/api/user", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      console.log(`Attempting to delete user with ID: ${user.id}, type: ${user.userType}`);
      
      // Permanently delete user and all associated data
      if (user.userType === UserType.PET_OWNER) {
        // Get pet owner
        const petOwner = await storage.getPetOwner(user.id);
        
        if (petOwner) {
          // Delete favorites
          const favorites = await storage.getFavoritesByPetOwnerId(petOwner.id);
          for (const favorite of favorites) {
            await storage.deleteFavorite(favorite.id);
          }
          
          // Delete appointments
          const appointments = await storage.getAppointmentsByUserId(user.id);
          for (const appointment of appointments) {
            await storage.updateAppointmentStatus(appointment.id, "cancelled");
          }
          
          // Delete pets 
          const pets = await storage.getPetsByOwnerId(user.id);
          for (const pet of pets) {
            await storage.deletePet(pet.id);
          }
        }
      } else if (user.userType === UserType.SERVICE_PROVIDER) {
        // Get service provider
        const serviceProvider = await storage.getServiceProvider(user.id);
        
        if (serviceProvider) {
          // Update appointments
          const appointments = await storage.getAppointmentsByProviderId(serviceProvider.id);
          for (const appointment of appointments) {
            await storage.updateAppointmentStatus(appointment.id, "cancelled");
          }
          
          // Delete services
          const services = await storage.getServicesByProviderId(serviceProvider.id);
          for (const service of services) {
            await storage.deleteService(service.id);
          }
        }
      } else if (user.userType === UserType.SHELTER) {
        // Get shelter
        const shelter = await storage.getShelter(user.id);
        
        if (shelter) {
          // Update appointments
          const appointments = await storage.getAppointmentsByShelterId(shelter.id);
          for (const appointment of appointments) {
            await storage.updateAppointmentStatus(appointment.id, "cancelled");
          }
          
          // Delete pets
          const pets = await storage.getPetsByShelterId(shelter.id);
          for (const pet of pets) {
            await storage.deletePet(pet.id);
          }
        }
      }
      
      // Delete the user from Firebase if they have a Firebase UID and if Firebase Admin is initialized
      if (user.firebaseUid) {
        try {
          // Initialize Firebase Admin
          const adminApp = initializeFirebaseAdmin();
          
          // Skip in development mode if Firebase Admin is not properly configured
          if (process.env.NODE_ENV !== "production" && 
              !process.env.FIREBASE_SERVICE_ACCOUNT_JSON && 
              (!process.env.FIREBASE_CLIENT_EMAIL || !process.env.FIREBASE_PRIVATE_KEY)) {
            console.log("Skipping Firebase user deletion in development mode due to missing credentials");
          } else {
            // Delete the Firebase user
            await adminApp.auth().deleteUser(user.firebaseUid);
            console.log(`Firebase user with UID ${user.firebaseUid} deleted successfully`);
          }
        } catch (firebaseError) {
          console.error("Error deleting Firebase user:", firebaseError);
          // Continue with local user deletion even if Firebase deletion fails
        }
      }
      
      // Mark the user as inactive in our database
      await storage.updateUser(user.id, { 
        isActive: false
        // isDeleted: true  // Commented out until schema migration
      });
      
      // Return success response
      res.status(200).json({ message: "Account deleted successfully" });
      
    } catch (error) {
      console.error("Error deleting account:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // ==========================================
  // PET WEIGHT HISTORY ENDPOINTS
  // ==========================================
  
  // Create a new pet weight record
  app.post("/api/pets/:petId/weight", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const petId = parseInt(req.params.petId);
      
      // Verify the pet belongs to this user
      const pet = await storage.getPet(petId);
      if (!pet) {
        return res.status(404).json({ error: "Pet not found" });
      }
      
      if (pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to add weight records for this pet" });
      }
      
      const { weight, recordDate, notes, recordedBy } = req.body;
      
      if (!weight || !recordDate) {
        return res.status(400).json({ error: "Weight and record date are required" });
      }
      
      const weightRecord = await storage.createPetWeightHistory({
        petId,
        weight,
        recordDate,
        notes: notes || null,
        recordedBy: recordedBy || null
      });
      
      res.status(201).json(weightRecord);
    } catch (error) {
      console.error("Error creating pet weight record:", error);
      res.status(500).json({ error: "Failed to create pet weight record" });
    }
  });
  
  // Get all weight records for a pet
  app.get("/api/pets/:petId/weight", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const petId = parseInt(req.params.petId);
      
      // Verify the pet belongs to this user
      const pet = await storage.getPet(petId);
      if (!pet) {
        return res.status(404).json({ error: "Pet not found" });
      }
      
      if (pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to view weight records for this pet" });
      }
      
      const weightRecords = await storage.getPetWeightHistoryByPetId(petId);
      res.json(weightRecords);
    } catch (error) {
      console.error("Error fetching pet weight records:", error);
      res.status(500).json({ error: "Failed to fetch pet weight records" });
    }
  });
  
  // Get a specific weight record
  app.get("/api/pets/weight/:recordId", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const recordId = parseInt(req.params.recordId);
      const weightRecord = await storage.getPetWeightHistory(recordId);
      
      if (!weightRecord) {
        return res.status(404).json({ error: "Weight record not found" });
      }
      
      // Verify the pet belongs to this user
      const pet = await storage.getPet(weightRecord.petId);
      if (!pet || pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to view this weight record" });
      }
      
      res.json(weightRecord);
    } catch (error) {
      console.error("Error fetching specific weight record:", error);
      res.status(500).json({ error: "Failed to fetch weight record" });
    }
  });

  // ==========================================
  // PET HEALTH METRICS ENDPOINTS
  // ==========================================
  
  // Create a new pet health metric
  app.post("/api/pets/:petId/health-metrics", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const petId = parseInt(req.params.petId);
      
      // Verify the pet belongs to this user
      const pet = await storage.getPet(petId);
      if (!pet) {
        return res.status(404).json({ error: "Pet not found" });
      }
      
      if (pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to add health metrics for this pet" });
      }
      
      const { metricType, metricValue, unit, recordDate, recordTime, notes, healthRecordId } = req.body;
      
      if (!metricType || !metricValue || !unit || !recordDate) {
        return res.status(400).json({ error: "Metric type, value, unit, and record date are required" });
      }
      
      const metric = await storage.createPetHealthMetric({
        petId,
        metricType,
        metricValue,
        unit,
        recordDate,
        recordTime: recordTime || null,
        notes: notes || null,
        healthRecordId: healthRecordId || null,
        createdBy: user.id
      });
      
      res.status(201).json(metric);
    } catch (error) {
      console.error("Error creating pet health metric:", error);
      res.status(500).json({ error: "Failed to create pet health metric" });
    }
  });
  
  // Get all health metrics for a pet
  app.get("/api/pets/:petId/health-metrics", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const petId = parseInt(req.params.petId);
      
      // Verify the pet belongs to this user
      const pet = await storage.getPet(petId);
      if (!pet) {
        return res.status(404).json({ error: "Pet not found" });
      }
      
      if (pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to view health metrics for this pet" });
      }
      
      // Check if metric type is specified in query
      const { type } = req.query;
      
      let metrics;
      if (type) {
        metrics = await storage.getPetHealthMetricsByType(petId, type as string);
      } else {
        metrics = await storage.getPetHealthMetricsByPetId(petId);
      }
      
      res.json(metrics);
    } catch (error) {
      console.error("Error fetching pet health metrics:", error);
      res.status(500).json({ error: "Failed to fetch pet health metrics" });
    }
  });
  
  // Get a specific health metric
  app.get("/api/pets/health-metrics/:metricId", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const metricId = parseInt(req.params.metricId);
      const metric = await storage.getPetHealthMetric(metricId);
      
      if (!metric) {
        return res.status(404).json({ error: "Health metric not found" });
      }
      
      // Verify the pet belongs to this user
      const pet = await storage.getPet(metric.petId);
      if (!pet || pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to view this health metric" });
      }
      
      res.json(metric);
    } catch (error) {
      console.error("Error fetching specific health metric:", error);
      res.status(500).json({ error: "Failed to fetch health metric" });
    }
  });
  
  // Update a health metric
  app.put("/api/pets/health-metrics/:metricId", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const metricId = parseInt(req.params.metricId);
      const metric = await storage.getPetHealthMetric(metricId);
      
      if (!metric) {
        return res.status(404).json({ error: "Health metric not found" });
      }
      
      // Verify the pet belongs to this user
      const pet = await storage.getPet(metric.petId);
      if (!pet || pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to update this health metric" });
      }
      
      const { metricValue, unit, recordDate, recordTime, notes } = req.body;
      
      // Create update object with only provided fields
      const updateData: Partial<PetHealthMetric> = {};
      if (metricValue !== undefined) updateData.metricValue = metricValue;
      if (unit !== undefined) updateData.unit = unit;
      if (recordDate !== undefined) updateData.recordDate = recordDate;
      if (recordTime !== undefined) updateData.recordTime = recordTime;
      if (notes !== undefined) updateData.notes = notes;
      
      const updatedMetric = await storage.updatePetHealthMetric(metricId, updateData);
      
      res.json(updatedMetric);
    } catch (error) {
      console.error("Error updating health metric:", error);
      res.status(500).json({ error: "Failed to update health metric" });
    }
  });
  
  // Delete a health metric (soft delete)
  app.delete("/api/pets/health-metrics/:metricId", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const metricId = parseInt(req.params.metricId);
      const metric = await storage.getPetHealthMetric(metricId);
      
      if (!metric) {
        return res.status(404).json({ error: "Health metric not found" });
      }
      
      // Verify the pet belongs to this user
      const pet = await storage.getPet(metric.petId);
      if (!pet || pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to delete this health metric" });
      }
      
      await storage.softDeletePetHealthMetric(metricId);
      
      res.json({ message: "Health metric deleted successfully" });
    } catch (error) {
      console.error("Error deleting health metric:", error);
      res.status(500).json({ error: "Failed to delete health metric" });
    }
  });

  // ==========================================
  // NOTIFICATION PREFERENCES ENDPOINTS
  // ==========================================
  
  // Create/update notification preferences
  app.post("/api/notification-preferences", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const { notificationType, viaApp, viaEmail, viaSms, viaPush, quietHoursStart, quietHoursEnd, isPaused } = req.body;
      
      if (!notificationType) {
        return res.status(400).json({ error: "Notification type is required" });
      }
      
      // Check if preference already exists for this user and type
      const existingPreferences = await storage.getNotificationPreferencesByUserId(user.id);
      const existingPreference = existingPreferences.find(pref => pref.notificationType === notificationType);
      
      let preference;
      
      if (existingPreference) {
        // Update existing preference
        const updateData: Partial<NotificationPreference> = {};
        if (viaApp !== undefined) updateData.viaApp = viaApp;
        if (viaEmail !== undefined) updateData.viaEmail = viaEmail;
        if (viaSms !== undefined) updateData.viaSms = viaSms;
        if (viaPush !== undefined) updateData.viaPush = viaPush;
        if (quietHoursStart !== undefined) updateData.quietHoursStart = quietHoursStart;
        if (quietHoursEnd !== undefined) updateData.quietHoursEnd = quietHoursEnd;
        if (isPaused !== undefined) updateData.isPaused = isPaused;
        
        preference = await storage.updateNotificationPreference(existingPreference.id, updateData);
      } else {
        // Create new preference
        preference = await storage.createNotificationPreference({
          userId: user.id,
          notificationType,
          viaApp: viaApp !== undefined ? viaApp : true,
          viaEmail: viaEmail !== undefined ? viaEmail : true,
          viaSms: viaSms !== undefined ? viaSms : false,
          viaPush: viaPush !== undefined ? viaPush : true,
          quietHoursStart: quietHoursStart || null,
          quietHoursEnd: quietHoursEnd || null,
          isPaused: isPaused !== undefined ? isPaused : false
        });
      }
      
      res.json(preference);
    } catch (error) {
      console.error("Error creating/updating notification preferences:", error);
      res.status(500).json({ error: "Failed to save notification preferences" });
    }
  });
  
  // Get notification preferences for current user
  app.get("/api/notification-preferences", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const preferences = await storage.getNotificationPreferencesByUserId(user.id);
      res.json(preferences);
    } catch (error) {
      console.error("Error fetching notification preferences:", error);
      res.status(500).json({ error: "Failed to fetch notification preferences" });
    }
  });
  
  // Get a specific notification preference
  app.get("/api/notification-preferences/:id", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const preferenceId = parseInt(req.params.id);
      const preference = await storage.getNotificationPreference(preferenceId);
      
      if (!preference) {
        return res.status(404).json({ error: "Notification preference not found" });
      }
      
      // Verify the preference belongs to this user
      if (preference.userId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to view this notification preference" });
      }
      
      res.json(preference);
    } catch (error) {
      console.error("Error fetching specific notification preference:", error);
      res.status(500).json({ error: "Failed to fetch notification preference" });
    }
  });

  // ==========================================
  // REMINDER NOTIFICATIONS ENDPOINTS
  // ==========================================
  
  // Create a reminder notification
  app.post("/api/reminder-notifications", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const { reminderId, scheduledAt, deliveryChannel, status } = req.body;
      
      if (!reminderId || !scheduledAt || !deliveryChannel) {
        return res.status(400).json({ error: "Reminder ID, scheduled date/time, and delivery channel are required" });
      }
      
      const reminderNotification = await storage.createReminderNotification({
        userId: user.id,
        reminderId,
        scheduledAt: new Date(scheduledAt),
        deliveryChannel,
        status: status || null,
        sentAt: null
      });
      
      res.status(201).json(reminderNotification);
    } catch (error) {
      console.error("Error creating reminder notification:", error);
      res.status(500).json({ error: "Failed to create reminder notification" });
    }
  });
  
  // Get reminder notifications for current user
  app.get("/api/reminder-notifications", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const notifications = await storage.getReminderNotificationsByUserId(user.id);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching reminder notifications:", error);
      res.status(500).json({ error: "Failed to fetch reminder notifications" });
    }
  });
  
  // Get reminder notifications for a specific reminder
  app.get("/api/reminder-notifications/reminder/:reminderId", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const reminderId = parseInt(req.params.reminderId);
      
      // We should verify that the reminder belongs to this user
      // This would require a getPetCareReminder method to check ownership
      // For now, we'll filter the results by user ID after fetching
      
      const allNotifications = await storage.getReminderNotificationsByReminderId(reminderId);
      const userNotifications = allNotifications.filter(notif => notif.userId === user.id);
      
      res.json(userNotifications);
    } catch (error) {
      console.error("Error fetching reminder notifications by reminder:", error);
      res.status(500).json({ error: "Failed to fetch reminder notifications" });
    }
  });
  
  // Update the status of a reminder notification
  app.put("/api/reminder-notifications/:id/status", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      
      const notificationId = parseInt(req.params.id);
      const { status } = req.body;
      
      if (!status) {
        return res.status(400).json({ error: "Status is required" });
      }
      
      const notification = await storage.getReminderNotification(notificationId);
      
      if (!notification) {
        return res.status(404).json({ error: "Reminder notification not found" });
      }
      
      // Verify the notification belongs to this user
      if (notification.userId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to update this notification" });
      }
      
      const updatedNotification = await storage.updateReminderNotificationStatus(notificationId, status);
      
      res.json(updatedNotification);
    } catch (error) {
      console.error("Error updating reminder notification status:", error);
      res.status(500).json({ error: "Failed to update reminder notification status" });
    }
  });

  // === Pet Weight History API Routes ===
  
  // Get a pet weight history record by ID
  app.get("/api/pet-weight-history/:id", async (req, res) => {
    try {
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const weightRecordId = parseInt(req.params.id);
      const weightRecord = await storage.getPetWeightHistory(weightRecordId);
      
      if (!weightRecord) {
        return res.status(404).json({ error: "Weight record not found" });
      }
      
      // Check if pet belongs to the user
      const pet = await storage.getPet(weightRecord.petId);
      if (!pet || (pet.ownerId !== user.id && user.userType !== UserType.SERVICE_PROVIDER)) {
        return res.status(403).json({ error: "You do not have permission to access this pet's weight record" });
      }
      
      res.json(weightRecord);
    } catch (error) {
      console.error("Error fetching pet weight history:", error);
      res.status(500).json({ error: "Failed to fetch pet weight history" });
    }
  });
  
  // Create a new pet weight history record
  app.post("/api/pet-weight-history", async (req, res) => {
    try {
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const { petId, weight, recordDate, notes, recordedBy } = req.body;
      
      if (!petId || !weight || !recordDate) {
        return res.status(400).json({ error: "Pet ID, weight, and record date are required" });
      }
      
      // Check if pet belongs to the user
      const pet = await storage.getPet(petId);
      if (!pet || (pet.ownerId !== user.id && user.userType !== UserType.SERVICE_PROVIDER)) {
        return res.status(403).json({ error: "You do not have permission to add a weight record for this pet" });
      }
      
      const newWeightRecord: InsertPetWeightHistory = {
        petId,
        weight,
        recordDate,
        notes: notes || null,
        recordedBy: recordedBy || null
      };
      
      const createdRecord = await storage.createPetWeightHistory(newWeightRecord);
      res.status(201).json(createdRecord);
    } catch (error) {
      console.error("Error creating pet weight history:", error);
      res.status(500).json({ error: "Failed to create weight record" });
    }
  });
  
  // Get weight history for a specific pet
  app.get("/api/pets/:petId/weight-history", async (req, res) => {
    try {
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const petId = parseInt(req.params.petId);
      
      // Check if pet belongs to the user
      const pet = await storage.getPet(petId);
      if (!pet || (pet.ownerId !== user.id && user.userType !== UserType.SERVICE_PROVIDER)) {
        return res.status(403).json({ error: "You do not have permission to access this pet's weight history" });
      }
      
      const weightHistory = await storage.getPetWeightHistoryByPetId(petId);
      res.json(weightHistory);
    } catch (error) {
      console.error("Error fetching pet weight history:", error);
      res.status(500).json({ error: "Failed to fetch weight history" });
    }
  });
  
  // === Pet Health Metrics API Routes ===
  
  // Get a pet health metric by ID
  app.get("/api/pet-health-metrics/:id", async (req, res) => {
    try {
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const metricId = parseInt(req.params.id);
      const metric = await storage.getPetHealthMetric(metricId);
      
      if (!metric) {
        return res.status(404).json({ error: "Health metric not found" });
      }
      
      // Check if pet belongs to the user
      const pet = await storage.getPet(metric.petId);
      if (!pet || (pet.ownerId !== user.id && user.userType !== UserType.SERVICE_PROVIDER)) {
        return res.status(403).json({ error: "You do not have permission to access this pet's health metrics" });
      }
      
      res.json(metric);
    } catch (error) {
      console.error("Error fetching pet health metric:", error);
      res.status(500).json({ error: "Failed to fetch health metric" });
    }
  });
  
  // Create a new pet health metric
  app.post("/api/pet-health-metrics", async (req, res) => {
    try {
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const { petId, metricType, metricValue, unit, recordDate, notes, healthRecordId, recordTime, createdBy } = req.body;
      
      if (!petId || !metricType || !metricValue || !unit || !recordDate) {
        return res.status(400).json({ 
          error: "Pet ID, metric type, metric value, unit, and record date are required" 
        });
      }
      
      // Check if pet belongs to the user
      const pet = await storage.getPet(petId);
      if (!pet || (pet.ownerId !== user.id && user.userType !== UserType.SERVICE_PROVIDER)) {
        return res.status(403).json({ error: "You do not have permission to add a health metric for this pet" });
      }
      
      const newHealthMetric: InsertPetHealthMetric = {
        petId,
        metricType,
        metricValue,
        unit,
        recordDate,
        notes: notes || null,
        healthRecordId: healthRecordId || null,
        recordTime: recordTime || null,
        createdBy: createdBy || null
      };
      
      const createdMetric = await storage.createPetHealthMetric(newHealthMetric);
      res.status(201).json(createdMetric);
    } catch (error) {
      console.error("Error creating pet health metric:", error);
      res.status(500).json({ error: "Failed to create health metric" });
    }
  });
  
  // Get health metrics for a specific pet
  app.get("/api/pets/:petId/health-metrics", async (req, res) => {
    try {
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const petId = parseInt(req.params.petId);
      
      // Check if pet belongs to the user
      const pet = await storage.getPet(petId);
      if (!pet || (pet.ownerId !== user.id && user.userType !== UserType.SERVICE_PROVIDER)) {
        return res.status(403).json({ error: "You do not have permission to access this pet's health metrics" });
      }
      
      const healthMetrics = await storage.getPetHealthMetricsByPetId(petId);
      res.json(healthMetrics);
    } catch (error) {
      console.error("Error fetching pet health metrics:", error);
      res.status(500).json({ error: "Failed to fetch health metrics" });
    }
  });
  
  // Get health metrics of a specific type for a pet
  app.get("/api/pets/:petId/health-metrics/:metricType", async (req, res) => {
    try {
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const petId = parseInt(req.params.petId);
      const { metricType } = req.params;
      
      // Check if pet belongs to the user
      const pet = await storage.getPet(petId);
      if (!pet || (pet.ownerId !== user.id && user.userType !== UserType.SERVICE_PROVIDER)) {
        return res.status(403).json({ error: "You do not have permission to access this pet's health metrics" });
      }
      
      const healthMetrics = await storage.getPetHealthMetricsByType(petId, metricType);
      res.json(healthMetrics);
    } catch (error) {
      console.error("Error fetching pet health metrics by type:", error);
      res.status(500).json({ error: "Failed to fetch health metrics by type" });
    }
  });
  
  // Update a pet health metric
  app.put("/api/pet-health-metrics/:id", async (req, res) => {
    try {
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const metricId = parseInt(req.params.id);
      const metric = await storage.getPetHealthMetric(metricId);
      
      if (!metric) {
        return res.status(404).json({ error: "Health metric not found" });
      }
      
      // Check if pet belongs to the user
      const pet = await storage.getPet(metric.petId);
      if (!pet || (pet.ownerId !== user.id && user.userType !== UserType.SERVICE_PROVIDER)) {
        return res.status(403).json({ error: "You do not have permission to update this pet's health metrics" });
      }
      
      const updateData = req.body;
      const updatedMetric = await storage.updatePetHealthMetric(metricId, updateData);
      
      res.json(updatedMetric);
    } catch (error) {
      console.error("Error updating pet health metric:", error);
      res.status(500).json({ error: "Failed to update health metric" });
    }
  });
  
  // Soft delete a pet health metric
  app.delete("/api/pet-health-metrics/:id", async (req, res) => {
    try {
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const metricId = parseInt(req.params.id);
      const metric = await storage.getPetHealthMetric(metricId);
      
      if (!metric) {
        return res.status(404).json({ error: "Health metric not found" });
      }
      
      // Check if pet belongs to the user
      const pet = await storage.getPet(metric.petId);
      if (!pet || (pet.ownerId !== user.id && user.userType !== UserType.SERVICE_PROVIDER)) {
        return res.status(403).json({ error: "You do not have permission to delete this pet's health metrics" });
      }
      
      const deletedMetric = await storage.softDeletePetHealthMetric(metricId);
      
      res.json(deletedMetric);
    } catch (error) {
      console.error("Error deleting pet health metric:", error);
      res.status(500).json({ error: "Failed to delete health metric" });
    }
  });
  
  // === Notification Preferences API Routes ===
  
  // Get a notification preference by ID
  app.get("/api/notification-preferences/:id", async (req, res) => {
    try {
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const preferenceId = parseInt(req.params.id);
      const preference = await storage.getNotificationPreference(preferenceId);
      
      if (!preference) {
        return res.status(404).json({ error: "Notification preference not found" });
      }
      
      // Verify preference belongs to the user
      if (preference.userId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to access this notification preference" });
      }
      
      res.json(preference);
    } catch (error) {
      console.error("Error fetching notification preference:", error);
      res.status(500).json({ error: "Failed to fetch notification preference" });
    }
  });
  
  // Create a new notification preference
  app.post("/api/notification-preferences", async (req, res) => {
    try {
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const { notificationType, viaApp, viaEmail, viaSms, viaPush, quietHoursStart, quietHoursEnd, isPaused } = req.body;
      
      if (!notificationType) {
        return res.status(400).json({ error: "Notification type is required" });
      }
      
      const newPreference: InsertNotificationPreference = {
        userId: user.id,
        notificationType,
        viaApp: viaApp !== undefined ? viaApp : true,
        viaEmail: viaEmail !== undefined ? viaEmail : true,
        viaSms: viaSms !== undefined ? viaSms : false,
        viaPush: viaPush !== undefined ? viaPush : true,
        quietHoursStart: quietHoursStart || null,
        quietHoursEnd: quietHoursEnd || null,
        isPaused: isPaused !== undefined ? isPaused : false
      };
      
      const createdPreference = await storage.createNotificationPreference(newPreference);
      res.status(201).json(createdPreference);
    } catch (error) {
      console.error("Error creating notification preference:", error);
      res.status(500).json({ error: "Failed to create notification preference" });
    }
  });
  
  // Get all notification preferences for a user
  app.get("/api/users/notification-preferences", async (req, res) => {
    try {
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const preferences = await storage.getNotificationPreferencesByUserId(user.id);
      res.json(preferences);
    } catch (error) {
      console.error("Error fetching user notification preferences:", error);
      res.status(500).json({ error: "Failed to fetch notification preferences" });
    }
  });
  
  // Update a notification preference
  app.put("/api/notification-preferences/:id", async (req, res) => {
    try {
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const preferenceId = parseInt(req.params.id);
      const preference = await storage.getNotificationPreference(preferenceId);
      
      if (!preference) {
        return res.status(404).json({ error: "Notification preference not found" });
      }
      
      // Verify preference belongs to the user
      if (preference.userId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to update this notification preference" });
      }
      
      const updateData = req.body;
      const updatedPreference = await storage.updateNotificationPreference(preferenceId, updateData);
      
      res.json(updatedPreference);
    } catch (error) {
      console.error("Error updating notification preference:", error);
      res.status(500).json({ error: "Failed to update notification preference" });
    }
  });
  
  // === Reminder Notifications API Routes ===
  
  // Get a reminder notification by ID
  app.get("/api/reminder-notifications/:id", async (req, res) => {
    try {
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const notificationId = parseInt(req.params.id);
      const notification = await storage.getReminderNotification(notificationId);
      
      if (!notification) {
        return res.status(404).json({ error: "Reminder notification not found" });
      }
      
      // Verify notification belongs to the user
      if (notification.userId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to access this notification" });
      }
      
      res.json(notification);
    } catch (error) {
      console.error("Error fetching reminder notification:", error);
      res.status(500).json({ error: "Failed to fetch reminder notification" });
    }
  });
  
  // Create a new reminder notification
  app.post("/api/reminder-notifications", async (req, res) => {
    try {
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const { reminderId, scheduledAt, deliveryChannel, status, sentAt } = req.body;
      
      if (!reminderId || !scheduledAt || !deliveryChannel) {
        return res.status(400).json({ 
          error: "Reminder ID, scheduled time, and delivery channel are required" 
        });
      }
      
      const newNotification: InsertReminderNotification = {
        userId: user.id,
        reminderId,
        scheduledAt: new Date(scheduledAt),
        deliveryChannel,
        status: status || null,
        sentAt: sentAt ? new Date(sentAt) : null
      };
      
      const createdNotification = await storage.createReminderNotification(newNotification);
      res.status(201).json(createdNotification);
    } catch (error) {
      console.error("Error creating reminder notification:", error);
      res.status(500).json({ error: "Failed to create reminder notification" });
    }
  });
  
  // Get all notifications for a user
  app.get("/api/users/reminder-notifications", async (req, res) => {
    try {
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Authentication required" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid authentication token" });
      }
      
      const notifications = await storage.getReminderNotificationsByUserId(user.id);
      res.json(notifications);
    } catch (error) {
      console.error("Error fetching user reminder notifications:", error);
      res.status(500).json({ error: "Failed to fetch reminder notifications" });
    }
  });
  
  // Pet Care Reminders API Endpoints
  
  // Get all reminders for a specific pet
  app.get("/api/pets/:petId/reminders", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid or expired authentication token" });
      }
      
      const petId = parseInt(req.params.petId);
      if (isNaN(petId)) {
        return res.status(400).json({ error: "Invalid pet ID format" });
      }
      
      // Verify the pet belongs to this user
      const pet = await storage.getPet(petId);
      if (!pet || pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to view reminders for this pet" });
      }
      
      // Get all reminders for this pet
      const reminders = await storage.getPetCareRemindersByPetId(petId);
      
      res.json(reminders);
    } catch (error) {
      console.error("Error fetching pet reminders:", error);
      res.status(500).json({ error: "Failed to fetch pet reminders" });
    }
  });
  
  // Get a specific reminder by ID
  app.get("/api/reminders/:id", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid or expired authentication token" });
      }
      
      const reminderId = parseInt(req.params.id);
      if (isNaN(reminderId)) {
        return res.status(400).json({ error: "Invalid reminder ID format" });
      }
      
      // Fetch the reminder
      const reminder = await storage.getPetCareReminder(reminderId);
      if (!reminder) {
        return res.status(404).json({ error: "Reminder not found" });
      }
      
      // Verify the reminder belongs to this user
      if (reminder.userId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to view this reminder" });
      }
      
      res.json(reminder);
    } catch (error) {
      console.error("Error fetching reminder:", error);
      res.status(500).json({ error: "Failed to fetch reminder" });
    }
  });
  
  // Get all reminders for the current user
  app.get("/api/reminders", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid or expired authentication token" });
      }
      
      // Get all reminders for this user
      const reminders = await storage.getPetCareRemindersByUserId(user.id);
      
      res.json(reminders);
    } catch (error) {
      console.error("Error fetching user reminders:", error);
      res.status(500).json({ error: "Failed to fetch user reminders" });
    }
  });
  
  // Create a new reminder for a pet
  app.post("/api/pets/:petId/reminders", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid or expired authentication token" });
      }
      
      const petId = parseInt(req.params.petId);
      if (isNaN(petId)) {
        return res.status(400).json({ error: "Invalid pet ID format" });
      }
      
      // Verify the pet belongs to this user
      const pet = await storage.getPet(petId);
      if (!pet || pet.ownerId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to create reminders for this pet" });
      }
      
      // Validate the reminder data
      const reminderData = {
        ...req.body,
        petId,
        userId: user.id
      };
      
      // Create the new reminder
      const newReminder = await storage.createPetCareReminder(reminderData);
      
      // Create a notification entry if applicable
      if (reminderData.createNotification) {
        const notificationData: InsertReminderNotification = {
          reminderId: newReminder.id,
          userId: user.id,
          scheduledAt: new Date(newReminder.startDate),
          deliveryChannel: "app", // Default to app notification
          status: "pending"
        };
        await storage.createReminderNotification(notificationData);
      }
      
      res.status(201).json(newReminder);
    } catch (error) {
      console.error("Error creating pet reminder:", error);
      res.status(500).json({ error: "Failed to create pet reminder" });
    }
  });
  
  // Update a reminder
  app.put("/api/reminders/:id", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid or expired authentication token" });
      }
      
      const reminderId = parseInt(req.params.id);
      if (isNaN(reminderId)) {
        return res.status(400).json({ error: "Invalid reminder ID format" });
      }
      
      // Fetch the existing reminder to verify ownership
      const existingReminder = await storage.getPetCareReminder(reminderId);
      if (!existingReminder) {
        return res.status(404).json({ error: "Reminder not found" });
      }
      
      // Verify the reminder belongs to this user
      if (existingReminder.userId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to update this reminder" });
      }
      
      // Update the reminder
      const updatedReminder = await storage.updatePetCareReminder(reminderId, req.body);
      
      res.json(updatedReminder);
    } catch (error) {
      console.error("Error updating reminder:", error);
      res.status(500).json({ error: "Failed to update reminder" });
    }
  });
  
  // Mark a reminder as completed
  app.post("/api/reminders/:id/complete", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid or expired authentication token" });
      }
      
      const reminderId = parseInt(req.params.id);
      if (isNaN(reminderId)) {
        return res.status(400).json({ error: "Invalid reminder ID format" });
      }
      
      // Fetch the existing reminder to verify ownership
      const existingReminder = await storage.getPetCareReminder(reminderId);
      if (!existingReminder) {
        return res.status(404).json({ error: "Reminder not found" });
      }
      
      // Verify the reminder belongs to this user
      if (existingReminder.userId !== user.id) {
        return res.status(403).json({ error: "You do not have permission to complete this reminder" });
      }
      
      // Mark the reminder as completed
      const completedReminder = await storage.markReminderAsCompleted(reminderId);
      
      res.json(completedReminder);
    } catch (error) {
      console.error("Error completing reminder:", error);
      res.status(500).json({ error: "Failed to complete reminder" });
    }
  });
  
  // Get all active reminders for today
  app.get("/api/reminders/active", async (req, res) => {
    try {
      // Extract token using utility function
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Invalid or expired authentication token" });
      }
      
      // Get all active reminders
      const activeReminders = await storage.getActivePetCareReminders();
      
      // Filter for the current user's reminders
      const userActiveReminders = activeReminders.filter(reminder => reminder.userId === user.id);
      
      res.json(userActiveReminders);
    } catch (error) {
      console.error("Error fetching active reminders:", error);
      res.status(500).json({ error: "Failed to fetch active reminders" });
    }
  });

  // ======== SERVICE PROVIDER SPECIFIC ROUTES ========

  // Get service provider details by ID
  app.get("/api/service-provider/:providerId", async (req, res) => {
    try {
      const providerId = parseInt(req.params.providerId);
      console.log(`Looking up provider with ID ${providerId}`);
      
      // For demonstration purposes, instead of using storage, return mock data
      const mockProvider = {
        id: providerId,
        userId: 2,
        category: "Veterinary",
        businessName: "Happy Pets Veterinary Clinic",
        description: "Professional pet healthcare services with experienced veterinarians.",
        address: "123 Pet Care Avenue, Pet City",
        phone: "+1234567890",
        rating: 4.5,
        priceRange: "$$",
        name: "Dr. James Smith",
        email: "james.smith@example.com",
        location: "Pet City, PC",
        services: [
          {
            id: 1,
            providerId: providerId,
            category: "Health Check",
            title: "General Health Examination",
            description: "Comprehensive health check for your pet",
            price: "50",
            duration: "30 minutes",
            available: true,
            createdAt: new Date()
          },
          {
            id: 2,
            providerId: providerId,
            category: "Vaccination",
            title: "Standard Vaccination Package",
            description: "Essential vaccines for pets of all ages",
            price: "100",
            duration: "45 minutes",
            available: true,
            createdAt: new Date()
          },
          {
            id: 3,
            providerId: providerId,
            category: "Treatment",
            title: "Minor Wound Treatment",
            description: "Care for minor injuries and wounds",
            price: "75",
            duration: "60 minutes",
            available: true,
            createdAt: new Date()
          }
        ],
        averageRating: 4.5
      };
      
      console.log("Returning mock provider data");
      res.json(mockProvider);
    } catch (error) {
      console.error(`Error fetching service provider ID ${req.params.providerId}:`, error);
      res.status(500).json({ error: "Failed to fetch service provider details" });
    }
  });

  // Get service provider settings
  app.get("/api/service-provider/:providerId/settings", async (req, res) => {
    try {
      const providerId = parseInt(req.params.providerId);
      
      // Authentication check
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      // For demonstration purposes, skip the provider authorization check
      // and directly return mock settings data
      
      // Mock settings for the provider
      const mockSettings = [
        { id: 1, providerId, settingCategory: "availability", settingName: "workHours", settingValue: "9:00-17:00" },
        { id: 2, providerId, settingCategory: "notifications", settingName: "emailAlerts", settingValue: "true" },
        { id: 3, providerId, settingCategory: "notifications", settingName: "smsAlerts", settingValue: "false" }
      ];
      res.json(mockSettings);
    } catch (error) {
      console.error(`Error fetching settings for service provider ${req.params.providerId}:`, error);
      res.status(500).json({ error: "Failed to fetch service provider settings" });
    }
  });

  // Update or create service provider settings
  app.post("/api/service-provider/:providerId/settings", async (req, res) => {
    try {
      const providerId = parseInt(req.params.providerId);
      const { settingCategory, settingName, settingValue } = req.body;
      
      // Validation
      if (!settingCategory || !settingName || !settingValue) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      
      // Authentication check
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      // Find the service provider for this user
      const provider = await storage.getServiceProvider(user.id);
      
      // Check if the user is authorized for this provider
      if (!provider || provider.id !== providerId) {
        return res.status(403).json({ error: "Forbidden - You are not authorized to update these settings" });
      }
      
      // For now, we'll simulate a successful setting update/creation
      const setting = {
        id: Date.now(), // Use timestamp as a mock ID
        providerId,
        settingCategory,
        settingName,
        settingValue,
        createdAt: new Date(),
        updatedAt: new Date()
      };
      
      // For demonstration, let's simulate whether this is an update or a creation
      const mockExistingSetting = Math.random() > 0.5;
      
      res.status(mockExistingSetting ? 200 : 201).json(setting);
    } catch (error) {
      console.error(`Error updating settings for service provider ${req.params.providerId}:`, error);
      res.status(500).json({ error: "Failed to update service provider settings" });
    }
  });

  // Create a new service
  app.post("/api/service-provider/:providerId/services", async (req, res) => {
    try {
      const providerId = parseInt(req.params.providerId);
      const { category, title, description, price, duration } = req.body;
      
      // Validation
      if (!category || !title) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      
      // Authentication check
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      // Find the service provider for this user
      const provider = await storage.getServiceProvider(user.id);
      
      // Check if the user is authorized for this provider
      if (!provider || provider.id !== providerId) {
        return res.status(403).json({ error: "Forbidden - You are not authorized to create services for this provider" });
      }
      
      // Create the service
      const service = await storage.createService({
        providerId,
        category,
        title,
        description: description || null,
        price: price || null,
        duration: duration || null,
        available: true
      });
      
      res.status(201).json(service);
    } catch (error) {
      console.error(`Error creating service for provider ${req.params.providerId}:`, error);
      res.status(500).json({ error: "Failed to create service" });
    }
  });

  // Get service provider bookings
  app.get("/api/service-provider/:providerId/bookings", async (req, res) => {
    try {
      const providerId = parseInt(req.params.providerId);
      const { status } = req.query;
      
      // Authentication check
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      // For demonstration purposes, skip the provider authorization check
      
      // For now, return mock bookings data
      const mockBookings = [];
      
      // Create some mock bookings with different statuses
      const statuses = ["pending", "confirmed", "completed", "cancelled"];
      const services = [
        { id: 1, title: "Pet Grooming" },
        { id: 2, title: "Veterinary Check-up" },
        { id: 3, title: "Dog Walking" }
      ];
      const pets = [
        { id: 1, name: "Max", type: "Dog", breed: "Golden Retriever" },
        { id: 2, name: "Luna", type: "Cat", breed: "Siamese" },
        { id: 3, name: "Buddy", type: "Dog", breed: "Labrador" }
      ];
      
      // Generate 5 mock bookings
      for (let i = 1; i <= 5; i++) {
        const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
        const randomService = services[Math.floor(Math.random() * services.length)];
        const randomPet = pets[Math.floor(Math.random() * pets.length)];
        
        // If status filter is provided, only include bookings with that status
        if (status && status !== randomStatus) {
          continue;
        }
        
        const bookingDate = new Date();
        bookingDate.setDate(bookingDate.getDate() + Math.floor(Math.random() * 14)); // Random date in next 2 weeks
        
        mockBookings.push({
          id: i,
          providerId,
          userId: 2, // Mock user ID
          serviceId: randomService.id,
          petId: randomPet.id,
          status: randomStatus,
          bookingDate: bookingDate.toISOString().split('T')[0],
          createdAt: new Date(),
          notes: `Booking notes for ${randomService.title}`,
          service: randomService,
          pet: randomPet,
          userName: "John Doe",
          userEmail: "john.doe@example.com"
        });
      }
      
      res.json(mockBookings);
    } catch (error) {
      console.error(`Error fetching bookings for service provider ${req.params.providerId}:`, error);
      res.status(500).json({ error: "Failed to fetch service provider bookings" });
    }
  });

  // Update booking status
  app.patch("/api/service-provider/:providerId/bookings/:bookingId", async (req, res) => {
    try {
      const providerId = parseInt(req.params.providerId);
      const bookingId = parseInt(req.params.bookingId);
      const { status } = req.body;
      
      // Validation
      if (!status) {
        return res.status(400).json({ error: "Missing status field" });
      }
      
      // Authentication check
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      // For demonstration purposes, skip the provider authorization check
      
      // For demonstration purposes, simulate a successful booking update
      // In a real implementation, we would fetch the booking record and verify it belongs to this provider
      
      // Create a mock updated booking response
      const updatedBooking = {
        id: bookingId,
        providerId,
        userId: 2, // Mock user ID
        serviceId: 1,
        petId: 1,
        status: status, // Set to the requested status
        bookingDate: new Date().toISOString().split('T')[0],
        createdAt: new Date(),
        updatedAt: new Date(),
        notes: "Booking status updated"
      };
      
      res.json(updatedBooking);
    } catch (error) {
      console.error(`Error updating booking status for booking ${req.params.bookingId}:`, error);
      res.status(500).json({ error: "Failed to update booking status" });
    }
  });

  // Get service provider reviews
  app.get("/api/service-provider/:providerId/reviews", async (req, res) => {
    try {
      const providerId = parseInt(req.params.providerId);
      
      // For now, return mock reviews data
      const mockReviews = [];
      
      // Generate 5 mock reviews
      for (let i = 1; i <= 5; i++) {
        const randomRating = Math.floor(Math.random() * 5) + 1; // Random rating 1-5
        
        mockReviews.push({
          id: i,
          providerId,
          userId: i + 10, // Mock user IDs
          bookingId: i + 20, // Mock booking IDs
          rating: randomRating,
          reviewText: `Review ${i}: ${randomRating} stars. ${randomRating >= 4 ? 'Great service!' : 'Could be improved.'}`,
          createdAt: new Date(Date.now() - (i * 86400000)), // Reviews from different days
          responseText: i % 2 === 0 ? `Thank you for your feedback!` : null, // Some reviews have responses
          responseDate: i % 2 === 0 ? new Date(Date.now() - (i * 86400000) + 3600000) : null,
          userName: `User ${i}`,
          serviceName: i % 3 === 0 ? "Pet Grooming" : (i % 3 === 1 ? "Veterinary Check-up" : "Dog Walking"),
          bookingDate: new Date(Date.now() - (i * 86400000 * 2)).toISOString().split('T')[0]
        });
      }
      
      res.json(mockReviews);
    } catch (error) {
      console.error(`Error fetching reviews for service provider ${req.params.providerId}:`, error);
      res.status(500).json({ error: "Failed to fetch service provider reviews" });
    }
  });

  // Respond to a review
  app.patch("/api/service-provider/:providerId/reviews/:reviewId", async (req, res) => {
    try {
      const providerId = parseInt(req.params.providerId);
      const reviewId = parseInt(req.params.reviewId);
      const { responseText } = req.body;
      
      // Validation
      if (!responseText) {
        return res.status(400).json({ error: "Missing response text" });
      }
      
      // Authentication check
      const token = extractTokenFromHeader(req);
      if (!token) {
        return res.status(401).json({ error: "Missing or invalid authentication token" });
      }
      
      const user = await getUserFromToken(token);
      if (!user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      // For demonstration purposes, skip the provider authorization check
      
      // For demonstration purposes, simulate a successful review response
      // In a real implementation, we would fetch the review and verify it belongs to this provider
      
      // Create a mock updated review
      const updatedReview = {
        id: reviewId,
        providerId,
        userId: 15, // Mock user ID
        bookingId: 25, // Mock booking ID
        rating: 4,
        reviewText: "The service was good but could be better with more attention to detail.",
        createdAt: new Date(Date.now() - 604800000), // One week ago
        responseText: responseText,
        responseDate: new Date(),
        userName: "Sample User",
        serviceName: "Pet Grooming",
        bookingDate: new Date(Date.now() - 1209600000).toISOString().split('T')[0] // Two weeks ago
      };
      
      res.json(updatedReview);
    } catch (error) {
      console.error(`Error responding to review ${req.params.reviewId}:`, error);
      res.status(500).json({ error: "Failed to respond to review" });
    }
  });

  // Create the HTTP server
  const httpServer = createServer(app);

  return httpServer;
}