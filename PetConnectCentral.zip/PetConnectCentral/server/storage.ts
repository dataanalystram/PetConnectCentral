import { 
  users, User, InsertUser, 
  petOwners, PetOwner, InsertPetOwner,
  serviceProviders, ServiceProvider, InsertServiceProvider,
  shelters, Shelter, InsertShelter,
  pets, Pet, InsertPet,
  services, Service, InsertService,
  resources, Resource, InsertResource,
  favorites, Favorite, InsertFavorite,
  appointments, Appointment, InsertAppointment,
  petHealthRecords, PetHealthRecord, InsertPetHealthRecord,
  petVaccinations, PetVaccination, InsertPetVaccination,
  petMedications, PetMedication, InsertPetMedication,
  petWeightHistory, PetWeightHistory, InsertPetWeightHistory,
  petHealthMetrics, PetHealthMetric, InsertPetHealthMetric,
  userNotifications, UserNotification, InsertUserNotification,
  petCareReminders, PetCareReminder, InsertPetCareReminder,
  userConsents, UserConsent, InsertUserConsent,
  petDocuments, PetDocument, InsertPetDocument,
  petBehaviorRecords, PetBehaviorRecord, InsertPetBehaviorRecord,
  notificationPreferences, NotificationPreference, InsertNotificationPreference,
  reminderNotifications, ReminderNotification, InsertReminderNotification,
  UserType
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, asc, sql } from "drizzle-orm";
import session from "express-session";
import createMemoryStore from "memorystore";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

// Define a custom type for SessionStore since the imported type is incompatible
type SessionStore = ReturnType<typeof connectPg>;

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUserType(userId: number, userType: UserType): Promise<User>;
  updateUser(userId: number, userData: Partial<User>): Promise<User>;
  
  // Pet owner operations
  getPetOwner(userId: number): Promise<PetOwner | undefined>;
  createPetOwner(petOwner: InsertPetOwner): Promise<PetOwner>;
  updatePetOwner(petOwnerId: number, petOwnerData: Partial<PetOwner>): Promise<PetOwner>;
  
  // Service provider operations
  getServiceProvider(userId: number): Promise<ServiceProvider | undefined>;
  getServiceProviderById(providerId: number): Promise<ServiceProvider | undefined>;
  createServiceProvider(serviceProvider: InsertServiceProvider): Promise<ServiceProvider>;
  updateServiceProvider(providerId: number, providerData: Partial<ServiceProvider>): Promise<ServiceProvider>;
  getAllServiceProviders(): Promise<ServiceProvider[]>;
  getServiceProvidersByCategory(category: string): Promise<ServiceProvider[]>;
  
  // Provider settings operations
  getProviderSettings(providerId: number): Promise<ProviderSetting[]>;
  getProviderSettingByName(providerId: number, settingName: string): Promise<ProviderSetting | undefined>;
  createProviderSetting(setting: InsertProviderSetting): Promise<ProviderSetting>;
  updateProviderSetting(settingId: number, settingData: Partial<ProviderSetting>): Promise<ProviderSetting>;
  
  // Service bookings operations
  getServiceBooking(bookingId: number): Promise<ServiceBooking | undefined>;
  createServiceBooking(booking: InsertServiceBooking): Promise<ServiceBooking>;
  updateServiceBooking(bookingId: number, bookingData: Partial<ServiceBooking>): Promise<ServiceBooking>;
  getServiceBookingsByProviderId(providerId: number): Promise<ServiceBooking[]>;
  getServiceBookingsByUserId(userId: number): Promise<ServiceBooking[]>;
  getServiceBookingsByStatus(providerId: number, status: string): Promise<ServiceBooking[]>;
  
  // Service reviews operations
  getServiceReview(reviewId: number): Promise<ServiceReview | undefined>;
  createServiceReview(review: InsertServiceReview): Promise<ServiceReview>;
  updateServiceReview(reviewId: number, reviewData: Partial<ServiceReview>): Promise<ServiceReview>;
  getServiceReviewsByProviderId(providerId: number): Promise<ServiceReview[]>;
  getProviderAverageRating(providerId: number): Promise<number | null>;
  
  // Shelter operations
  getShelter(userId: number): Promise<Shelter | undefined>;
  createShelter(shelter: InsertShelter): Promise<Shelter>;
  updateShelter(shelterId: number, shelterData: Partial<Shelter>): Promise<Shelter>;
  getAllShelters(): Promise<Shelter[]>;
  
  // Pet operations
  getPet(id: number): Promise<Pet | undefined>;
  createPet(pet: InsertPet): Promise<Pet>;
  updatePet(id: number, petData: Partial<Pet>): Promise<Pet>;
  deletePet(id: number): Promise<void>;
  getAllPets(): Promise<Pet[]>;
  getPetsByShelterId(shelterId: number): Promise<Pet[]>;
  getFeaturedPets(): Promise<Pet[]>;
  searchPets(filters: { type?: string; breed?: string; age?: number; size?: string }): Promise<Pet[]>;
  
  // Service operations
  getService(id: number): Promise<Service | undefined>;
  createService(service: InsertService): Promise<Service>;
  getServicesByProviderId(providerId: number): Promise<Service[]>;
  getServicesByCategory(category: string): Promise<Service[]>;
  getAllServices(): Promise<Service[]>;
  
  // Resource operations
  getResource(id: number): Promise<Resource | undefined>;
  createResource(resource: InsertResource): Promise<Resource>;
  getAllResources(): Promise<Resource[]>;
  getResourcesByCategory(category: string): Promise<Resource[]>;
  
  // Favorites operations
  getFavorite(id: number): Promise<Favorite | undefined>;
  createFavorite(favorite: InsertFavorite): Promise<Favorite>;
  getFavoritesByPetOwnerId(petOwnerId: number): Promise<Favorite[]>;
  getIsFavorite(petOwnerId: number, petId: number): Promise<boolean>;
  deleteFavorite(id: number): Promise<void>;
  
  // Appointment operations
  getAppointment(id: number): Promise<Appointment | undefined>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  getAppointmentsByUserId(userId: number): Promise<Appointment[]>;
  getAppointmentsByPetId(petId: number): Promise<Appointment[]>;
  getAppointmentsByShelterId(shelterId: number): Promise<Appointment[]>;
  getAppointmentsByProviderId(providerId: number): Promise<Appointment[]>;
  updateAppointmentStatus(id: number, status: string): Promise<Appointment>;
  
  // Pet Health Record operations
  getPetHealthRecord(id: number): Promise<PetHealthRecord | undefined>;
  createPetHealthRecord(record: InsertPetHealthRecord): Promise<PetHealthRecord>;
  updatePetHealthRecord(id: number, recordData: Partial<PetHealthRecord>): Promise<PetHealthRecord>;
  getPetHealthRecordsByPetId(petId: number): Promise<PetHealthRecord[]>;
  deletePetHealthRecord(id: number): Promise<void>;
  
  // Pet Vaccination operations
  getPetVaccination(id: number): Promise<PetVaccination | undefined>;
  createPetVaccination(vaccination: InsertPetVaccination): Promise<PetVaccination>;
  updatePetVaccination(id: number, vaccinationData: Partial<PetVaccination>): Promise<PetVaccination>;
  getPetVaccinationsByPetId(petId: number): Promise<PetVaccination[]>;
  getUpcomingVaccinations(days: number): Promise<PetVaccination[]>;
  
  // Pet Medication operations
  getPetMedication(id: number): Promise<PetMedication | undefined>;
  createPetMedication(medication: InsertPetMedication): Promise<PetMedication>;
  updatePetMedication(id: number, medicationData: Partial<PetMedication>): Promise<PetMedication>;
  getPetMedicationsByPetId(petId: number): Promise<PetMedication[]>;
  getActiveMedications(): Promise<PetMedication[]>;
  
  // Pet Weight History operations
  getPetWeightHistory(id: number): Promise<PetWeightHistory | undefined>;
  createPetWeightHistory(weightRecord: InsertPetWeightHistory): Promise<PetWeightHistory>;
  getPetWeightHistoryByPetId(petId: number): Promise<PetWeightHistory[]>;
  
  // User Notification operations
  getUserNotification(id: number): Promise<UserNotification | undefined>;
  createUserNotification(notification: InsertUserNotification): Promise<UserNotification>;
  getUserNotificationsByUserId(userId: number): Promise<UserNotification[]>;
  getUnreadNotificationsByUserId(userId: number): Promise<UserNotification[]>;
  markNotificationAsRead(id: number): Promise<UserNotification>;
  deleteNotification(id: number): Promise<void>;
  
  // Pet Care Reminder operations
  getPetCareReminder(id: number): Promise<PetCareReminder | undefined>;
  createPetCareReminder(reminder: InsertPetCareReminder): Promise<PetCareReminder>;
  updatePetCareReminder(id: number, reminderData: Partial<PetCareReminder>): Promise<PetCareReminder>;
  getPetCareRemindersByPetId(petId: number): Promise<PetCareReminder[]>;
  getPetCareRemindersByUserId(userId: number): Promise<PetCareReminder[]>;
  getActivePetCareReminders(): Promise<PetCareReminder[]>;
  markReminderAsCompleted(id: number): Promise<PetCareReminder>;
  
  // User Consent operations
  getUserConsent(id: number): Promise<UserConsent | undefined>;
  createUserConsent(consent: InsertUserConsent): Promise<UserConsent>;
  getUserConsentsByUserId(userId: number): Promise<UserConsent[]>;
  getUserConsentByType(userId: number, consentType: string): Promise<UserConsent | undefined>;
  updateUserConsent(id: number, isGranted: boolean): Promise<UserConsent>;
  
  // Pet Document operations
  getPetDocument(id: number): Promise<PetDocument | undefined>;
  createPetDocument(document: InsertPetDocument): Promise<PetDocument>;
  getPetDocumentsByPetId(petId: number): Promise<PetDocument[]>;
  getPetDocumentsByHealthRecordId(healthRecordId: number): Promise<PetDocument[]>;
  markDocumentAsVerified(id: number, verifiedBy: string): Promise<PetDocument>;
  
  // Pet Behavior Record operations
  getPetBehaviorRecord(id: number): Promise<PetBehaviorRecord | undefined>;
  createPetBehaviorRecord(record: InsertPetBehaviorRecord): Promise<PetBehaviorRecord>;
  updatePetBehaviorRecord(id: number, recordData: Partial<PetBehaviorRecord>): Promise<PetBehaviorRecord>;
  getPetBehaviorRecordsByPetId(petId: number): Promise<PetBehaviorRecord[]>;
  softDeletePetBehaviorRecord(id: number): Promise<PetBehaviorRecord>;
  
  // Pet Weight History operations
  getPetWeightHistory(id: number): Promise<PetWeightHistory | undefined>;
  createPetWeightHistory(record: InsertPetWeightHistory): Promise<PetWeightHistory>;
  getPetWeightHistoryByPetId(petId: number): Promise<PetWeightHistory[]>;
  
  // Pet Health Metrics operations
  getPetHealthMetric(id: number): Promise<PetHealthMetric | undefined>;
  createPetHealthMetric(metric: InsertPetHealthMetric): Promise<PetHealthMetric>;
  getPetHealthMetricsByPetId(petId: number): Promise<PetHealthMetric[]>;
  getPetHealthMetricsByType(petId: number, metricType: string): Promise<PetHealthMetric[]>;
  updatePetHealthMetric(id: number, metricData: Partial<PetHealthMetric>): Promise<PetHealthMetric>;
  softDeletePetHealthMetric(id: number): Promise<PetHealthMetric>;
  
  // Notification Preferences operations
  getNotificationPreference(id: number): Promise<NotificationPreference | undefined>;
  createNotificationPreference(preference: InsertNotificationPreference): Promise<NotificationPreference>;
  getNotificationPreferencesByUserId(userId: number): Promise<NotificationPreference[]>;
  updateNotificationPreference(id: number, preferenceData: Partial<NotificationPreference>): Promise<NotificationPreference>;
  
  // Reminder Notifications operations
  getReminderNotification(id: number): Promise<ReminderNotification | undefined>;
  createReminderNotification(notification: InsertReminderNotification): Promise<ReminderNotification>;
  getReminderNotificationsByReminderId(reminderId: number): Promise<ReminderNotification[]>;
  getReminderNotificationsByUserId(userId: number): Promise<ReminderNotification[]>;
  updateReminderNotificationStatus(id: number, status: string): Promise<ReminderNotification>;
  
  // Notification Preferences operations
  getNotificationPreference(id: number): Promise<NotificationPreference | undefined>;
  createNotificationPreference(preference: InsertNotificationPreference): Promise<NotificationPreference>;
  getNotificationPreferencesByUserId(userId: number): Promise<NotificationPreference[]>;
  updateNotificationPreference(id: number, preferenceData: Partial<NotificationPreference>): Promise<NotificationPreference>;
  
  // Reminder Notifications operations
  getReminderNotification(id: number): Promise<ReminderNotification | undefined>;
  createReminderNotification(notification: InsertReminderNotification): Promise<ReminderNotification>;
  getReminderNotificationsByReminderId(reminderId: number): Promise<ReminderNotification[]>;
  getReminderNotificationsByUserId(userId: number): Promise<ReminderNotification[]>;
  
  // GDPR compliance related operations
  deleteUser(id: number): Promise<void>;
  deleteService(id: number): Promise<void>;
  getPetsByOwnerId(userId: number): Promise<Pet[]>;
  
  // Session store
  sessionStore: any; // Using 'any' to resolve SessionStore compatibility issues
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private petOwners: Map<number, PetOwner>;
  private serviceProviders: Map<number, ServiceProvider>;
  private shelters: Map<number, Shelter>;
  private pets: Map<number, Pet>;
  private services: Map<number, Service>;
  private resources: Map<number, Resource>;
  private favorites: Map<number, Favorite>;
  private appointments: Map<number, Appointment>;
  private petHealthRecords: Map<number, PetHealthRecord>;
  private petVaccinations: Map<number, PetVaccination>;
  private petMedications: Map<number, PetMedication>;
  private petWeightHistory: Map<number, PetWeightHistory>;
  private petHealthMetrics: Map<number, PetHealthMetric>;
  private userNotifications: Map<number, UserNotification>;
  private petCareReminders: Map<number, PetCareReminder>;
  private userConsents: Map<number, UserConsent>;
  private petDocuments: Map<number, PetDocument>;
  private petBehaviorRecords: Map<number, PetBehaviorRecord>;
  private notificationPreferences: Map<number, NotificationPreference>;
  private reminderNotifications: Map<number, ReminderNotification>;
  // Service provider specific maps
  private providerSettings: Map<number, ProviderSetting>;
  private complianceChecks: Map<number, ComplianceCheck>;
  private regulatoryUpdates: Map<number, RegulatoryUpdate>;
  private providerRegulatoryAcknowledgements: Map<number, ProviderRegulatoryAcknowledgement>;
  private providerDataProcessingRecords: Map<number, ProviderDataProcessingRecord>;
  private serviceBookings: Map<number, ServiceBooking>;
  private serviceReviews: Map<number, ServiceReview>;
  
  currentId: number;
  sessionStore: any; // Using 'any' to resolve SessionStore compatibility issues

  constructor() {
    this.users = new Map();
    this.petOwners = new Map();
    this.serviceProviders = new Map();
    this.shelters = new Map();
    this.pets = new Map();
    this.services = new Map();
    this.resources = new Map();
    this.favorites = new Map();
    this.appointments = new Map();
    this.petHealthRecords = new Map();
    this.petVaccinations = new Map();
    this.petMedications = new Map();
    this.petWeightHistory = new Map();
    this.petHealthMetrics = new Map();
    this.userNotifications = new Map();
    this.petCareReminders = new Map();
    this.userConsents = new Map();
    this.petDocuments = new Map();
    this.petBehaviorRecords = new Map();
    this.notificationPreferences = new Map();
    this.reminderNotifications = new Map();
    // Service provider specific maps initialization
    this.providerSettings = new Map();
    this.complianceChecks = new Map();
    this.regulatoryUpdates = new Map();
    this.providerRegulatoryAcknowledgements = new Map();
    this.providerDataProcessingRecords = new Map();
    this.serviceBookings = new Map();
    this.serviceReviews = new Map();
    
    this.currentId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24 hours
    });

    // Add some initial resources
    this.initializeResources();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email
    );
  }
  
  async getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.firebaseUid === firebaseUid
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const createdAt = new Date();
    const user: User = { ...insertUser, id, createdAt };
    this.users.set(id, user);
    return user;
  }
  
  async updateUserType(userId: number, userType: UserType): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    const updatedUser = { ...user, userType };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }
  
  async updateUser(userId: number, userData: Partial<User>): Promise<User> {
    const user = await this.getUser(userId);
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    const updatedUser = { ...user, ...userData };
    this.users.set(userId, updatedUser);
    return updatedUser;
  }

  // Pet owner operations
  async getPetOwner(userId: number): Promise<PetOwner | undefined> {
    return Array.from(this.petOwners.values()).find(
      (po) => po.userId === userId
    );
  }

  async createPetOwner(insertPetOwner: InsertPetOwner): Promise<PetOwner> {
    const id = this.currentId++;
    const petOwner: PetOwner = { ...insertPetOwner, id };
    this.petOwners.set(id, petOwner);
    return petOwner;
  }
  
  async updatePetOwner(petOwnerId: number, petOwnerData: Partial<PetOwner>): Promise<PetOwner> {
    const petOwner = this.petOwners.get(petOwnerId);
    if (!petOwner) {
      throw new Error(`Pet owner with ID ${petOwnerId} not found`);
    }
    
    const updatedPetOwner = { ...petOwner, ...petOwnerData };
    this.petOwners.set(petOwnerId, updatedPetOwner);
    return updatedPetOwner;
  }

  // Service provider operations
  async getServiceProvider(userId: number): Promise<ServiceProvider | undefined> {
    return Array.from(this.serviceProviders.values()).find(
      (sp) => sp.userId === userId
    );
  }

  async getServiceProviderById(providerId: number): Promise<ServiceProvider | undefined> {
    return this.serviceProviders.get(providerId);
  }

  async createServiceProvider(insertServiceProvider: InsertServiceProvider): Promise<ServiceProvider> {
    const id = this.currentId++;
    const serviceProvider: ServiceProvider = { ...insertServiceProvider, id };
    this.serviceProviders.set(id, serviceProvider);
    return serviceProvider;
  }
  
  async updateServiceProvider(providerId: number, providerData: Partial<ServiceProvider>): Promise<ServiceProvider> {
    const provider = this.serviceProviders.get(providerId);
    if (!provider) {
      throw new Error(`Service provider with ID ${providerId} not found`);
    }
    
    const updatedProvider = { ...provider, ...providerData };
    this.serviceProviders.set(providerId, updatedProvider);
    return updatedProvider;
  }

  async getAllServiceProviders(): Promise<ServiceProvider[]> {
    return Array.from(this.serviceProviders.values());
  }

  async getServiceProvidersByCategory(category: string): Promise<ServiceProvider[]> {
    return Array.from(this.serviceProviders.values()).filter(
      (sp) => sp.category === category
    );
  }
  
  // Provider settings operations
  async getProviderSettings(providerId: number): Promise<ProviderSetting[]> {
    return Array.from(this.providerSettings.values()).filter(
      (setting) => setting.providerId === providerId
    );
  }
  
  async getProviderSettingByName(providerId: number, settingName: string): Promise<ProviderSetting | undefined> {
    return Array.from(this.providerSettings.values()).find(
      (setting) => setting.providerId === providerId && setting.settingName === settingName
    );
  }
  
  async createProviderSetting(insertSetting: InsertProviderSetting): Promise<ProviderSetting> {
    const id = this.currentId++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const setting: ProviderSetting = { ...insertSetting, id, createdAt, updatedAt };
    this.providerSettings.set(id, setting);
    return setting;
  }
  
  async updateProviderSetting(settingId: number, settingData: Partial<ProviderSetting>): Promise<ProviderSetting> {
    const setting = this.providerSettings.get(settingId);
    if (!setting) {
      throw new Error(`Provider setting with ID ${settingId} not found`);
    }
    
    const updatedSetting = { ...setting, ...settingData, updatedAt: new Date() };
    this.providerSettings.set(settingId, updatedSetting);
    return updatedSetting;
  }
  
  // Service bookings operations
  async getServiceBooking(bookingId: number): Promise<ServiceBooking | undefined> {
    return this.serviceBookings.get(bookingId);
  }
  
  async createServiceBooking(insertBooking: InsertServiceBooking): Promise<ServiceBooking> {
    const id = this.currentId++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const booking: ServiceBooking = { ...insertBooking, id, createdAt, updatedAt };
    this.serviceBookings.set(id, booking);
    return booking;
  }
  
  async updateServiceBooking(bookingId: number, bookingData: Partial<ServiceBooking>): Promise<ServiceBooking> {
    const booking = this.serviceBookings.get(bookingId);
    if (!booking) {
      throw new Error(`Service booking with ID ${bookingId} not found`);
    }
    
    const updatedBooking = { ...booking, ...bookingData, updatedAt: new Date() };
    this.serviceBookings.set(bookingId, updatedBooking);
    return updatedBooking;
  }
  
  async getServiceBookingsByProviderId(providerId: number): Promise<ServiceBooking[]> {
    return Array.from(this.serviceBookings.values()).filter(
      (booking) => booking.providerId === providerId
    ).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async getServiceBookingsByUserId(userId: number): Promise<ServiceBooking[]> {
    return Array.from(this.serviceBookings.values()).filter(
      (booking) => booking.userId === userId
    ).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async getServiceBookingsByStatus(providerId: number, status: string): Promise<ServiceBooking[]> {
    return Array.from(this.serviceBookings.values()).filter(
      (booking) => booking.providerId === providerId && booking.status === status
    ).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  // Service reviews operations
  async getServiceReview(reviewId: number): Promise<ServiceReview | undefined> {
    return this.serviceReviews.get(reviewId);
  }
  
  async createServiceReview(insertReview: InsertServiceReview): Promise<ServiceReview> {
    const id = this.currentId++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const review: ServiceReview = { ...insertReview, id, createdAt, updatedAt };
    this.serviceReviews.set(id, review);
    return review;
  }
  
  async updateServiceReview(reviewId: number, reviewData: Partial<ServiceReview>): Promise<ServiceReview> {
    const review = this.serviceReviews.get(reviewId);
    if (!review) {
      throw new Error(`Service review with ID ${reviewId} not found`);
    }
    
    const updatedReview = { ...review, ...reviewData, updatedAt: new Date() };
    this.serviceReviews.set(reviewId, updatedReview);
    return updatedReview;
  }
  
  async getServiceReviewsByProviderId(providerId: number): Promise<ServiceReview[]> {
    return Array.from(this.serviceReviews.values()).filter(
      (review) => review.providerId === providerId
    ).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async getProviderAverageRating(providerId: number): Promise<number | null> {
    const reviews = await this.getServiceReviewsByProviderId(providerId);
    if (reviews.length === 0) {
      return null;
    }
    
    const totalRating = reviews.reduce((sum, review) => sum + review.rating, 0);
    return totalRating / reviews.length;
  }

  // Shelter operations
  async getShelter(userId: number): Promise<Shelter | undefined> {
    return Array.from(this.shelters.values()).find(
      (shelter) => shelter.userId === userId
    );
  }

  async createShelter(insertShelter: InsertShelter): Promise<Shelter> {
    const id = this.currentId++;
    const shelter: Shelter = { ...insertShelter, id };
    this.shelters.set(id, shelter);
    return shelter;
  }
  
  async updateShelter(shelterId: number, shelterData: Partial<Shelter>): Promise<Shelter> {
    const shelter = this.shelters.get(shelterId);
    if (!shelter) {
      throw new Error(`Shelter with ID ${shelterId} not found`);
    }
    
    const updatedShelter = { ...shelter, ...shelterData };
    this.shelters.set(shelterId, updatedShelter);
    return updatedShelter;
  }

  async getAllShelters(): Promise<Shelter[]> {
    return Array.from(this.shelters.values());
  }

  // Pet operations
  async getPet(id: number): Promise<Pet | undefined> {
    return this.pets.get(id);
  }

  async createPet(insertPet: InsertPet): Promise<Pet> {
    const id = this.currentId++;
    const createdAt = new Date();
    const pet: Pet = { ...insertPet, id, createdAt };
    this.pets.set(id, pet);
    return pet;
  }
  
  async updatePet(id: number, petData: Partial<Pet>): Promise<Pet> {
    const pet = this.pets.get(id);
    if (!pet) {
      throw new Error(`Pet with ID ${id} not found`);
    }
    
    const updatedPet = { ...pet, ...petData };
    this.pets.set(id, updatedPet);
    return updatedPet;
  }
  
  async deletePet(id: number): Promise<void> {
    if (!this.pets.has(id)) {
      throw new Error(`Pet with ID ${id} not found`);
    }
    
    this.pets.delete(id);
  }

  async getAllPets(): Promise<Pet[]> {
    return Array.from(this.pets.values());
  }

  async getPetsByShelterId(shelterId: number): Promise<Pet[]> {
    return Array.from(this.pets.values()).filter(
      (pet) => pet.shelterId === shelterId
    );
  }
  
  async getFeaturedPets(): Promise<Pet[]> {
    return Array.from(this.pets.values()).filter(
      (pet) => pet.isFeatured === true
    );
  }
  
  async searchPets(filters: { type?: string; breed?: string; age?: number; size?: string }): Promise<Pet[]> {
    let filteredPets = Array.from(this.pets.values());
    
    if (filters.type) {
      filteredPets = filteredPets.filter(pet => pet.type === filters.type);
    }
    
    if (filters.breed) {
      filteredPets = filteredPets.filter(pet => pet.breed === filters.breed);
    }
    
    if (filters.age) {
      filteredPets = filteredPets.filter(pet => pet.age === filters.age);
    }
    
    if (filters.size) {
      filteredPets = filteredPets.filter(pet => pet.size === filters.size);
    }
    
    return filteredPets;
  }

  // Service operations
  async getService(id: number): Promise<Service | undefined> {
    return this.services.get(id);
  }

  async createService(insertService: InsertService): Promise<Service> {
    const id = this.currentId++;
    const createdAt = new Date();
    const service: Service = { ...insertService, id, createdAt };
    this.services.set(id, service);
    return service;
  }

  async getServicesByProviderId(providerId: number): Promise<Service[]> {
    return Array.from(this.services.values()).filter(
      (service) => service.providerId === providerId
    );
  }

  async getServicesByCategory(category: string): Promise<Service[]> {
    return Array.from(this.services.values()).filter(
      (service) => service.category === category
    );
  }

  async getAllServices(): Promise<Service[]> {
    return Array.from(this.services.values());
  }

  // Resource operations
  async getResource(id: number): Promise<Resource | undefined> {
    return this.resources.get(id);
  }

  async createResource(insertResource: InsertResource): Promise<Resource> {
    const id = this.currentId++;
    const createdAt = new Date();
    const resource: Resource = { ...insertResource, id, createdAt };
    this.resources.set(id, resource);
    return resource;
  }

  async getAllResources(): Promise<Resource[]> {
    return Array.from(this.resources.values());
  }

  async getResourcesByCategory(category: string): Promise<Resource[]> {
    return Array.from(this.resources.values()).filter(
      (resource) => resource.category === category
    );
  }
  
  // Favorites operations
  async getFavorite(id: number): Promise<Favorite | undefined> {
    return this.favorites.get(id);
  }
  
  async createFavorite(insertFavorite: InsertFavorite): Promise<Favorite> {
    const id = this.currentId++;
    const createdAt = new Date();
    const favorite: Favorite = { ...insertFavorite, id, createdAt };
    this.favorites.set(id, favorite);
    return favorite;
  }
  
  async getFavoritesByPetOwnerId(petOwnerId: number): Promise<Favorite[]> {
    return Array.from(this.favorites.values()).filter(
      (favorite) => favorite.petOwnerId === petOwnerId
    );
  }
  
  async getIsFavorite(petOwnerId: number, petId: number): Promise<boolean> {
    const favorite = Array.from(this.favorites.values()).find(
      (favorite) => favorite.petOwnerId === petOwnerId && favorite.petId === petId
    );
    return favorite !== undefined;
  }
  
  async deleteFavorite(id: number): Promise<void> {
    this.favorites.delete(id);
  }
  
  // Appointment operations
  async getAppointment(id: number): Promise<Appointment | undefined> {
    return this.appointments.get(id);
  }
  
  async createAppointment(insertAppointment: InsertAppointment): Promise<Appointment> {
    const id = this.currentId++;
    const createdAt = new Date();
    const appointment: Appointment = { ...insertAppointment, id, createdAt };
    this.appointments.set(id, appointment);
    return appointment;
  }
  
  async getAppointmentsByUserId(userId: number): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      (appointment) => appointment.userId === userId
    );
  }
  
  async getAppointmentsByPetId(petId: number): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      (appointment) => appointment.petId === petId
    );
  }
  
  async getAppointmentsByShelterId(shelterId: number): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      (appointment) => appointment.shelterId === shelterId
    );
  }
  
  async getAppointmentsByProviderId(providerId: number): Promise<Appointment[]> {
    return Array.from(this.appointments.values()).filter(
      (appointment) => appointment.providerId === providerId
    );
  }
  
  async updateAppointmentStatus(id: number, status: string): Promise<Appointment> {
    const appointment = await this.getAppointment(id);
    if (!appointment) {
      throw new Error(`Appointment with ID ${id} not found`);
    }
    
    const updatedAppointment = { ...appointment, status };
    this.appointments.set(id, updatedAppointment);
    return updatedAppointment;
  }
  
  // Pet Health Record operations
  async getPetHealthRecord(id: number): Promise<PetHealthRecord | undefined> {
    return this.petHealthRecords.get(id);
  }
  
  async createPetHealthRecord(insertRecord: InsertPetHealthRecord): Promise<PetHealthRecord> {
    const id = this.currentId++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const petHealthRecord: PetHealthRecord = { ...insertRecord, id, createdAt, updatedAt };
    this.petHealthRecords.set(id, petHealthRecord);
    return petHealthRecord;
  }
  
  async updatePetHealthRecord(id: number, recordData: Partial<PetHealthRecord>): Promise<PetHealthRecord> {
    const record = this.petHealthRecords.get(id);
    if (!record) {
      throw new Error(`Pet health record with ID ${id} not found`);
    }
    
    const updatedRecord = { ...record, ...recordData, updatedAt: new Date() };
    this.petHealthRecords.set(id, updatedRecord);
    return updatedRecord;
  }
  
  async getPetHealthRecordsByPetId(petId: number): Promise<PetHealthRecord[]> {
    return Array.from(this.petHealthRecords.values()).filter(
      (record) => record.petId === petId
    );
  }
  
  async deletePetHealthRecord(id: number): Promise<void> {
    if (!this.petHealthRecords.has(id)) {
      throw new Error(`Pet health record with ID ${id} not found`);
    }
    
    this.petHealthRecords.delete(id);
  }
  
  // Pet Vaccination operations
  async getPetVaccination(id: number): Promise<PetVaccination | undefined> {
    return this.petVaccinations.get(id);
  }
  
  async createPetVaccination(insertVaccination: InsertPetVaccination): Promise<PetVaccination> {
    const id = this.currentId++;
    const createdAt = new Date();
    const petVaccination: PetVaccination = { ...insertVaccination, id, createdAt };
    this.petVaccinations.set(id, petVaccination);
    return petVaccination;
  }
  
  async updatePetVaccination(id: number, vaccinationData: Partial<PetVaccination>): Promise<PetVaccination> {
    const vaccination = this.petVaccinations.get(id);
    if (!vaccination) {
      throw new Error(`Pet vaccination with ID ${id} not found`);
    }
    
    const updatedVaccination = { ...vaccination, ...vaccinationData };
    this.petVaccinations.set(id, updatedVaccination);
    return updatedVaccination;
  }
  
  async getPetVaccinationsByPetId(petId: number): Promise<PetVaccination[]> {
    return Array.from(this.petVaccinations.values()).filter(
      (vaccination) => vaccination.petId === petId
    );
  }
  
  async getUpcomingVaccinations(days: number): Promise<PetVaccination[]> {
    const now = new Date();
    const futureDate = new Date();
    futureDate.setDate(now.getDate() + days);
    
    return Array.from(this.petVaccinations.values()).filter(
      (vaccination) => {
        if (!vaccination.dueDate) return false;
        const dueDate = new Date(vaccination.dueDate);
        return dueDate >= now && dueDate <= futureDate;
      }
    );
  }
  
  // Pet Medication operations
  async getPetMedication(id: number): Promise<PetMedication | undefined> {
    return this.petMedications.get(id);
  }
  
  async createPetMedication(insertMedication: InsertPetMedication): Promise<PetMedication> {
    const id = this.currentId++;
    const createdAt = new Date();
    const petMedication: PetMedication = { ...insertMedication, id, createdAt };
    this.petMedications.set(id, petMedication);
    return petMedication;
  }
  
  async updatePetMedication(id: number, medicationData: Partial<PetMedication>): Promise<PetMedication> {
    const medication = this.petMedications.get(id);
    if (!medication) {
      throw new Error(`Pet medication with ID ${id} not found`);
    }
    
    const updatedMedication = { ...medication, ...medicationData };
    this.petMedications.set(id, updatedMedication);
    return updatedMedication;
  }
  
  async getPetMedicationsByPetId(petId: number): Promise<PetMedication[]> {
    return Array.from(this.petMedications.values()).filter(
      (medication) => medication.petId === petId
    );
  }
  
  async getActiveMedications(): Promise<PetMedication[]> {
    const today = new Date();
    
    return Array.from(this.petMedications.values()).filter(
      (medication) => {
        const startDate = new Date(medication.startDate);
        const endDate = medication.endDate ? new Date(medication.endDate) : null;
        
        return startDate <= today && (!endDate || endDate >= today);
      }
    );
  }
  
  // Pet Weight History operations
  async getPetWeightHistory(id: number): Promise<PetWeightHistory | undefined> {
    return this.petWeightHistory.get(id);
  }
  
  async createPetWeightHistory(insertWeightRecord: InsertPetWeightHistory): Promise<PetWeightHistory> {
    const id = this.currentId++;
    const createdAt = new Date();
    const petWeightRecord: PetWeightHistory = { ...insertWeightRecord, id, createdAt };
    this.petWeightHistory.set(id, petWeightRecord);
    return petWeightRecord;
  }
  
  async getPetWeightHistoryByPetId(petId: number): Promise<PetWeightHistory[]> {
    return Array.from(this.petWeightHistory.values())
      .filter(record => record.petId === petId)
      .sort((a, b) => new Date(b.recordDate).getTime() - new Date(a.recordDate).getTime());
  }
  
  // Pet Health Metrics operations
  async getPetHealthMetric(id: number): Promise<PetHealthMetric | undefined> {
    return this.petHealthMetrics.get(id);
  }
  
  async createPetHealthMetric(insertMetric: InsertPetHealthMetric): Promise<PetHealthMetric> {
    const id = this.currentId++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const isDeleted = false;
    const petHealthMetric: PetHealthMetric = { 
      ...insertMetric, 
      id, 
      createdAt, 
      updatedAt, 
      isDeleted: isDeleted,
      notes: insertMetric.notes ?? null,
      healthRecordId: insertMetric.healthRecordId ?? null,
      recordTime: insertMetric.recordTime ?? null,
      createdBy: insertMetric.createdBy ?? null
    };
    this.petHealthMetrics.set(id, petHealthMetric);
    return petHealthMetric;
  }
  
  async getPetHealthMetricsByPetId(petId: number): Promise<PetHealthMetric[]> {
    return Array.from(this.petHealthMetrics.values())
      .filter(metric => metric.petId === petId && !metric.isDeleted)
      .sort((a, b) => new Date(b.recordDate).getTime() - new Date(a.recordDate).getTime());
  }
  
  async getPetHealthMetricsByType(petId: number, metricType: string): Promise<PetHealthMetric[]> {
    return Array.from(this.petHealthMetrics.values())
      .filter(metric => metric.petId === petId && metric.metricType === metricType && !metric.isDeleted)
      .sort((a, b) => new Date(b.recordDate).getTime() - new Date(a.recordDate).getTime());
  }
  
  async updatePetHealthMetric(id: number, metricData: Partial<PetHealthMetric>): Promise<PetHealthMetric> {
    const metric = this.petHealthMetrics.get(id);
    if (!metric) {
      throw new Error(`Pet health metric with ID ${id} not found`);
    }
    
    const updatedMetric = { ...metric, ...metricData, updatedAt: new Date() };
    this.petHealthMetrics.set(id, updatedMetric);
    return updatedMetric;
  }
  
  async softDeletePetHealthMetric(id: number): Promise<PetHealthMetric> {
    const metric = this.petHealthMetrics.get(id);
    if (!metric) {
      throw new Error(`Pet health metric with ID ${id} not found`);
    }
    
    const updatedMetric = { ...metric, isDeleted: true, updatedAt: new Date() };
    this.petHealthMetrics.set(id, updatedMetric);
    return updatedMetric;
  }
  
  // Notification Preferences operations
  async getNotificationPreference(id: number): Promise<NotificationPreference | undefined> {
    return this.notificationPreferences.get(id);
  }
  
  async createNotificationPreference(insertPreference: InsertNotificationPreference): Promise<NotificationPreference> {
    const id = this.currentId++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const notificationPreference: NotificationPreference = { ...insertPreference, id, createdAt, updatedAt };
    this.notificationPreferences.set(id, notificationPreference);
    return notificationPreference;
  }
  
  async getNotificationPreferencesByUserId(userId: number): Promise<NotificationPreference[]> {
    return Array.from(this.notificationPreferences.values())
      .filter(preference => preference.userId === userId);
  }
  
  async updateNotificationPreference(id: number, preferenceData: Partial<NotificationPreference>): Promise<NotificationPreference> {
    const preference = this.notificationPreferences.get(id);
    if (!preference) {
      throw new Error(`Notification preference with ID ${id} not found`);
    }
    
    const updatedPreference = { ...preference, ...preferenceData, updatedAt: new Date() };
    this.notificationPreferences.set(id, updatedPreference);
    return updatedPreference;
  }
  
  // Reminder Notifications operations
  async getReminderNotification(id: number): Promise<ReminderNotification | undefined> {
    return this.reminderNotifications.get(id);
  }
  
  async createReminderNotification(insertNotification: InsertReminderNotification): Promise<ReminderNotification> {
    const id = this.currentId++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const reminderNotification: ReminderNotification = { 
      ...insertNotification, 
      id, 
      createdAt, 
      updatedAt,
      status: insertNotification.status ?? null,
      sentAt: insertNotification.sentAt ?? null 
    };
    this.reminderNotifications.set(id, reminderNotification);
    return reminderNotification;
  }
  
  async getReminderNotificationsByReminderId(reminderId: number): Promise<ReminderNotification[]> {
    return Array.from(this.reminderNotifications.values())
      .filter(notification => notification.reminderId === reminderId);
  }
  
  async getReminderNotificationsByUserId(userId: number): Promise<ReminderNotification[]> {
    return Array.from(this.reminderNotifications.values())
      .filter(notification => notification.userId === userId);
  }
  
  async updateReminderNotificationStatus(id: number, status: string): Promise<ReminderNotification> {
    const notification = this.reminderNotifications.get(id);
    if (!notification) {
      throw new Error(`Reminder notification with ID ${id} not found`);
    }
    
    const updatedNotification = { ...notification, status, updatedAt: new Date() };
    this.reminderNotifications.set(id, updatedNotification);
    return updatedNotification;
  }
  
  // User Notification operations
  async getUserNotification(id: number): Promise<UserNotification | undefined> {
    return this.userNotifications.get(id);
  }
  
  async createUserNotification(insertNotification: InsertUserNotification): Promise<UserNotification> {
    const id = this.currentId++;
    const createdAt = new Date();
    const notification: UserNotification = { 
      ...insertNotification, 
      id, 
      createdAt, 
      isRead: false,
      actionUrl: insertNotification.actionUrl ?? null,
      expiresAt: insertNotification.expiresAt ?? null
    };
    this.userNotifications.set(id, notification);
    return notification;
  }
  
  async getUserNotificationsByUserId(userId: number): Promise<UserNotification[]> {
    return Array.from(this.userNotifications.values())
      .filter(notification => notification.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async getUnreadNotificationsByUserId(userId: number): Promise<UserNotification[]> {
    return Array.from(this.userNotifications.values())
      .filter(notification => notification.userId === userId && !notification.isRead)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async markNotificationAsRead(id: number): Promise<UserNotification> {
    const notification = this.userNotifications.get(id);
    if (!notification) {
      throw new Error(`Notification with ID ${id} not found`);
    }
    
    const updatedNotification = { ...notification, isRead: true };
    this.userNotifications.set(id, updatedNotification);
    return updatedNotification;
  }
  
  async deleteNotification(id: number): Promise<void> {
    if (!this.userNotifications.has(id)) {
      throw new Error(`Notification with ID ${id} not found`);
    }
    
    this.userNotifications.delete(id);
  }
  
  // Pet Care Reminder operations
  async getPetCareReminder(id: number): Promise<PetCareReminder | undefined> {
    return this.petCareReminders.get(id);
  }
  
  async createPetCareReminder(insertReminder: InsertPetCareReminder): Promise<PetCareReminder> {
    const id = this.currentId++;
    const createdAt = new Date();
    const reminder: PetCareReminder = { 
      ...insertReminder, 
      id, 
      createdAt, 
      isCompleted: false,
      isActive: insertReminder.isActive ?? true,
      description: insertReminder.description ?? null,
      endDate: insertReminder.endDate ?? null,
      timeOfDay: insertReminder.timeOfDay ?? null,
      lastTriggered: null
    };
    this.petCareReminders.set(id, reminder);
    return reminder;
  }
  
  async updatePetCareReminder(id: number, reminderData: Partial<PetCareReminder>): Promise<PetCareReminder> {
    const reminder = this.petCareReminders.get(id);
    if (!reminder) {
      throw new Error(`Pet care reminder with ID ${id} not found`);
    }
    
    const updatedReminder = { ...reminder, ...reminderData };
    this.petCareReminders.set(id, updatedReminder);
    return updatedReminder;
  }
  
  async getPetCareRemindersByPetId(petId: number): Promise<PetCareReminder[]> {
    return Array.from(this.petCareReminders.values())
      .filter(reminder => reminder.petId === petId)
      .sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime());
  }
  
  async getPetCareRemindersByUserId(userId: number): Promise<PetCareReminder[]> {
    return Array.from(this.petCareReminders.values())
      .filter(reminder => reminder.userId === userId)
      .sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime());
  }
  
  async getActivePetCareReminders(): Promise<PetCareReminder[]> {
    const today = new Date();
    
    return Array.from(this.petCareReminders.values())
      .filter(reminder => !reminder.isCompleted && new Date(reminder.startDate) >= today)
      .sort((a, b) => new Date(a.startDate).getTime() - new Date(b.startDate).getTime());
  }
  
  async markReminderAsCompleted(id: number): Promise<PetCareReminder> {
    const reminder = this.petCareReminders.get(id);
    if (!reminder) {
      throw new Error(`Pet care reminder with ID ${id} not found`);
    }
    
    const updatedReminder = { 
      ...reminder, 
      isCompleted: true, 
      lastTriggered: new Date() // Use lastTriggered instead of completedAt 
    };
    this.petCareReminders.set(id, updatedReminder);
    return updatedReminder;
  }
  
  // User Consent operations
  async getUserConsent(id: number): Promise<UserConsent | undefined> {
    return this.userConsents.get(id);
  }
  
  async createUserConsent(insertConsent: InsertUserConsent): Promise<UserConsent> {
    const id = this.currentId++;
    const grantedAt = new Date();
    const consent: UserConsent = { ...insertConsent, id, grantedAt };
    this.userConsents.set(id, consent);
    return consent;
  }
  
  async getUserConsentsByUserId(userId: number): Promise<UserConsent[]> {
    return Array.from(this.userConsents.values())
      .filter(consent => consent.userId === userId);
  }
  
  async getUserConsentByType(userId: number, consentType: string): Promise<UserConsent | undefined> {
    return Array.from(this.userConsents.values())
      .find(consent => consent.userId === userId && consent.consentType === consentType);
  }
  
  async updateUserConsent(id: number, isGranted: boolean): Promise<UserConsent> {
    const consent = this.userConsents.get(id);
    if (!consent) {
      throw new Error(`User consent with ID ${id} not found`);
    }
    
    const updatedConsent = { 
      ...consent, 
      isGranted, 
      grantedAt: isGranted ? new Date() : consent.grantedAt,
      revokedAt: !isGranted ? new Date() : null
    };
    this.userConsents.set(id, updatedConsent);
    return updatedConsent;
  }
  
  // Pet Document operations
  async getPetDocument(id: number): Promise<PetDocument | undefined> {
    return this.petDocuments.get(id);
  }
  
  async createPetDocument(insertDocument: InsertPetDocument): Promise<PetDocument> {
    const id = this.currentId++;
    const createdAt = new Date();
    const document: PetDocument = { 
      ...insertDocument, 
      id, 
      createdAt, 
      isVerified: false,
      verifiedBy: null,
      verificationDate: null
    };
    this.petDocuments.set(id, document);
    return document;
  }
  
  async getPetDocumentsByPetId(petId: number): Promise<PetDocument[]> {
    return Array.from(this.petDocuments.values())
      .filter(document => document.petId === petId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async getPetDocumentsByHealthRecordId(healthRecordId: number): Promise<PetDocument[]> {
    return Array.from(this.petDocuments.values())
      .filter(document => document.healthRecordId === healthRecordId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
  
  async markDocumentAsVerified(id: number, verifiedBy: string): Promise<PetDocument> {
    const document = this.petDocuments.get(id);
    if (!document) {
      throw new Error(`Pet document with ID ${id} not found`);
    }
    
    const updatedDocument = { 
      ...document, 
      isVerified: true,
      verifiedBy,
      verificationDate: new Date()
    };
    this.petDocuments.set(id, updatedDocument);
    return updatedDocument;
  }
  
  // Pet Behavior Record operations
  async getPetBehaviorRecord(id: number): Promise<PetBehaviorRecord | undefined> {
    return this.petBehaviorRecords.get(id);
  }
  
  async createPetBehaviorRecord(insertRecord: InsertPetBehaviorRecord): Promise<PetBehaviorRecord> {
    const id = this.currentId++;
    const createdAt = new Date();
    const updatedAt = new Date();
    const isDeleted = false;
    const petBehaviorRecord: PetBehaviorRecord = { 
      ...insertRecord, 
      id, 
      createdAt, 
      updatedAt, 
      isDeleted: isDeleted,
      triggerFactors: insertRecord.triggerFactors ?? null,
      intervention: insertRecord.intervention ?? null,
      trainerName: insertRecord.trainerName ?? null,
      progressStatus: insertRecord.progressStatus ?? null
    };
    this.petBehaviorRecords.set(id, petBehaviorRecord);
    return petBehaviorRecord;
  }
  
  async updatePetBehaviorRecord(id: number, recordData: Partial<PetBehaviorRecord>): Promise<PetBehaviorRecord> {
    const record = this.petBehaviorRecords.get(id);
    if (!record) {
      throw new Error(`Pet behavior record with ID ${id} not found`);
    }
    
    const updatedRecord = { ...record, ...recordData, updatedAt: new Date() };
    this.petBehaviorRecords.set(id, updatedRecord);
    return updatedRecord;
  }
  
  async getPetBehaviorRecordsByPetId(petId: number): Promise<PetBehaviorRecord[]> {
    return Array.from(this.petBehaviorRecords.values())
      .filter(record => record.petId === petId && !record.isDeleted)
      .sort((a, b) => new Date(b.recordDate).getTime() - new Date(a.recordDate).getTime());
  }
  
  async softDeletePetBehaviorRecord(id: number): Promise<PetBehaviorRecord> {
    const record = this.petBehaviorRecords.get(id);
    if (!record) {
      throw new Error(`Pet behavior record with ID ${id} not found`);
    }
    
    const deletedRecord = { ...record, isDeleted: true, updatedAt: new Date() };
    this.petBehaviorRecords.set(id, deletedRecord);
    return deletedRecord;
  }
  
  // GDPR compliance related operations
  async deleteUser(id: number): Promise<void> {
    if (!this.users.has(id)) {
      throw new Error(`User with ID ${id} not found`);
    }
    
    this.users.delete(id);
  }
  
  async deleteService(id: number): Promise<void> {
    if (!this.services.has(id)) {
      throw new Error(`Service with ID ${id} not found`);
    }
    
    this.services.delete(id);
  }
  
  async getPetsByOwnerId(userId: number): Promise<Pet[]> {
    return Array.from(this.pets.values()).filter(
      (pet) => pet.ownerId === userId
    );
  }

  // Initialize some basic resources
  private initializeResources() {
    const resources: InsertResource[] = [
      {
        title: "5 Essential Vaccinations for Puppies",
        content: "Learn about the critical vaccines your new puppy needs in their first year to stay healthy and protected.",
        category: "Veterinary Care",
        author: "Dr. Sarah Wilson",
        readTime: 5
      },
      {
        title: "Understanding Cat Behavior: What Your Cat Is Trying to Tell You",
        content: "Decode your cat's body language and vocalizations to better understand their needs and emotions.",
        category: "Behavior",
        author: "Emma Chen",
        readTime: 7
      },
      {
        title: "Nutritional Guide for Senior Dogs: What to Feed Your Aging Companion",
        content: "Tailored dietary recommendations to support your senior dog's health, mobility, and cognitive function.",
        category: "Nutrition",
        author: "Dr. Mark Johnson",
        readTime: 6
      }
    ];

    resources.forEach(async (resource) => {
      await this.createResource(resource);
    });
  }
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  sessionStore: any; // Using 'any' to resolve SessionStore compatibility issues

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }
  
  // Pet Health Record operations
  async getPetHealthRecord(id: number): Promise<PetHealthRecord | undefined> {
    const [record] = await db.select().from(petHealthRecords).where(eq(petHealthRecords.id, id));
    return record;
  }
  
  async createPetHealthRecord(record: InsertPetHealthRecord): Promise<PetHealthRecord> {
    const [newRecord] = await db.insert(petHealthRecords).values(record).returning();
    return newRecord;
  }
  
  async updatePetHealthRecord(id: number, recordData: Partial<PetHealthRecord>): Promise<PetHealthRecord> {
    const [updated] = await db
      .update(petHealthRecords)
      .set({ ...recordData, updatedAt: new Date() })
      .where(eq(petHealthRecords.id, id))
      .returning();
    
    if (!updated) {
      throw new Error(`Pet health record with ID ${id} not found`);
    }
    
    return updated;
  }
  
  async getPetHealthRecordsByPetId(petId: number): Promise<PetHealthRecord[]> {
    return db.select().from(petHealthRecords).where(eq(petHealthRecords.petId, petId));
  }
  
  async deletePetHealthRecord(id: number): Promise<void> {
    await db.delete(petHealthRecords).where(eq(petHealthRecords.id, id));
  }
  
  // Pet Vaccination operations
  async getPetVaccination(id: number): Promise<PetVaccination | undefined> {
    const [vaccination] = await db.select().from(petVaccinations).where(eq(petVaccinations.id, id));
    return vaccination;
  }
  
  async createPetVaccination(vaccination: InsertPetVaccination): Promise<PetVaccination> {
    const [newVaccination] = await db.insert(petVaccinations).values(vaccination).returning();
    return newVaccination;
  }
  
  async updatePetVaccination(id: number, vaccinationData: Partial<PetVaccination>): Promise<PetVaccination> {
    const [updated] = await db
      .update(petVaccinations)
      .set(vaccinationData)
      .where(eq(petVaccinations.id, id))
      .returning();
    
    if (!updated) {
      throw new Error(`Pet vaccination with ID ${id} not found`);
    }
    
    return updated;
  }
  
  async getPetVaccinationsByPetId(petId: number): Promise<PetVaccination[]> {
    return db.select().from(petVaccinations).where(eq(petVaccinations.petId, petId));
  }
  
  async getUpcomingVaccinations(days: number): Promise<PetVaccination[]> {
    const now = new Date();
    const futureDate = new Date();
    futureDate.setDate(now.getDate() + days);
    
    return db
      .select()
      .from(petVaccinations)
      .where(
        and(
          sql`${petVaccinations.dueDate} >= ${now.toISOString()}`,
          sql`${petVaccinations.dueDate} <= ${futureDate.toISOString()}`
        )
      );
  }
  
  // Pet Medication operations
  async getPetMedication(id: number): Promise<PetMedication | undefined> {
    const [medication] = await db.select().from(petMedications).where(eq(petMedications.id, id));
    return medication;
  }
  
  async createPetMedication(medication: InsertPetMedication): Promise<PetMedication> {
    const [newMedication] = await db.insert(petMedications).values(medication).returning();
    return newMedication;
  }
  
  async updatePetMedication(id: number, medicationData: Partial<PetMedication>): Promise<PetMedication> {
    const [updated] = await db
      .update(petMedications)
      .set(medicationData)
      .where(eq(petMedications.id, id))
      .returning();
    
    if (!updated) {
      throw new Error(`Pet medication with ID ${id} not found`);
    }
    
    return updated;
  }
  
  async getPetMedicationsByPetId(petId: number): Promise<PetMedication[]> {
    return db.select().from(petMedications).where(eq(petMedications.petId, petId));
  }
  
  async getActiveMedications(): Promise<PetMedication[]> {
    const today = new Date().toISOString();
    
    return db
      .select()
      .from(petMedications)
      .where(
        and(
          sql`${petMedications.startDate} <= ${today}`,
          sql`${petMedications.endDate} IS NULL OR ${petMedications.endDate} >= ${today}`
        )
      );
  }
  
  // Pet Weight History operations
  async getPetWeightHistory(id: number): Promise<PetWeightHistory | undefined> {
    const [record] = await db.select().from(petWeightHistory).where(eq(petWeightHistory.id, id));
    return record;
  }
  
  async createPetWeightHistory(weightRecord: InsertPetWeightHistory): Promise<PetWeightHistory> {
    const [newRecord] = await db.insert(petWeightHistory).values(weightRecord).returning();
    return newRecord;
  }
  
  async getPetWeightHistoryByPetId(petId: number): Promise<PetWeightHistory[]> {
    return db
      .select()
      .from(petWeightHistory)
      .where(eq(petWeightHistory.petId, petId))
      .orderBy(desc(petWeightHistory.recordDate));
  }
  
  // User Notification operations
  async getUserNotification(id: number): Promise<UserNotification | undefined> {
    const [notification] = await db.select().from(userNotifications).where(eq(userNotifications.id, id));
    return notification;
  }
  
  async createUserNotification(notification: InsertUserNotification): Promise<UserNotification> {
    const [newNotification] = await db.insert(userNotifications).values({
      ...notification,
      isRead: false
    }).returning();
    return newNotification;
  }
  
  async getUserNotificationsByUserId(userId: number): Promise<UserNotification[]> {
    return db
      .select()
      .from(userNotifications)
      .where(eq(userNotifications.userId, userId))
      .orderBy(desc(userNotifications.createdAt));
  }
  
  async getUnreadNotificationsByUserId(userId: number): Promise<UserNotification[]> {
    return db
      .select()
      .from(userNotifications)
      .where(
        and(
          eq(userNotifications.userId, userId),
          eq(userNotifications.isRead, false)
        )
      )
      .orderBy(desc(userNotifications.createdAt));
  }
  
  async markNotificationAsRead(id: number): Promise<UserNotification> {
    const [updated] = await db
      .update(userNotifications)
      .set({ isRead: true })
      .where(eq(userNotifications.id, id))
      .returning();
    
    if (!updated) {
      throw new Error(`Notification with ID ${id} not found`);
    }
    
    return updated;
  }
  
  async deleteNotification(id: number): Promise<void> {
    await db.delete(userNotifications).where(eq(userNotifications.id, id));
  }
  
  // Pet Care Reminder operations
  async getPetCareReminder(id: number): Promise<PetCareReminder | undefined> {
    const [reminder] = await db.select().from(petCareReminders).where(eq(petCareReminders.id, id));
    return reminder;
  }
  
  async createPetCareReminder(reminder: InsertPetCareReminder): Promise<PetCareReminder> {
    const [newReminder] = await db.insert(petCareReminders).values({
      ...reminder,
      isCompleted: false
    }).returning();
    return newReminder;
  }
  
  async updatePetCareReminder(id: number, reminderData: Partial<PetCareReminder>): Promise<PetCareReminder> {
    const [updated] = await db
      .update(petCareReminders)
      .set(reminderData)
      .where(eq(petCareReminders.id, id))
      .returning();
    
    if (!updated) {
      throw new Error(`Pet care reminder with ID ${id} not found`);
    }
    
    return updated;
  }
  
  async getPetCareRemindersByPetId(petId: number): Promise<PetCareReminder[]> {
    return db
      .select()
      .from(petCareReminders)
      .where(eq(petCareReminders.petId, petId))
      .orderBy(asc(petCareReminders.startDate));
  }
  
  async getPetCareRemindersByUserId(userId: number): Promise<PetCareReminder[]> {
    return db
      .select()
      .from(petCareReminders)
      .where(eq(petCareReminders.userId, userId))
      .orderBy(asc(petCareReminders.startDate));
  }
  
  async getActivePetCareReminders(): Promise<PetCareReminder[]> {
    const today = new Date().toISOString();
    
    return db
      .select()
      .from(petCareReminders)
      .where(
        and(
          eq(petCareReminders.isCompleted, false),
          sql`${petCareReminders.startDate} >= ${today}`
        )
      )
      .orderBy(asc(petCareReminders.startDate));
  }
  
  async markReminderAsCompleted(id: number): Promise<PetCareReminder> {
    const [updated] = await db
      .update(petCareReminders)
      .set({ 
        isCompleted: true,
        lastTriggered: new Date() // Use lastTriggered instead of completedAt
      })
      .where(eq(petCareReminders.id, id))
      .returning();
    
    if (!updated) {
      throw new Error(`Pet care reminder with ID ${id} not found`);
    }
    
    return updated;
  }
  
  // User Consent operations
  async getUserConsent(id: number): Promise<UserConsent | undefined> {
    const [consent] = await db.select().from(userConsents).where(eq(userConsents.id, id));
    return consent;
  }
  
  async createUserConsent(consent: InsertUserConsent): Promise<UserConsent> {
    const [newConsent] = await db.insert(userConsents).values(consent).returning();
    return newConsent;
  }
  
  async getUserConsentsByUserId(userId: number): Promise<UserConsent[]> {
    return db
      .select()
      .from(userConsents)
      .where(eq(userConsents.userId, userId));
  }
  
  async getUserConsentByType(userId: number, consentType: string): Promise<UserConsent | undefined> {
    const [consent] = await db
      .select()
      .from(userConsents)
      .where(
        and(
          eq(userConsents.userId, userId),
          eq(userConsents.consentType, consentType)
        )
      );
    
    return consent;
  }
  
  async updateUserConsent(id: number, isGranted: boolean): Promise<UserConsent> {
    const updateData: any = { isGranted };
    
    if (isGranted) {
      updateData.grantedAt = new Date();
      updateData.revokedAt = null;
    } else {
      updateData.revokedAt = new Date();
    }
    
    const [updated] = await db
      .update(userConsents)
      .set(updateData)
      .where(eq(userConsents.id, id))
      .returning();
    
    if (!updated) {
      throw new Error(`User consent with ID ${id} not found`);
    }
    
    return updated;
  }
  
  // Pet Document operations
  async getPetDocument(id: number): Promise<PetDocument | undefined> {
    const [document] = await db.select().from(petDocuments).where(eq(petDocuments.id, id));
    return document;
  }
  
  async createPetDocument(document: InsertPetDocument): Promise<PetDocument> {
    // Create the document object with explicitly defined properties that match the schema
    const docToInsert = {
      ...document,
      isVerified: false,
      verifiedBy: null as string | null,
      verificationDate: null as Date | null
    };
    
    const [newDocument] = await db.insert(petDocuments).values(docToInsert).returning();
    return newDocument;
  }
  
  async getPetDocumentsByPetId(petId: number): Promise<PetDocument[]> {
    return db
      .select()
      .from(petDocuments)
      .where(eq(petDocuments.petId, petId))
      .orderBy(desc(petDocuments.createdAt));
  }
  
  async getPetDocumentsByHealthRecordId(healthRecordId: number): Promise<PetDocument[]> {
    return db
      .select()
      .from(petDocuments)
      .where(eq(petDocuments.healthRecordId, healthRecordId))
      .orderBy(desc(petDocuments.createdAt));
  }
  
  async markDocumentAsVerified(id: number, verifiedBy: string): Promise<PetDocument> {
    // Create an explicitly typed update object
    const updateData = {
      isVerified: true,
      verifiedBy: verifiedBy,
      verificationDate: new Date() as Date
    };
    
    const [updated] = await db
      .update(petDocuments)
      .set(updateData)
      .where(eq(petDocuments.id, id))
      .returning();
    
    if (!updated) {
      throw new Error(`Pet document with ID ${id} not found`);
    }
    
    return updated;
  }
  
  // Pet Behavior Record operations
  async getPetBehaviorRecord(id: number): Promise<PetBehaviorRecord | undefined> {
    const [record] = await db
      .select()
      .from(petBehaviorRecords)
      .where(and(eq(petBehaviorRecords.id, id), eq(petBehaviorRecords.isDeleted, false)));
    return record;
  }
  
  async createPetBehaviorRecord(record: InsertPetBehaviorRecord): Promise<PetBehaviorRecord> {
    const [newRecord] = await db
      .insert(petBehaviorRecords)
      .values({
        ...record,
        isDeleted: false
      })
      .returning();
    return newRecord;
  }
  
  async updatePetBehaviorRecord(id: number, recordData: Partial<PetBehaviorRecord>): Promise<PetBehaviorRecord> {
    const [updated] = await db
      .update(petBehaviorRecords)
      .set({ 
        ...recordData, 
        updatedAt: new Date() 
      })
      .where(eq(petBehaviorRecords.id, id))
      .returning();
    
    if (!updated) {
      throw new Error(`Pet behavior record with ID ${id} not found`);
    }
    
    return updated;
  }
  
  async getPetBehaviorRecordsByPetId(petId: number): Promise<PetBehaviorRecord[]> {
    return db
      .select()
      .from(petBehaviorRecords)
      .where(
        and(
          eq(petBehaviorRecords.petId, petId),
          eq(petBehaviorRecords.isDeleted, false)
        )
      )
      .orderBy(desc(petBehaviorRecords.recordDate));
  }
  
  // Pet Behavior Record softDelete operation
  async softDeletePetBehaviorRecord(id: number): Promise<PetBehaviorRecord> {
    const [updated] = await db
      .update(petBehaviorRecords)
      .set({ 
        isDeleted: true,
        updatedAt: new Date() 
      })
      .where(eq(petBehaviorRecords.id, id))
      .returning();
    
    if (!updated) {
      throw new Error(`Pet behavior record with ID ${id} not found`);
    }
    
    return updated;
  }

  // GDPR compliance related operations are defined below in the main class

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async getUserByFirebaseUid(firebaseUid: string): Promise<User | undefined> {
    try {
      const [user] = await db.select().from(users).where(eq(users.firebaseUid, firebaseUid));
      return user;
    } catch (error) {
      console.error("Error in getUserByFirebaseUid:", error);
      return undefined;
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUserType(userId: number, userType: UserType): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ userType })
      .where(eq(users.id, userId))
      .returning();
    
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    return user;
  }

  async updateUser(userId: number, userData: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, userId))
      .returning();
    
    if (!user) {
      throw new Error(`User with ID ${userId} not found`);
    }
    
    return user;
  }

  // Pet owner operations
  async getPetOwner(userId: number): Promise<PetOwner | undefined> {
    const [petOwner] = await db
      .select()
      .from(petOwners)
      .where(eq(petOwners.userId, userId));
    
    return petOwner;
  }

  async createPetOwner(insertPetOwner: InsertPetOwner): Promise<PetOwner> {
    const [petOwner] = await db
      .insert(petOwners)
      .values(insertPetOwner)
      .returning();
    
    return petOwner;
  }

  async updatePetOwner(petOwnerId: number, petOwnerData: Partial<PetOwner>): Promise<PetOwner> {
    const [petOwner] = await db
      .update(petOwners)
      .set(petOwnerData)
      .where(eq(petOwners.id, petOwnerId))
      .returning();
    
    if (!petOwner) {
      throw new Error(`Pet owner with ID ${petOwnerId} not found`);
    }
    
    return petOwner;
  }

  // Service provider operations
  async getServiceProvider(userId: number): Promise<ServiceProvider | undefined> {
    const [serviceProvider] = await db
      .select()
      .from(serviceProviders)
      .where(eq(serviceProviders.userId, userId));
    
    return serviceProvider;
  }
  
  async getServiceProviderById(providerId: number): Promise<ServiceProvider | undefined> {
    const [serviceProvider] = await db
      .select()
      .from(serviceProviders)
      .where(eq(serviceProviders.id, providerId));
    
    return serviceProvider;
  }

  async createServiceProvider(insertServiceProvider: InsertServiceProvider): Promise<ServiceProvider> {
    const [serviceProvider] = await db
      .insert(serviceProviders)
      .values(insertServiceProvider)
      .returning();
    
    return serviceProvider;
  }

  async updateServiceProvider(providerId: number, providerData: Partial<ServiceProvider>): Promise<ServiceProvider> {
    const [provider] = await db
      .update(serviceProviders)
      .set(providerData)
      .where(eq(serviceProviders.id, providerId))
      .returning();
    
    if (!provider) {
      throw new Error(`Service provider with ID ${providerId} not found`);
    }
    
    return provider;
  }

  async getAllServiceProviders(): Promise<ServiceProvider[]> {
    return db.select().from(serviceProviders);
  }

  async getServiceProvidersByCategory(category: string): Promise<ServiceProvider[]> {
    return db
      .select()
      .from(serviceProviders)
      .where(eq(serviceProviders.category, category));
  }

  // Shelter operations
  async getShelter(userId: number): Promise<Shelter | undefined> {
    const [shelter] = await db
      .select()
      .from(shelters)
      .where(eq(shelters.userId, userId));
    
    return shelter;
  }

  async createShelter(insertShelter: InsertShelter): Promise<Shelter> {
    const [shelter] = await db
      .insert(shelters)
      .values(insertShelter)
      .returning();
    
    return shelter;
  }

  async updateShelter(shelterId: number, shelterData: Partial<Shelter>): Promise<Shelter> {
    const [shelter] = await db
      .update(shelters)
      .set(shelterData)
      .where(eq(shelters.id, shelterId))
      .returning();
    
    if (!shelter) {
      throw new Error(`Shelter with ID ${shelterId} not found`);
    }
    
    return shelter;
  }

  async getAllShelters(): Promise<Shelter[]> {
    return db.select().from(shelters);
  }

  // Pet operations
  async getPet(id: number): Promise<Pet | undefined> {
    const [pet] = await db
      .select()
      .from(pets)
      .where(eq(pets.id, id));
    
    return pet;
  }

  async createPet(insertPet: InsertPet): Promise<Pet> {
    const [pet] = await db
      .insert(pets)
      .values(insertPet)
      .returning();
    
    return pet;
  }
  
  async updatePet(id: number, petData: Partial<Pet>): Promise<Pet> {
    const [updatedPet] = await db
      .update(pets)
      .set(petData)
      .where(eq(pets.id, id))
      .returning();
      
    if (!updatedPet) {
      throw new Error(`Pet with ID ${id} not found`);
    }
    
    return updatedPet;
  }
  
  async deletePet(id: number): Promise<void> {
    const result = await db
      .delete(pets)
      .where(eq(pets.id, id));
      
    // In a more robust implementation, we would check if the deletion
    // was successful and throw an error if not
  }

  async getAllPets(): Promise<Pet[]> {
    return db.select().from(pets);
  }

  async getPetsByShelterId(shelterId: number): Promise<Pet[]> {
    return db
      .select()
      .from(pets)
      .where(eq(pets.shelterId, shelterId));
  }

  async getFeaturedPets(): Promise<Pet[]> {
    return db
      .select()
      .from(pets)
      .where(eq(pets.isFeatured, true));
  }

  async searchPets(filters: { type?: string; breed?: string; age?: number; size?: string }): Promise<Pet[]> {
    // Start with a base query
    let baseQuery = db.select().from(pets);
    let conditions = [];
    
    // Build the conditions array
    if (filters.type) {
      conditions.push(eq(pets.type, filters.type));
    }
    
    if (filters.breed) {
      conditions.push(eq(pets.breed, filters.breed));
    }
    
    if (filters.age) {
      conditions.push(eq(pets.age, filters.age));
    }
    
    if (filters.size) {
      conditions.push(eq(pets.size, filters.size));
    }
    
    // Apply all conditions at once if there are any
    if (conditions.length > 0) {
      return baseQuery.where(and(...conditions));
    }
    
    // Return all pets if no filters
    return baseQuery;
  }

  // Service operations
  async getService(id: number): Promise<Service | undefined> {
    const [service] = await db
      .select()
      .from(services)
      .where(eq(services.id, id));
    
    return service;
  }

  async createService(insertService: InsertService): Promise<Service> {
    const [service] = await db
      .insert(services)
      .values(insertService)
      .returning();
    
    return service;
  }

  async getServicesByProviderId(providerId: number): Promise<Service[]> {
    return db
      .select()
      .from(services)
      .where(eq(services.providerId, providerId));
  }

  async getServicesByCategory(category: string): Promise<Service[]> {
    return db
      .select()
      .from(services)
      .where(eq(services.category, category));
  }

  async getAllServices(): Promise<Service[]> {
    return db.select().from(services);
  }

  // Resource operations
  async getResource(id: number): Promise<Resource | undefined> {
    const [resource] = await db
      .select()
      .from(resources)
      .where(eq(resources.id, id));
    
    return resource;
  }

  async createResource(insertResource: InsertResource): Promise<Resource> {
    const [resource] = await db
      .insert(resources)
      .values(insertResource)
      .returning();
    
    return resource;
  }

  async getAllResources(): Promise<Resource[]> {
    return db.select().from(resources);
  }

  async getResourcesByCategory(category: string): Promise<Resource[]> {
    return db
      .select()
      .from(resources)
      .where(eq(resources.category, category));
  }

  // Favorites operations
  async getFavorite(id: number): Promise<Favorite | undefined> {
    const [favorite] = await db
      .select()
      .from(favorites)
      .where(eq(favorites.id, id));
    
    return favorite;
  }

  async createFavorite(insertFavorite: InsertFavorite): Promise<Favorite> {
    const [favorite] = await db
      .insert(favorites)
      .values(insertFavorite)
      .returning();
    
    return favorite;
  }

  async getFavoritesByPetOwnerId(petOwnerId: number): Promise<Favorite[]> {
    return db
      .select()
      .from(favorites)
      .where(eq(favorites.petOwnerId, petOwnerId));
  }

  async getIsFavorite(petOwnerId: number, petId: number): Promise<boolean> {
    const [favorite] = await db
      .select()
      .from(favorites)
      .where(
        and(
          eq(favorites.petOwnerId, petOwnerId),
          eq(favorites.petId, petId)
        )
      );
    
    return !!favorite;
  }

  async deleteFavorite(id: number): Promise<void> {
    await db
      .delete(favorites)
      .where(eq(favorites.id, id));
  }

  // Appointment operations
  async getAppointment(id: number): Promise<Appointment | undefined> {
    const [appointment] = await db
      .select()
      .from(appointments)
      .where(eq(appointments.id, id));
    
    return appointment;
  }

  async createAppointment(insertAppointment: InsertAppointment): Promise<Appointment> {
    const [appointment] = await db
      .insert(appointments)
      .values(insertAppointment)
      .returning();
    
    return appointment;
  }

  async getAppointmentsByUserId(userId: number): Promise<Appointment[]> {
    return db
      .select()
      .from(appointments)
      .where(eq(appointments.userId, userId));
  }

  async getAppointmentsByPetId(petId: number): Promise<Appointment[]> {
    return db
      .select()
      .from(appointments)
      .where(eq(appointments.petId, petId));
  }

  async getAppointmentsByShelterId(shelterId: number): Promise<Appointment[]> {
    return db
      .select()
      .from(appointments)
      .where(eq(appointments.shelterId, shelterId));
  }

  async getAppointmentsByProviderId(providerId: number): Promise<Appointment[]> {
    return db
      .select()
      .from(appointments)
      .where(eq(appointments.providerId, providerId));
  }

  async updateAppointmentStatus(id: number, status: string): Promise<Appointment> {
    const [appointment] = await db
      .update(appointments)
      .set({ status })
      .where(eq(appointments.id, id))
      .returning();
    
    if (!appointment) {
      throw new Error(`Appointment with ID ${id} not found`);
    }
    
    return appointment;
  }

  // GDPR compliance related operations
  async deleteUser(id: number): Promise<void> {
    try {
      console.log(`Executing deleteUser for user ID: ${id}`);
      
      // First check if user exists
      const [user] = await db.select().from(users).where(eq(users.id, id));
      
      if (!user) {
        console.log(`No user found with ID: ${id}`);
        throw new Error(`User with ID ${id} not found`);
      }
      
      console.log(`Found user with ID: ${id}, attempting to delete`);
      
      // Delete the user
      const result = await db
        .delete(users)
        .where(eq(users.id, id))
        .returning({ id: users.id });
      
      console.log(`Deletion result:`, result);
      
      if (!result.length) {
        throw new Error(`Failed to delete user with ID ${id}`);
      }
      
      console.log(`User ${id} successfully deleted`);
    } catch (error) {
      console.error(`Error in deleteUser:`, error);
      throw error;
    }
  }
  
  async deleteService(id: number): Promise<void> {
    await db
      .delete(services)
      .where(eq(services.id, id));
  }
  
  async getPetsByOwnerId(userId: number): Promise<Pet[]> {
    return db
      .select()
      .from(pets)
      .where(eq(pets.ownerId, userId));
  }
  
  // Pet Weight History operations implemented above
  
  // Pet Health Metrics operations
  async getPetHealthMetric(id: number): Promise<PetHealthMetric | undefined> {
    const [metric] = await db
      .select()
      .from(petHealthMetrics)
      .where(eq(petHealthMetrics.id, id));
    
    return metric;
  }
  
  async createPetHealthMetric(metric: InsertPetHealthMetric): Promise<PetHealthMetric> {
    const [newMetric] = await db.insert(petHealthMetrics).values({
      ...metric,
      createdAt: new Date(),
      updatedAt: new Date(),
      isDeleted: false
    }).returning();
    
    return newMetric;
  }
  
  async getPetHealthMetricsByPetId(petId: number): Promise<PetHealthMetric[]> {
    return db
      .select()
      .from(petHealthMetrics)
      .where(
        and(
          eq(petHealthMetrics.petId, petId),
          eq(petHealthMetrics.isDeleted, false)
        )
      )
      .orderBy(desc(petHealthMetrics.recordDate));
  }
  
  async getPetHealthMetricsByType(petId: number, metricType: string): Promise<PetHealthMetric[]> {
    return db
      .select()
      .from(petHealthMetrics)
      .where(
        and(
          eq(petHealthMetrics.petId, petId),
          eq(petHealthMetrics.metricType, metricType),
          eq(petHealthMetrics.isDeleted, false)
        )
      )
      .orderBy(desc(petHealthMetrics.recordDate));
  }
  
  async updatePetHealthMetric(id: number, metricData: Partial<PetHealthMetric>): Promise<PetHealthMetric> {
    const [updated] = await db
      .update(petHealthMetrics)
      .set({ ...metricData, updatedAt: new Date() })
      .where(eq(petHealthMetrics.id, id))
      .returning();
    
    if (!updated) {
      throw new Error(`Pet health metric with ID ${id} not found`);
    }
    
    return updated;
  }
  
  async softDeletePetHealthMetric(id: number): Promise<PetHealthMetric> {
    const [updated] = await db
      .update(petHealthMetrics)
      .set({ isDeleted: true, updatedAt: new Date() })
      .where(eq(petHealthMetrics.id, id))
      .returning();
    
    if (!updated) {
      throw new Error(`Pet health metric with ID ${id} not found`);
    }
    
    return updated;
  }
  
  // Notification Preferences operations
  async getNotificationPreference(id: number): Promise<NotificationPreference | undefined> {
    const [preference] = await db
      .select()
      .from(notificationPreferences)
      .where(eq(notificationPreferences.id, id));
    
    return preference;
  }
  
  async createNotificationPreference(preference: InsertNotificationPreference): Promise<NotificationPreference> {
    const [newPreference] = await db.insert(notificationPreferences).values({
      ...preference,
      createdAt: new Date(),
      updatedAt: new Date()
    }).returning();
    
    return newPreference;
  }
  
  async getNotificationPreferencesByUserId(userId: number): Promise<NotificationPreference[]> {
    return db
      .select()
      .from(notificationPreferences)
      .where(eq(notificationPreferences.userId, userId));
  }
  
  async updateNotificationPreference(id: number, preferenceData: Partial<NotificationPreference>): Promise<NotificationPreference> {
    const [updated] = await db
      .update(notificationPreferences)
      .set({ ...preferenceData, updatedAt: new Date() })
      .where(eq(notificationPreferences.id, id))
      .returning();
    
    if (!updated) {
      throw new Error(`Notification preference with ID ${id} not found`);
    }
    
    return updated;
  }
  
  // Reminder Notifications operations
  async getReminderNotification(id: number): Promise<ReminderNotification | undefined> {
    const [notification] = await db
      .select()
      .from(reminderNotifications)
      .where(eq(reminderNotifications.id, id));
    
    return notification;
  }
  
  async createReminderNotification(notification: InsertReminderNotification): Promise<ReminderNotification> {
    const [newNotification] = await db.insert(reminderNotifications).values({
      ...notification,
      createdAt: new Date(),
      updatedAt: new Date()
    }).returning();
    
    return newNotification;
  }
  
  async getReminderNotificationsByReminderId(reminderId: number): Promise<ReminderNotification[]> {
    return db
      .select()
      .from(reminderNotifications)
      .where(eq(reminderNotifications.reminderId, reminderId));
  }
  
  async getReminderNotificationsByUserId(userId: number): Promise<ReminderNotification[]> {
    return db
      .select()
      .from(reminderNotifications)
      .where(eq(reminderNotifications.userId, userId));
  }
  
  async updateReminderNotificationStatus(id: number, status: string): Promise<ReminderNotification> {
    const [updated] = await db
      .update(reminderNotifications)
      .set({ status, updatedAt: new Date() })
      .where(eq(reminderNotifications.id, id))
      .returning();
    
    if (!updated) {
      throw new Error(`Reminder notification with ID ${id} not found`);
    }
    
    return updated;
  }

  // Initialize some basic resources if needed
  async initializeResources() {
    const existingResources = await this.getAllResources();

    // Only initialize if no resources exist
    if (existingResources.length === 0) {
      const resourcesData: InsertResource[] = [
        {
          title: "5 Essential Vaccinations for Puppies",
          content: "Learn about the critical vaccines your new puppy needs in their first year to stay healthy and protected.",
          category: "Veterinary Care",
          author: "Dr. Sarah Wilson",
          readTime: 5
        },
        {
          title: "Understanding Cat Behavior: What Your Cat Is Trying to Tell You",
          content: "Decode your cat's body language and vocalizations to better understand their needs and emotions.",
          category: "Behavior",
          author: "Emma Chen",
          readTime: 7
        },
        {
          title: "Nutritional Guide for Senior Dogs: What to Feed Your Aging Companion",
          content: "Tailored dietary recommendations to support your senior dog's health, mobility, and cognitive function.",
          category: "Nutrition",
          author: "Dr. Mark Johnson",
          readTime: 6
        }
      ];

      for (const resource of resourcesData) {
        await this.createResource(resource);
      }
    }
  }
  
  // Initialize sample pets for development
  async initializeSamplePets() {
    console.log("Sample pet initialization disabled. Use the Add Pet form to add real pets.");
    return;
  }
}

// Switch to database storage
export const storage = new DatabaseStorage();
