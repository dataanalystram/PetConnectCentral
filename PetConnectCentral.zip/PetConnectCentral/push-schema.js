const { exec } = require('child_process');
exec('npx drizzle-kit push:pg --config=drizzle.config.ts --verbose', (error, stdout, stderr) => {
  if (error) {
    console.error();
    return;
  }
  if (stderr) {
    console.error();
    return;
  }
  console.log();
});
