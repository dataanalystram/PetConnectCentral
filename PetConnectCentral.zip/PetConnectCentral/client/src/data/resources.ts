import { CategoryType, ResourceType } from "@/lib/types";

// Resource categories
export const resourceCategories: CategoryType[] = [
  {
    value: "veterinary-care",
    label: "Veterinary Care",
    icon: "🏥"
  },
  {
    value: "behavior",
    label: "Behavior",
    icon: "🧠"
  },
  {
    value: "nutrition",
    label: "Nutrition",
    icon: "🍖"
  },
  {
    value: "training",
    label: "Training",
    icon: "🎓"
  },
  {
    value: "grooming",
    label: "Grooming",
    icon: "✂️"
  },
  {
    value: "adoption",
    label: "Adoption",
    icon: "❤️"
  }
];

// Sample resource articles
export const resources: ResourceType[] = [
  {
    id: 1,
    title: "5 Essential Vaccinations for Puppies",
    content: "Learn about the critical vaccines your new puppy needs in their first year to stay healthy and protected.",
    category: "Veterinary Care",
    author: "Dr. Sarah Wilson",
    readTime: 5
  },
  {
    id: 2,
    title: "Understanding Cat Behavior: What Your Cat Is Trying to Tell You",
    content: "Decode your cat's body language and vocalizations to better understand their needs and emotions.",
    category: "Behavior",
    author: "Emma Chen",
    readTime: 7
  },
  {
    id: 3,
    title: "Nutritional Guide for Senior Dogs: What to Feed Your Aging Companion",
    content: "Tailored dietary recommendations to support your senior dog's health, mobility, and cognitive function.",
    category: "Nutrition",
    author: "Dr. Mark Johnson",
    readTime: 6
  }
];

// Tips categories
export const tipCategories = [
  "New Pet Owner",
  "Health & Wellness",
  "Training Tips",
  "Pet Safety",
  "Seasonal Tips"
];

// Frequently asked questions
export const faqs = [
  {
    question: "How do I choose the right pet for my lifestyle?",
    answer: "Consider factors like your living space, activity level, time availability, and budget. Research different breeds and their needs. Visit shelters to meet various pets and see which one connects with you."
  },
  {
    question: "How often should my pet visit the veterinarian?",
    answer: "Generally, dogs and cats should have annual wellness exams. Puppies and kittens need more frequent visits for vaccinations, while senior pets may need semi-annual checkups. Always consult with your veterinarian for a schedule tailored to your pet's specific needs."
  },
  {
    question: "What should I feed my pet for optimal nutrition?",
    answer: "Choose high-quality pet food appropriate for your pet's species, age, size, and activity level. Look for products that meet AAFCO standards and list a specific protein source as the first ingredient. Consult your veterinarian for recommendations specific to your pet's health needs."
  },
  {
    question: "How can I help my new pet adjust to my home?",
    answer: "Create a quiet space with familiar items, maintain a consistent routine, introduce family members slowly, and be patient. Keep initial interactions positive and calm, and gradually introduce your pet to different areas of your home."
  },
  {
    question: "What are the most important training commands for dogs?",
    answer: "Start with basic commands like sit, stay, come, leave it, and walking politely on a leash. These foundation skills keep your dog safe and build communication. Use positive reinforcement methods for the best results."
  }
];
