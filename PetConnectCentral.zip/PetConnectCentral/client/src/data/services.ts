import { CategoryType } from "@/lib/types";

// Service categories with icons
export const serviceCategories: CategoryType[] = [
  {
    value: "veterinary",
    label: "Veterinary",
    icon: "🏥"
  },
  {
    value: "grooming",
    label: "Grooming",
    icon: "✂️"
  },
  {
    value: "training",
    label: "Training",
    icon: "📚"
  },
  {
    value: "dog-walking",
    label: "Dog Walking",
    icon: "🦮"
  },
  {
    value: "pet-sitting",
    label: "Pet Sitting",
    icon: "🏠"
  },
  {
    value: "pet-stores",
    label: "Pet Stores",
    icon: "🛍️"
  }
];

// Emergency services
export const emergencyServices = [
  {
    title: "24/7 Emergency Veterinary Care",
    description: "For urgent medical situations requiring immediate attention",
    icon: "🚑"
  },
  {
    title: "Pet Ambulance Service",
    description: "Rapid transport to emergency care facilities",
    icon: "🚨"
  },
  {
    title: "Poison Control Hotline",
    description: "Expert advice for suspected poisoning or toxin exposure",
    icon: "☎️"
  }
];

// Pricing tiers for service providers
export const providerPricingTiers = [
  {
    name: "Basic",
    price: "Free",
    features: [
      "Standard listing",
      "Basic provider profile",
      "Up to 3 services",
      "Customer reviews"
    ]
  },
  {
    name: "Professional",
    price: "€29",
    frequency: "/month",
    features: [
      "Enhanced visibility",
      "Premium provider profile",
      "Unlimited services",
      "Booking management tools",
      "Priority customer support"
    ],
    popular: true
  },
  {
    name: "Business",
    price: "€79",
    frequency: "/month",
    features: [
      "Top search placement",
      "Featured provider status",
      "Advanced analytics",
      "Marketing tools",
      "Multiple location support",
      "Dedicated account manager"
    ]
  }
];
