import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { ServiceProviderType } from "@/lib/types";
import { Loader2, MapPin, Search, Star, Filter, Grid, Map as MapIcon } from "lucide-react";
import { serviceCategories } from "@/data/services";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import MapView from "@/components/services/map-view";
import ServiceSearch from "@/components/services/service-search";
import { Coordinates } from "@/lib/geolocation";

export default function ServicesPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [priceRange, setPriceRange] = useState([0, 100]);
  const [viewMode, setViewMode] = useState<"list" | "map">("list");
  const [activeTab, setActiveTab] = useState<"browse" | "location">("browse");
  const [userLocation, setUserLocation] = useState<Coordinates | null>(null);

  // Fetch service providers
  const { data: providers = [], isLoading, error } = useQuery<ServiceProviderType[]>({
    queryKey: ["/api/service-providers"],
  });

  // Handle location selection from the map
  const handleLocationSelect = (location: { lat: number; lng: number; address: string }) => {
    setUserLocation({ lat: location.lat, lng: location.lng });
    setActiveTab("browse");
  };

  return (
    <div className="bg-neutral-50 min-h-screen">
      <div className="bg-gradient-to-r from-primary to-purple-700 py-12">
        <div className="container mx-auto px-4">
          <h1 className="font-heading font-bold text-3xl md:text-4xl text-white mb-4">
            Find Pet Services
          </h1>
          <p className="text-white text-lg opacity-90 mb-8 max-w-2xl">
            Discover trusted providers for all your pet care needs, from veterinary care to grooming, training, and more.
          </p>

          {/* Tabs Navigation */}
          <Tabs value={activeTab} onValueChange={(value) => setActiveTab(value as "browse" | "location")} className="w-full">
            <TabsList className="grid w-full max-w-md grid-cols-2 mb-4 bg-white/20 text-white">
              <TabsTrigger 
                value="browse" 
                className="data-[state=active]:bg-white data-[state=active]:text-primary"
              >
                <Search className="h-4 w-4 mr-2" />
                Browse Services
              </TabsTrigger>
              <TabsTrigger 
                value="location" 
                className="data-[state=active]:bg-white data-[state=active]:text-primary"
              >
                <MapPin className="h-4 w-4 mr-2" />
                Find Near Me
              </TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {activeTab === "location" ? (
          <div className="max-w-2xl mx-auto">
            <MapView onLocationSelect={handleLocationSelect} />
          </div>
        ) : (
          <>
            {/* Service Categories */}
            <div className="flex flex-wrap gap-3 mb-8">
              <Button
                variant={selectedCategory === "all" ? "default" : "outline"}
                className="rounded-full"
                onClick={() => setSelectedCategory("all")}
              >
                All Services
              </Button>
              {serviceCategories.map((category) => (
                <Button
                  key={category.value}
                  variant={selectedCategory === category.value ? "default" : "outline"}
                  className="rounded-full"
                  onClick={() => setSelectedCategory(category.value)}
                >
                  {category.icon && <span className="mr-2">{category.icon}</span>}
                  {category.label}
                </Button>
              ))}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              {/* Filters */}
              <div className="bg-white p-6 rounded-xl shadow-sm h-fit">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-heading font-bold text-lg">Filters</h3>
                  <Button variant="ghost" size="sm">
                    Reset
                  </Button>
                </div>

                <div className="space-y-6">
                  <div>
                    <h4 className="font-heading font-semibold mb-2">Price Range</h4>
                    <Slider
                      defaultValue={[0, 100]}
                      max={100}
                      step={1}
                      value={priceRange}
                      onValueChange={setPriceRange}
                      className="mb-2"
                    />
                    <div className="flex justify-between text-sm text-neutral-500">
                      <span>€{priceRange[0]}</span>
                      <span>€{priceRange[1]}</span>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-heading font-semibold mb-2">Rating</h4>
                    <div className="space-y-1">
                      {[5, 4, 3, 2, 1].map((rating) => (
                        <div key={rating} className="flex items-center">
                          <Checkbox id={`rating-${rating}`} />
                          <label htmlFor={`rating-${rating}`} className="ml-2 flex items-center">
                            {Array(rating)
                              .fill(0)
                              .map((_, i) => (
                                <Star key={i} className="h-4 w-4 fill-secondary text-secondary" />
                              ))}
                            {Array(5 - rating)
                              .fill(0)
                              .map((_, i) => (
                                <Star key={i} className="h-4 w-4 text-neutral-300" />
                              ))}
                            <span className="ml-1">& Up</span>
                          </label>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-heading font-semibold mb-2">Availability</h4>
                    <div className="space-y-1">
                      <div className="flex items-center">
                        <Checkbox id="availability-today" />
                        <label htmlFor="availability-today" className="ml-2">Today</label>
                      </div>
                      <div className="flex items-center">
                        <Checkbox id="availability-this-week" />
                        <label htmlFor="availability-this-week" className="ml-2">This Week</label>
                      </div>
                      <div className="flex items-center">
                        <Checkbox id="availability-weekend" />
                        <label htmlFor="availability-weekend" className="ml-2">Weekend</label>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h4 className="font-heading font-semibold mb-2">Special Features</h4>
                    <div className="space-y-1">
                      <div className="flex items-center">
                        <Checkbox id="feature-emergency" />
                        <label htmlFor="feature-emergency" className="ml-2">Emergency Services</label>
                      </div>
                      <div className="flex items-center">
                        <Checkbox id="feature-home" />
                        <label htmlFor="feature-home" className="ml-2">Home Visits</label>
                      </div>
                      <div className="flex items-center">
                        <Checkbox id="feature-online" />
                        <label htmlFor="feature-online" className="ml-2">Online Booking</label>
                      </div>
                      <div className="flex items-center">
                        <Checkbox id="feature-certified" />
                        <label htmlFor="feature-certified" className="ml-2">Certified Professionals</label>
                      </div>
                    </div>
                  </div>

                  <Button className="w-full">Apply Filters</Button>
                </div>
              </div>

              {/* Results */}
              <div className="lg:col-span-3">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="font-heading font-bold text-2xl">
                    {isLoading ? "Loading services..." : "Services Near You"}
                  </h2>
                  <div className="flex items-center gap-2">
                    <Select defaultValue="recommended">
                      <SelectTrigger className="w-[160px]">
                        <SelectValue placeholder="Sort by" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="recommended">Recommended</SelectItem>
                        <SelectItem value="rating-high">Highest Rated</SelectItem>
                        <SelectItem value="price-low">Price: Low to High</SelectItem>
                        <SelectItem value="price-high">Price: High to Low</SelectItem>
                        <SelectItem value="distance">Nearest</SelectItem>
                      </SelectContent>
                    </Select>
                    <div className="flex border rounded-md">
                      <Button
                        variant={viewMode === "list" ? "default" : "ghost"}
                        size="icon"
                        onClick={() => setViewMode("list")}
                        className="rounded-r-none"
                      >
                        <Grid className="h-4 w-4" />
                      </Button>
                      <Button
                        variant={viewMode === "map" ? "default" : "ghost"}
                        size="icon"
                        onClick={() => setViewMode("map")}
                        className="rounded-l-none"
                      >
                        <MapIcon className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>

                {viewMode === "list" ? (
                  <ServiceSearch initialLocation={userLocation} />
                ) : (
                  <div className="bg-white rounded-xl overflow-hidden border">
                    {userLocation ? (
                      <MapView onLocationSelect={handleLocationSelect} />
                    ) : (
                      <div className="h-[600px] flex items-center justify-center">
                        <div className="text-center p-6">
                          <MapIcon className="h-12 w-12 text-neutral-400 mx-auto mb-4" />
                          <p className="text-neutral-600 mb-4">Please select a location to view pet services on the map</p>
                          <Button 
                            variant="default" 
                            size="lg" 
                            onClick={() => setActiveTab("location")}
                            className="bg-primary hover:bg-primary/90"
                          >
                            <MapPin className="h-4 w-4 mr-2" />
                            Select Location
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
