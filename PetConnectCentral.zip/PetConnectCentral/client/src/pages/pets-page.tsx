import { useAuth } from "@/contexts/AuthContext";
import PetList from "@/components/pets/pet-list";
import { Loader2 } from "lucide-react";

export default function PetsPage() {
  const { userProfile } = useAuth();
  
  if (!userProfile) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <PetList />
    </div>
  );
}