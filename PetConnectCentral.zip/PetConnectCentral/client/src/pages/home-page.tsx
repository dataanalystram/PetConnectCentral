import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/contexts/AuthContext";
import { UserType } from "@shared/schema";
import HeroSection from "@/components/home/hero-section";
import ServicesDiscovery from "@/components/home/services-discovery";
import AdoptionSpotlight from "@/components/home/adoption-spotlight";
import ResourcesPreview from "@/components/home/resources-preview";
import ValueProposition from "@/components/home/value-proposition";
import CallToAction from "@/components/home/call-to-action";
import { Loader2 } from "lucide-react";
import PetOwnerDashboard from "@/components/dashboard/pet-owner-dashboard";
import ServiceProviderDashboard from "@/components/dashboard/service-provider-dashboard";
import ShelterDashboard from "@/components/dashboard/shelter-dashboard";

export default function HomePage() {
  const { userProfile } = useAuth();
  
  // If user is logged in, show appropriate dashboard based on user type
  if (userProfile) {
    switch (userProfile.userType) {
      case UserType.PET_OWNER:
        return <PetOwnerDashboard />;
      case UserType.SERVICE_PROVIDER:
        return <ServiceProviderDashboard />;
      case UserType.SHELTER:
        return <ShelterDashboard />;
    }
  }
  
  // Default content for non-logged in users or unknown user type
  return (
    <div>
      <HeroSection />
      <ServicesDiscovery />
      <AdoptionSpotlight />
      <ResourcesPreview />
      <ValueProposition />
      <CallToAction />
    </div>
  );
}
