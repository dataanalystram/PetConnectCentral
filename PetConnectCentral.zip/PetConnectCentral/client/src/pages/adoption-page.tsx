import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Pet } from "@shared/schema";
import { 
  Loader2, 
  Search, 
  MapPin, 
  Heart, 
  Grid, 
  List, 
  Map as MapIcon,
  Filter,
  ChevronLeft,
  ChevronRight
} from "lucide-react";
import { petBreeds, petTypes } from "@/data/pets";

export default function AdoptionPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedType, setSelectedType] = useState<string>("all");
  const [viewMode, setViewMode] = useState<"grid" | "list" | "map">("grid");
  const [location, setLocation] = useState("Berlin, DE");

  // Fetch pets
  const { data: pets, isLoading, error } = useQuery<Pet[]>({
    queryKey: ["/api/pets"],
  });

  // Filter pets based on search and filters
  const filteredPets = pets
    ? pets.filter((pet) => {
        const matchesSearch =
          searchQuery === "" ||
          pet.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          pet.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
          pet.breed?.toLowerCase().includes(searchQuery.toLowerCase());

        const matchesType =
          selectedType === "all" || pet.type === selectedType;

        return matchesSearch && matchesType;
      })
    : [];

  return (
    <div className="bg-neutral-50 min-h-screen">
      <div className="bg-secondary py-12">
        <div className="container mx-auto px-4">
          <h1 className="font-heading font-bold text-3xl md:text-4xl text-white mb-4">
            Find Your Perfect Companion
          </h1>
          <p className="text-white text-lg opacity-90 mb-8 max-w-2xl">
            Thousands of loving animals are waiting for their forever homes. Browse available pets from shelters and rescue organizations.
          </p>

          {/* Search Bar */}
          <div className="bg-white p-4 rounded-xl shadow-md">
            <div className="flex flex-col md:flex-row gap-3">
              <div className="flex-grow relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 h-5 w-5" />
                <Input 
                  type="text" 
                  className="pl-10 pr-4 py-6 rounded-lg border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-secondary" 
                  placeholder="Search by breed, age, or characteristics"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <div className="relative md:w-1/3">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 h-5 w-5" />
                <Input 
                  type="text" 
                  className="pl-10 pr-4 py-6 rounded-lg border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-secondary" 
                  placeholder="Location" 
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                />
              </div>
              <Button className="bg-secondary hover:bg-secondary-dark text-white font-heading font-semibold rounded-lg px-6 py-6">
                Search
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Pet Types Tabs */}
        <Tabs
          defaultValue="all"
          value={selectedType}
          onValueChange={setSelectedType}
          className="mb-8"
        >
          <TabsList className="bg-white p-1 rounded-lg">
            <TabsTrigger value="all">All Pets</TabsTrigger>
            {petTypes.map((type) => (
              <TabsTrigger key={type.value} value={type.value}>
                {type.icon}
                <span className="ml-2">{type.label}</span>
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Filters */}
          <div className="bg-white p-6 rounded-xl shadow-sm h-fit">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-heading font-bold text-lg">Filters</h3>
              <Button variant="ghost" size="sm">
                Reset
              </Button>
            </div>

            <div className="space-y-6">
              {selectedType !== "all" && (
                <div>
                  <h4 className="font-heading font-semibold mb-2">Breed</h4>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select breed" />
                    </SelectTrigger>
                    <SelectContent>
                      {petBreeds[selectedType as keyof typeof petBreeds]?.map((breed) => (
                        <SelectItem key={breed} value={breed}>
                          {breed}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}

              <div>
                <h4 className="font-heading font-semibold mb-2">Age</h4>
                <div className="space-y-1">
                  <div className="flex items-center">
                    <Checkbox id="age-baby" />
                    <label htmlFor="age-baby" className="ml-2">Baby (0-1 year)</label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox id="age-young" />
                    <label htmlFor="age-young" className="ml-2">Young (1-3 years)</label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox id="age-adult" />
                    <label htmlFor="age-adult" className="ml-2">Adult (3-7 years)</label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox id="age-senior" />
                    <label htmlFor="age-senior" className="ml-2">Senior (7+ years)</label>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-heading font-semibold mb-2">Gender</h4>
                <div className="space-y-1">
                  <div className="flex items-center">
                    <Checkbox id="gender-male" />
                    <label htmlFor="gender-male" className="ml-2">Male</label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox id="gender-female" />
                    <label htmlFor="gender-female" className="ml-2">Female</label>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-heading font-semibold mb-2">Size</h4>
                <div className="space-y-1">
                  <div className="flex items-center">
                    <Checkbox id="size-small" />
                    <label htmlFor="size-small" className="ml-2">Small</label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox id="size-medium" />
                    <label htmlFor="size-medium" className="ml-2">Medium</label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox id="size-large" />
                    <label htmlFor="size-large" className="ml-2">Large</label>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-heading font-semibold mb-2">Characteristics</h4>
                <div className="space-y-1">
                  <div className="flex items-center">
                    <Checkbox id="char-friendly" />
                    <label htmlFor="char-friendly" className="ml-2">Good with children</label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox id="char-other-pets" />
                    <label htmlFor="char-other-pets" className="ml-2">Good with other pets</label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox id="char-trained" />
                    <label htmlFor="char-trained" className="ml-2">Trained</label>
                  </div>
                  <div className="flex items-center">
                    <Checkbox id="char-special-needs" />
                    <label htmlFor="char-special-needs" className="ml-2">Special needs</label>
                  </div>
                </div>
              </div>

              <Button className="w-full">Apply Filters</Button>
            </div>
          </div>

          {/* Results */}
          <div className="lg:col-span-3">
            <div className="flex justify-between items-center mb-6">
              <h2 className="font-heading font-bold text-2xl">
                {isLoading
                  ? "Loading pets..."
                  : `${filteredPets.length || "No"} Pets Found`}
              </h2>
              <div className="flex items-center gap-2">
                <Select defaultValue="recent">
                  <SelectTrigger className="w-[160px]">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="recent">Recently Added</SelectItem>
                    <SelectItem value="age-asc">Age: Youngest First</SelectItem>
                    <SelectItem value="age-desc">Age: Oldest First</SelectItem>
                    <SelectItem value="distance">Nearest</SelectItem>
                  </SelectContent>
                </Select>
                <div className="flex border rounded-md">
                  <Button
                    variant={viewMode === "grid" ? "default" : "ghost"}
                    size="icon"
                    onClick={() => setViewMode("grid")}
                    className="rounded-r-none"
                  >
                    <Grid className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === "list" ? "default" : "ghost"}
                    size="icon"
                    onClick={() => setViewMode("list")}
                    className="rounded-l-none rounded-r-none"
                  >
                    <List className="h-4 w-4" />
                  </Button>
                  <Button
                    variant={viewMode === "map" ? "default" : "ghost"}
                    size="icon"
                    onClick={() => setViewMode("map")}
                    className="rounded-l-none"
                  >
                    <MapIcon className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {isLoading ? (
              <div className="flex items-center justify-center h-64">
                <Loader2 className="h-8 w-8 animate-spin text-secondary" />
              </div>
            ) : error ? (
              <div className="bg-white rounded-xl p-6 text-center">
                <p className="text-red-500">Error loading pets. Please try again.</p>
              </div>
            ) : viewMode === "grid" ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                {/* Mock pet cards until data is fetched */}
                <PetCard
                  name="Max"
                  status="Available"
                  breed="German Shepherd"
                  age={2}
                  gender="Male"
                  description="Friendly and active German Shepherd looking for an active family. Good with children and other dogs."
                  shelter="Berlin Animal Shelter"
                />
                <PetCard
                  name="Luna"
                  status="Available"
                  breed="Tabby Cat"
                  age={1}
                  gender="Female"
                  description="Sweet and playful tabby who loves attention. Already spayed and litter trained."
                  shelter="Paws Rescue Center"
                />
                <PetCard
                  name="Buddy"
                  status="Available"
                  breed="Golden Retriever"
                  age={3}
                  gender="Male"
                  description="Gentle, loving retriever who adores people and other pets. Well trained and house broken."
                  shelter="Golden Heart Rescue"
                />
                <PetCard
                  name="Coco"
                  status="Available"
                  breed="French Bulldog"
                  age={4}
                  gender="Female"
                  description="Charming and affectionate Frenchie who loves cuddles and short walks. Perfect apartment companion."
                  shelter="Berlin Animal Shelter"
                />
              </div>
            ) : viewMode === "list" ? (
              <div className="space-y-4">
                {/* List view of pets - simplified for now */}
                <Card>
                  <CardContent className="p-4 flex gap-4">
                    <div className="w-24 h-24 bg-neutral-200 rounded-md"></div>
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <h3 className="font-heading font-bold">Max</h3>
                        <Badge className="bg-accent bg-opacity-10 text-accent">Available</Badge>
                      </div>
                      <div className="flex flex-wrap gap-2 my-1">
                        <Badge variant="outline">German Shepherd</Badge>
                        <Badge variant="outline">2 years</Badge>
                        <Badge variant="outline">Male</Badge>
                      </div>
                      <p className="text-sm text-neutral-600 line-clamp-1">
                        Friendly and active German Shepherd looking for an active family.
                      </p>
                    </div>
                    <Button variant="outline" size="sm" className="self-center" asChild>
                      <a href="/adopt/max">View</a>
                    </Button>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4 flex gap-4">
                    <div className="w-24 h-24 bg-neutral-200 rounded-md"></div>
                    <div className="flex-1">
                      <div className="flex justify-between">
                        <h3 className="font-heading font-bold">Luna</h3>
                        <Badge className="bg-accent bg-opacity-10 text-accent">Available</Badge>
                      </div>
                      <div className="flex flex-wrap gap-2 my-1">
                        <Badge variant="outline">Tabby Cat</Badge>
                        <Badge variant="outline">1 year</Badge>
                        <Badge variant="outline">Female</Badge>
                      </div>
                      <p className="text-sm text-neutral-600 line-clamp-1">
                        Sweet and playful tabby who loves attention.
                      </p>
                    </div>
                    <Button variant="outline" size="sm" className="self-center" asChild>
                      <a href="/adopt/luna">View</a>
                    </Button>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <div className="bg-neutral-200 rounded-xl h-[600px] flex items-center justify-center">
                <p className="text-neutral-600">Map view will be implemented with Leaflet</p>
              </div>
            )}

            {/* Pagination */}
            <div className="flex justify-center mt-8">
              <div className="flex items-center space-x-2">
                <Button variant="outline" size="icon" onClick={() => console.log('Previous page')}>
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button variant="outline" className="px-4" onClick={() => console.log('Page 1')}>1</Button>
                <Button variant="outline" className="px-4" onClick={() => console.log('Page 2')}>2</Button>
                <Button variant="outline" className="px-4" onClick={() => console.log('Page 3')}>3</Button>
                <span>...</span>
                <Button variant="outline" className="px-4" onClick={() => console.log('Page 10')}>10</Button>
                <Button variant="outline" size="icon" onClick={() => console.log('Next page')}>
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

type PetCardProps = {
  name: string;
  status: string;
  breed: string;
  age: number;
  gender: string;
  description: string;
  shelter: string;
};

function PetCard({
  name,
  status,
  breed,
  age,
  gender,
  description,
  shelter,
}: PetCardProps) {
  return (
    <a href={`/adopt/${name.toLowerCase()}`} className="block no-underline text-inherit">
      <Card className="overflow-hidden hover:shadow-md transition cursor-pointer">
        <div className="h-48 bg-neutral-200 relative">
          <Button
            variant="outline"
            size="icon"
            className="absolute top-3 right-3 bg-white rounded-full p-1.5 text-neutral-400 hover:text-secondary border-none"
            onClick={(e) => {
              e.stopPropagation();
              e.preventDefault();
              console.log(`Added ${name} to favorites`);
            }}
          >
            <Heart className="h-4 w-4" />
          </Button>
        </div>
        <CardContent className="p-4">
          <div className="flex justify-between items-center mb-2">
            <h4 className="font-heading font-bold text-lg text-neutral-800">{name}</h4>
            <Badge className="text-xs font-semibold bg-accent bg-opacity-10 text-accent rounded-full px-2 py-1">
              {status}
            </Badge>
          </div>
          <div className="flex flex-wrap gap-2 mb-3">
            <span className="text-xs bg-neutral-100 text-neutral-600 rounded-full px-2 py-0.5">
              {breed}
            </span>
            <span className="text-xs bg-neutral-100 text-neutral-600 rounded-full px-2 py-0.5">
              {age} {age === 1 ? "year" : "years"}
            </span>
            <span className="text-xs bg-neutral-100 text-neutral-600 rounded-full px-2 py-0.5">
              {gender}
            </span>
          </div>
          <p className="text-neutral-600 text-sm mb-3 line-clamp-2">{description}</p>
          <div className="flex justify-between items-center">
            <div className="flex items-center text-neutral-500 text-xs">
              <MapPin className="h-3 w-3 mr-1" />
              <span>{shelter}</span>
            </div>
            <Button
              variant="link"
              className="text-primary hover:text-primary-dark font-semibold text-sm p-0"
            >
              View Details
            </Button>
          </div>
        </CardContent>
      </Card>
    </a>
  );
}
