import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { UserType } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, User, Shield, Download, Save } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function ProfilePage() {
  const { userProfile, isLoading, logout } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [isSaving, setIsSaving] = useState(false);
  
  // If not logged in, redirect to auth page
  if (!isLoading && !userProfile) {
    navigate("/auth");
    return null;
  }
  
  // Profile form schema (changes depending on user type)
  const baseProfileSchema = z.object({
    name: z.string().min(2, "Name must be at least 2 characters"),
    email: z.string().email("Please enter a valid email"),
    location: z.string().optional(),
  });
  
  // Pet owner specific fields
  const petOwnerFormSchema = baseProfileSchema.extend({
    bio: z.string().optional(),
    preferences: z.string().optional(),
  });
  
  // Service provider specific fields
  const serviceProviderFormSchema = baseProfileSchema.extend({
    businessName: z.string().min(2, "Business name is required"),
    description: z.string().min(10, "Please provide a description of your services"),
    address: z.string().min(5, "Business address is required"),
    phone: z.string().min(10, "Please provide a valid phone number"),
    category: z.string().min(1, "Please select a service category"),
  });
  
  // Shelter specific fields
  const shelterFormSchema = baseProfileSchema.extend({
    organizationName: z.string().min(2, "Organization name is required"),
    description: z.string().min(10, "Please provide a description of your shelter"),
    address: z.string().min(5, "Shelter address is required"),
    phone: z.string().min(10, "Please provide a valid phone number"),
  });
  
  // Get the right schema based on user type
  const getSchemaForUserType = () => {
    if (!userProfile) return baseProfileSchema;
    
    switch (userProfile.userType) {
      case UserType.PET_OWNER:
        return petOwnerFormSchema;
      case UserType.SERVICE_PROVIDER:
        return serviceProviderFormSchema;
      case UserType.SHELTER:
        return shelterFormSchema;
      default:
        return baseProfileSchema;
    }
  };
  
  // Form with the right schema
  const form = useForm({
    resolver: zodResolver(getSchemaForUserType()),
    defaultValues: {
      name: userProfile?.name || "",
      email: userProfile?.email || "",
      location: userProfile?.location || "",
      bio: userProfile?.bio || "",
      preferences: userProfile?.preferences || "",
      businessName: userProfile?.businessName || "",
      organizationName: userProfile?.organizationName || "",
      description: userProfile?.description || "",
      address: userProfile?.address || "",
      phone: userProfile?.phone || "",
      category: userProfile?.category || "",
    },
  });
  
  // Handle form submission
  const onSubmit = async (values: any) => {
    setIsSaving(true);
    try {
      const response = await apiRequest("PUT", "/api/user/profile", values);
      
      if (response.ok) {
        toast({
          title: "Profile updated",
          description: "Your profile has been successfully updated.",
          variant: "default",
        });
      } else {
        toast({
          title: "Update failed",
          description: "Failed to update your profile. Please try again.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while updating your profile.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };
  
  // Handle account deletion (GDPR compliance)
  const handleDeleteAccount = async () => {
    try {
      const response = await apiRequest("DELETE", "/api/user");
      
      if (response.ok) {
        toast({
          title: "Account deleted",
          description: "Your account has been permanently deleted.",
          variant: "default",
        });
        
        // Log the user out
        await logout();
        navigate("/");
      } else {
        toast({
          title: "Deletion failed",
          description: "Failed to delete your account. Please try again.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while deleting your account.",
        variant: "destructive",
      });
    }
  };
  
  // Handle data export (GDPR compliance)
  const handleExportData = async () => {
    try {
      const response = await apiRequest("GET", "/api/user/export-data");
      
      if (response.ok) {
        const data = await response.json();
        
        // Create a JSON file for download
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `petpals-data-${new Date().toISOString().split("T")[0]}.json`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        
        toast({
          title: "Data exported",
          description: "Your data has been exported successfully.",
          variant: "default",
        });
      } else {
        toast({
          title: "Export failed",
          description: "Failed to export your data. Please try again.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred while exporting your data.",
        variant: "destructive",
      });
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <div className="container mx-auto py-10 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-primary">My Account</h1>
          <p className="text-neutral-600 mt-2">
            Manage your profile information and account settings
          </p>
        </div>
        
        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="grid grid-cols-3 w-full mb-8">
            <TabsTrigger value="profile" className="flex items-center">
              <User className="mr-2 h-4 w-4" />
              Profile
            </TabsTrigger>
            <TabsTrigger value="privacy" className="flex items-center">
              <Shield className="mr-2 h-4 w-4" />
              Privacy & Data
            </TabsTrigger>
            <TabsTrigger value="account" className="flex items-center">
              <svg className="mr-2 h-4 w-4" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"></path>
                <circle cx="12" cy="7" r="4"></circle>
              </svg>
              Account
            </TabsTrigger>
          </TabsList>
          
          {/* Profile Tab */}
          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
                <CardDescription>
                  Update your personal information and how others see you on the platform
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    {/* Basic Fields for All User Types */}
                    <div className="grid gap-6 md:grid-cols-2">
                      <FormField
                        control={form.control}
                        name="name"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Full Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Your name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input 
                                placeholder="your@email.com" 
                                {...field}
                                disabled={true} // Email cannot be changed
                              />
                            </FormControl>
                            <FormDescription>
                              Email cannot be changed for security reasons
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="location"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Location</FormLabel>
                          <FormControl>
                            <Input placeholder="City, State" {...field} />
                          </FormControl>
                          <FormDescription>
                            Where are you located? This helps us show you relevant services and pets.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    {/* Pet Owner Fields */}
                    {userProfile?.userType === UserType.PET_OWNER && (
                      <>
                        <Separator className="my-6" />
                        <h3 className="text-lg font-semibold mb-4">Pet Owner Information</h3>
                        
                        <FormField
                          control={form.control}
                          name="bio"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>About Me</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Tell us about yourself and your pets" 
                                  className="min-h-[120px]"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="preferences"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Preferences</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="What are your preferences for pet services and resources?" 
                                  className="min-h-[100px]"
                                  {...field} 
                                />
                              </FormControl>
                              <FormDescription>
                                Let us know your preferences to customize your experience
                              </FormDescription>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </>
                    )}
                    
                    {/* Service Provider Fields */}
                    {userProfile?.userType === UserType.SERVICE_PROVIDER && (
                      <>
                        <Separator className="my-6" />
                        <h3 className="text-lg font-semibold mb-4">Business Information</h3>
                        
                        <FormField
                          control={form.control}
                          name="businessName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Business Name</FormLabel>
                              <FormControl>
                                <Input placeholder="Your business name" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Business Description</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Describe your business and services" 
                                  className="min-h-[120px]"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid gap-6 md:grid-cols-2">
                          <FormField
                            control={form.control}
                            name="category"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Service Category</FormLabel>
                                <FormControl>
                                  <Input placeholder="Main service category" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <FormField
                            control={form.control}
                            name="phone"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Business Phone</FormLabel>
                                <FormControl>
                                  <Input placeholder="Business phone number" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={form.control}
                          name="address"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Business Address</FormLabel>
                              <FormControl>
                                <Input placeholder="Full address" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </>
                    )}
                    
                    {/* Shelter Fields */}
                    {userProfile?.userType === UserType.SHELTER && (
                      <>
                        <Separator className="my-6" />
                        <h3 className="text-lg font-semibold mb-4">Shelter Information</h3>
                        
                        <FormField
                          control={form.control}
                          name="organizationName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Organization Name</FormLabel>
                              <FormControl>
                                <Input placeholder="Your shelter or organization name" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={form.control}
                          name="description"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Shelter Description</FormLabel>
                              <FormControl>
                                <Textarea 
                                  placeholder="Describe your shelter and mission" 
                                  className="min-h-[120px]"
                                  {...field} 
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="grid gap-6 md:grid-cols-2">
                          <FormField
                            control={form.control}
                            name="phone"
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>Contact Phone</FormLabel>
                                <FormControl>
                                  <Input placeholder="Contact phone number" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>
                        
                        <FormField
                          control={form.control}
                          name="address"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Shelter Address</FormLabel>
                              <FormControl>
                                <Input placeholder="Full address" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </>
                    )}
                    
                    <Button 
                      type="submit" 
                      className="w-full md:w-auto"
                      disabled={isSaving}
                    >
                      {isSaving ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Saving Changes...
                        </>
                      ) : (
                        <>
                          <Save className="mr-2 h-4 w-4" />
                          Save Changes
                        </>
                      )}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
          
          {/* Privacy Tab - GDPR Compliance */}
          <TabsContent value="privacy">
            <Card>
              <CardHeader>
                <CardTitle>Privacy & Data Settings</CardTitle>
                <CardDescription>
                  Manage your data and privacy preferences according to GDPR regulations
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="bg-primary/5 rounded-lg p-6">
                  <h3 className="text-lg font-semibold mb-2">Your Data Rights</h3>
                  <p className="text-neutral-600 mb-4">
                    According to GDPR, you have the right to access, export, or delete your personal data at any time.
                  </p>
                  <div className="flex flex-col md:flex-row gap-4">
                    <Button 
                      variant="outline" 
                      className="flex items-center"
                      onClick={handleExportData}
                    >
                      <Download className="mr-2 h-4 w-4" />
                      Export My Data
                    </Button>
                    
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button 
                          variant="destructive"
                          className="flex items-center"
                        >
                          Delete My Account
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
                          <AlertDialogDescription>
                            This action cannot be undone. This will permanently delete your
                            account and remove all your data from our servers.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction onClick={handleDeleteAccount}>
                            Yes, delete my account
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-2">Communication Preferences</h3>
                  <p className="text-neutral-600 mb-4">
                    Control what type of communications you receive from us.
                  </p>
                  
                  <div className="space-y-4">
                    {/* This would be populated based on the user's actual consent settings */}
                    <div className="flex items-center space-x-2">
                      <input 
                        type="checkbox" 
                        id="marketing" 
                        className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                        defaultChecked
                      />
                      <label htmlFor="marketing" className="text-sm font-medium leading-none">
                        Marketing emails and notifications
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <input 
                        type="checkbox" 
                        id="updates" 
                        className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                        defaultChecked
                      />
                      <label htmlFor="updates" className="text-sm font-medium leading-none">
                        Platform updates and news
                      </label>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <input 
                        type="checkbox" 
                        id="recommendations" 
                        className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                        defaultChecked
                      />
                      <label htmlFor="recommendations" className="text-sm font-medium leading-none">
                        Service and pet recommendations
                      </label>
                    </div>
                  </div>
                  
                  <Button className="mt-4">
                    Save Preferences
                  </Button>
                </div>
              </CardContent>
              <CardFooter className="flex flex-col items-start border-t pt-6">
                <h3 className="text-sm font-semibold mb-2">Privacy Policy</h3>
                <p className="text-neutral-600 text-sm mb-2">
                  Our Privacy Policy explains how we collect, use, and protect your personal data.
                </p>
                <Button variant="link" className="p-0 h-auto">
                  View Privacy Policy
                </Button>
              </CardFooter>
            </Card>
          </TabsContent>
          
          {/* Account Tab */}
          <TabsContent value="account">
            <Card>
              <CardHeader>
                <CardTitle>Account Settings</CardTitle>
                <CardDescription>
                  Manage your account security and preferences
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="text-lg font-semibold mb-4">Account Type</h3>
                  <div className="flex items-center space-x-4 p-4 bg-primary/5 rounded-lg">
                    {userProfile?.userType === UserType.PET_OWNER && (
                      <div className="flex items-center">
                        <svg className="h-8 w-8 text-primary" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M10 5.172C10 3.12 8.21 1.88 6.5 2.75"></path>
                          <path d="M14 5.172C14 3.12 15.79 1.88 17.5 2.75"></path>
                          <path d="M9 11a4 4 0 0 0-4-4 4 4 0 0 0-4 4"></path>
                          <path d="M19 11a4 4 0 0 0-4-4 4 4 0 0 0-4 4"></path>
                          <path d="M12 19c-3.4-4.8-7-5.2-10-2"></path>
                          <path d="M12 19c3.4-4.8 7-5.2 10-2"></path>
                          <path d="M12 19v-5"></path>
                        </svg>
                        <div className="ml-4">
                          <p className="font-semibold">Pet Owner</p>
                          <p className="text-sm text-neutral-600">Standard access to pet services and adoption</p>
                        </div>
                      </div>
                    )}
                    
                    {userProfile?.userType === UserType.SERVICE_PROVIDER && (
                      <div className="flex items-center">
                        <svg className="h-8 w-8 text-primary" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M9 6V3c0-.6.4-1 1-1h4c.6 0 1 .4 1 1v3"></path>
                          <path d="M19 6v14c0 .6-.4 1-1 1H6c-.6 0-1-.4-1-1V6"></path>
                          <path d="M5 11h14"></path>
                          <path d="M9 11v6"></path>
                          <path d="M12 11v6"></path>
                          <path d="M15 11v6"></path>
                        </svg>
                        <div className="ml-4">
                          <p className="font-semibold">Service Provider</p>
                          <p className="text-sm text-neutral-600">Offer pet care services on the platform</p>
                        </div>
                      </div>
                    )}
                    
                    {userProfile?.userType === UserType.SHELTER && (
                      <div className="flex items-center">
                        <svg className="h-8 w-8 text-primary" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                          <polyline points="9 22 9 12 15 12 15 22"></polyline>
                        </svg>
                        <div className="ml-4">
                          <p className="font-semibold">Shelter / Organization</p>
                          <p className="text-sm text-neutral-600">List pets for adoption and manage applications</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                
                <div>
                  <h3 className="text-lg font-semibold mb-4">Security</h3>
                  <Button className="mb-4">Change Password</Button>
                  
                  <div className="mt-8">
                    <h4 className="font-medium mb-2">Two-Factor Authentication</h4>
                    <p className="text-neutral-600 text-sm mb-4">
                      Add an extra layer of security to your account by enabling two-factor authentication.
                    </p>
                    <Button variant="outline">Enable 2FA</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}