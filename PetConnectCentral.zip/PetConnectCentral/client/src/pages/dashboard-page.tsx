import { useAuth } from "@/contexts/AuthContext";
import { UserType } from "@shared/schema";
import { useLocation } from "wouter";
import { Loader2 } from "lucide-react";
import PetOwnerDashboard from "@/components/dashboard/pet-owner-dashboard";
import ServiceProviderDashboard from "@/components/dashboard/service-provider-dashboard";
import ShelterDashboard from "@/components/dashboard/shelter-dashboard";

export default function DashboardPage() {
  const { userProfile, isLoading } = useAuth();
  const [, navigate] = useLocation();
  
  // If not logged in, redirect to auth page
  if (!isLoading && !userProfile) {
    navigate("/auth");
    return null;
  }
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  // Show appropriate dashboard based on user type
  switch (userProfile?.userType) {
    case UserType.PET_OWNER:
      return <PetOwnerDashboard />;
    case UserType.SERVICE_PROVIDER:
      return <ServiceProviderDashboard />;
    case UserType.SHELTER:
      return <ShelterDashboard />;
    default:
      // Fallback to pet owner dashboard if type is unknown
      return <PetOwnerDashboard />;
  }
}