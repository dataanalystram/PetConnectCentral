import { useAuth } from "@/contexts/AuthContext";
import AddPetForm from "@/components/pets/add-pet-form";
import { Loader2 } from "lucide-react";
import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Pet } from "@shared/schema";

interface AddPetPageProps {
  isEditMode?: boolean;
}

export default function AddPetPage({ isEditMode = false }: AddPetPageProps) {
  const { userProfile } = useAuth();
  const params = useParams<{ id: string }>();
  const petId = params.id ? parseInt(params.id) : undefined;
  
  const { data: pet, isLoading: isPetLoading } = useQuery<Pet>({
    queryKey: isEditMode && petId ? ['/api/pets', petId] : ['skip-query'],
    queryFn: async () => {
      const response = await fetch(`/api/pets/${petId}`);
      if (!response.ok) {
        throw new Error('Failed to fetch pet data');
      }
      return response.json();
    },
    enabled: isEditMode && !!petId,
    staleTime: Infinity,
  });
  
  if (!userProfile || (isEditMode && isPetLoading)) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold mb-6">
        {isEditMode ? `Edit ${pet ? pet.name : 'Pet'}` : 'Add a New Pet'}
      </h1>
      <AddPetForm 
        isEditMode={isEditMode} 
        petId={petId} 
        initialData={pet} 
      />
    </div>
  );
}