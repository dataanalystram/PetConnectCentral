import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { UserType } from "@shared/schema";
import { useAuth } from "@/contexts/AuthContext";
import { signInWithGoogle, loginWithEmailAndPassword, registerWithEmailAndPassword } from "@/lib/auth";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { useSearchParams } from "@/lib/use-search-params";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PawPrint, LogIn, UserPlus, ArrowLeft } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import WelcomeScreen from "@/components/auth/welcome-screen";
import RegistrationFlow from "@/components/auth/registration-flow";
import TestUserLogin from "@/components/auth/test-user-login";

export default function AuthPage() {
  const { currentUser, updateUserRole } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [registrationStep, setRegistrationStep] = useState<"welcome" | "form" | "flow">("welcome");
  const [selectedUserType, setSelectedUserType] = useState<UserType | null>(null);
  const [advancedFormData, setAdvancedFormData] = useState<any>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Email and password login form
  const loginForm = useForm({
    resolver: zodResolver(
      z.object({
        email: z.string().email("Please enter a valid email"),
        password: z.string().min(6, "Password must be at least 6 characters"),
      })
    ),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  // Email and password registration form
  const registerForm = useForm({
    resolver: zodResolver(
      z.object({
        name: z.string().min(2, "Full name is required"),
        email: z.string().email("Please enter a valid email"),
        password: z.string().min(6, "Password must be at least 6 characters"),
        confirmPassword: z.string(),
      }).refine(data => data.password === data.confirmPassword, {
        message: "Passwords do not match",
        path: ["confirmPassword"],
      })
    ),
    defaultValues: {
      name: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
  });

  // Get URL query parameters
  const searchParams = useSearchParams();
  
  // Set user type from URL parameter if present
  useEffect(() => {
    const typeParam = searchParams.type;
    if (typeParam) {
      if (typeParam === 'shelter') {
        setSelectedUserType(UserType.SHELTER);
        setRegistrationStep("form");
      } else if (typeParam === 'service_provider') {
        setSelectedUserType(UserType.SERVICE_PROVIDER);
        setRegistrationStep("form");
      } else if (typeParam === 'pet_owner') {
        setSelectedUserType(UserType.PET_OWNER);
        setRegistrationStep("form");
      }
    }
  }, [searchParams]);
  
  // Redirect if user is already logged in
  useEffect(() => {
    if (currentUser) {
      navigate("/");
    }
  }, [currentUser, navigate]);

  // Handle login submit
  const onLoginSubmit = async (values: { email: string; password: string }) => {
    setIsSubmitting(true);
    try {
      const user = await loginWithEmailAndPassword(values.email, values.password);
      if (user) {
        toast({
          title: "Login Successful",
          description: "Welcome back!",
        });
        navigate("/dashboard");
      }
    } catch (error: any) {
      toast({
        title: "Login Failed",
        description: error.message || "Invalid email or password",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle regular registration submit
  const onRegisterSubmit = async (values: { name: string; email: string; password: string }) => {
    if (!selectedUserType && registrationStep === "form") {
      // Always force user type selection before registration
      setRegistrationStep("welcome");
      return;
    }
    
    setIsSubmitting(true);
    try {
      console.log("Registering with user type:", selectedUserType);
      
      if (!selectedUserType) {
        throw new Error("Please select your user type before registering");
      }
      
      // Register the user with Firebase and our database
      const user = await registerWithEmailAndPassword(
        values.email, 
        values.password, 
        values.name,
        selectedUserType
      );
      
      // After successful registration, ensure the proper role is set in the database
      // This is a failsafe to ensure Firebase and PostgreSQL are in sync
      if (user) {
        try {
          // Ensure the role is set correctly in the database
          await updateUserRole(selectedUserType);
          
          // Show success toast
          toast({
            title: "Registration Successful",
            description: `Welcome to PetPals as a ${selectedUserType.replace('_', ' ')}!`,
          });
          
          // After successful registration, navigate to the appropriate page
          navigate("/dashboard");
        } catch (roleError: any) {
          console.error("Error setting user role:", roleError);
          // Continue anyway, as we can fix this later
        }
      }
    } catch (error: any) {
      console.error("Registration error:", error);
      toast({
        title: "Registration Failed",
        description: error.message || "Could not create your account",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Google sign in
  const handleGoogleSignIn = async () => {
    try {
      console.log("Attempting Google sign in");
      const user = await signInWithGoogle();
      
      // After Google sign in, check if user type needs to be selected
      if (user) {
        // Fetch user profile from database to check if user type is already set
        const userProfileResponse = await apiRequest('GET', '/api/user/profile');
        if (userProfileResponse.ok) {
          const profile = await userProfileResponse.json();
          
          // If the user profile exists but has no user type, prompt them to select one
          if (profile && !profile.userType) {
            setRegistrationStep("welcome");
            toast({
              title: "Welcome to PetPals",
              description: "Please select how you'll be using our platform",
            });
          }
        }
      }
    } catch (error: any) {
      console.error("Google sign in error:", error);
      toast({
        title: "Google Sign In Failed",
        description: error.message || "Could not sign in with Google",
        variant: "destructive",
      });
    }
  };

  // Handle user type selection
  const handleUserTypeSelect = async (userType: UserType) => {
    try {
      setSelectedUserType(userType);
      if (currentUser) {
        // If user exists, update their role
        await updateUserRole(userType);
      }
      setRegistrationStep("flow");
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to set user type",
        variant: "destructive",
      });
    }
  };

  // Handle flow completion
  const handleFlowComplete = (data: any) => {
    setAdvancedFormData(data);
    setRegistrationStep("form");
  };

  // If showing welcome screen for user type selection
  // Only show the welcome screen in register mode, not for login
  if (registrationStep === "welcome") {
    return (
      <div className="min-h-screen bg-neutral-50 py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl mx-auto">
            <WelcomeScreen 
              onUserTypeSelect={handleUserTypeSelect} 
              onSkip={() => setRegistrationStep("form")} 
            />
          </div>
        </div>
      </div>
    );
  }

  // If showing the multi-step registration flow
  // This happens during registration, not login
  if (registrationStep === "flow" && selectedUserType) {
    return (
      <div className="min-h-screen bg-neutral-50 py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-lg mx-auto">
            <RegistrationFlow 
              userType={selectedUserType}
              onBack={() => setRegistrationStep("welcome")}
              onComplete={handleFlowComplete}
            />
          </div>
        </div>
      </div>
    );
  }

  // Render standard login/registration form
  return (
    <div className="min-h-screen bg-neutral-50 py-12">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {/* Hero Section */}
          <div className="flex flex-col justify-center">
            <div className="flex items-center mb-6">
              <PawPrint className="h-10 w-10 text-primary mr-2" />
              <h1 className="font-heading font-bold text-3xl text-primary-dark">PetPals</h1>
            </div>
            <h2 className="font-heading font-bold text-3xl md:text-4xl text-primary mb-4">
              Welcome to your pet care companion
            </h2>
            <p className="text-neutral-600 text-lg mb-6">
              Join our community of pet lovers and access a world of services, adoption opportunities, and resources for your furry friends.
            </p>
            <div className="bg-primary bg-opacity-5 rounded-xl p-6 mb-4">
              <h3 className="font-heading font-semibold text-xl text-neutral-800 mb-2">What you can do:</h3>
              <ul className="space-y-2">
                <li className="flex items-start">
                  <span className="text-primary mr-2">✓</span>
                  <span>Find and book trusted pet care services</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-2">✓</span>
                  <span>Discover adoptable pets from shelters and rescues</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-2">✓</span>
                  <span>Access expert pet care resources and articles</span>
                </li>
                <li className="flex items-start">
                  <span className="text-primary mr-2">✓</span>
                  <span>Connect with other pet owners in your area</span>
                </li>
              </ul>
            </div>
            {selectedUserType && (
              <div className="mt-2">
                <Button variant="outline" size="sm" onClick={() => setRegistrationStep("welcome")}>
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Change user type
                </Button>
              </div>
            )}
          </div>
          
          {/* Auth Forms */}
          <div>
            <Tabs 
              defaultValue={searchParams.tab === "register" ? "register" : "login"} 
              className="w-full"
            >
              <TabsList className="grid w-full grid-cols-2 mb-4">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
              </TabsList>
              
              {/* Login Form */}
              <TabsContent value="login">
                <Card>
                  <CardHeader>
                    <CardTitle>Login to your account</CardTitle>
                    <CardDescription>
                      Enter your credentials to access your PetPals account
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...loginForm}>
                      <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                        <FormField
                          control={loginForm.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email</FormLabel>
                              <FormControl>
                                <Input placeholder="you@example.com" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={loginForm.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Password</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="••••••••" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button 
                          type="submit" 
                          className="w-full" 
                          disabled={isSubmitting}
                        >
                          {isSubmitting ? (
                            <>
                              <span className="animate-pulse">Logging in...</span>
                            </>
                          ) : (
                            <>
                              <LogIn className="mr-2 h-4 w-4" />
                              Login
                            </>
                          )}
                        </Button>
                      </form>
                    </Form>
                    
                    <div className="relative my-6">
                      <div className="absolute inset-0 flex items-center">
                        <Separator className="w-full" />
                      </div>
                      <div className="relative flex justify-center">
                        <span className="bg-white px-2 text-xs text-neutral-500">
                          OR CONTINUE WITH
                        </span>
                      </div>
                    </div>
                    
                    <Button
                      variant="outline"
                      className="w-full mb-6"
                      onClick={handleGoogleSignIn}
                    >
                      <svg className="mr-2 h-4 w-4" viewBox="0 0 48 48">
                        <path fill="#FFC107" d="M43.6 20H24v8h11.3c-1.1 5.2-5.8 8-11.3 8-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l6.1-6.1C34.2 5.1 29.3 3 24 3 14.1 3 6 11.1 6 21s8.1 18 18 18c14.4 0 18-13.2 16.5-19h-16.2z" />
                        <path fill="#FF3D00" d="M6.3 14.7l7.1 5.4c1.6-4.8 6.2-8.1 11.4-8.1 3.1 0 5.9 1.2 8 3.1l6.1-6.1C34.2 5.1 29.3 3 24 3 16.3 3 9.7 7.8 6.3 14.7z" />
                        <path fill="#4CAF50" d="M24 39c5.2 0 9.9-2 13.1-5.4l-6.8-5.8c-1.8 1.2-4.1 2.2-6.3 2.2-5.5 0-10.1-3.7-11.8-8.8l-7.2 5.5C8.9 34.1 15.7 39 24 39z" />
                        <path fill="#1976D2" d="M43.6 20H24v8h11.3c-.5 2.4-2 4.6-4.1 5.8l6.8 5.8c4.8-4.4 6-10.8 5.6-19.6z" />
                      </svg>
                      Continue with Google
                    </Button>
                    
                    {/* Test user login component */}
                    <div className="relative my-6">
                      <div className="absolute inset-0 flex items-center">
                        <Separator className="w-full" />
                      </div>
                      <div className="relative flex justify-center">
                        <span className="bg-white px-2 text-xs text-neutral-500">
                          TEST ACCOUNTS
                        </span>
                      </div>
                    </div>
                    
                    {/* Import the test user login component */}
                    <div className="mt-4">
                      <TestUserLogin />
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
              
              {/* Register Form */}
              <TabsContent value="register">
                <Card>
                  <CardHeader>
                    <CardTitle>Create your account</CardTitle>
                    <CardDescription>
                      Join PetPals to access all features and services
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Form {...registerForm}>
                      <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                        <FormField
                          control={registerForm.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Full Name</FormLabel>
                              <FormControl>
                                <Input placeholder="John Doe" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={registerForm.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Email</FormLabel>
                              <FormControl>
                                <Input placeholder="you@example.com" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={registerForm.control}
                          name="password"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Password</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="••••••••" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <FormField
                          control={registerForm.control}
                          name="confirmPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Confirm Password</FormLabel>
                              <FormControl>
                                <Input type="password" placeholder="••••••••" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        <Button 
                          type="submit" 
                          className="w-full" 
                          disabled={isSubmitting}
                        >
                          {isSubmitting ? (
                            <>
                              <span className="animate-pulse">Creating account...</span>
                            </>
                          ) : (
                            <>
                              <UserPlus className="mr-2 h-4 w-4" />
                              Create Account
                            </>
                          )}
                        </Button>
                      </form>
                    </Form>
                    
                    <div className="relative my-6">
                      <div className="absolute inset-0 flex items-center">
                        <Separator className="w-full" />
                      </div>
                      <div className="relative flex justify-center">
                        <span className="bg-white px-2 text-xs text-neutral-500">
                          OR CONTINUE WITH
                        </span>
                      </div>
                    </div>
                    
                    <Button
                      variant="outline"
                      className="w-full"
                      onClick={handleGoogleSignIn}
                    >
                      <svg className="mr-2 h-4 w-4" viewBox="0 0 48 48">
                        <path fill="#FFC107" d="M43.6 20H24v8h11.3c-1.1 5.2-5.8 8-11.3 8-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.9 1.2 8 3.1l6.1-6.1C34.2 5.1 29.3 3 24 3 14.1 3 6 11.1 6 21s8.1 18 18 18c14.4 0 18-13.2 16.5-19h-16.2z" />
                        <path fill="#FF3D00" d="M6.3 14.7l7.1 5.4c1.6-4.8 6.2-8.1 11.4-8.1 3.1 0 5.9 1.2 8 3.1l6.1-6.1C34.2 5.1 29.3 3 24 3 16.3 3 9.7 7.8 6.3 14.7z" />
                        <path fill="#4CAF50" d="M24 39c5.2 0 9.9-2 13.1-5.4l-6.8-5.8c-1.8 1.2-4.1 2.2-6.3 2.2-5.5 0-10.1-3.7-11.8-8.8l-7.2 5.5C8.9 34.1 15.7 39 24 39z" />
                        <path fill="#1976D2" d="M43.6 20H24v8h11.3c-.5 2.4-2 4.6-4.1 5.8l6.8 5.8c4.8-4.4 6-10.8 5.6-19.6z" />
                      </svg>
                      Continue with Google
                    </Button>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  );
}