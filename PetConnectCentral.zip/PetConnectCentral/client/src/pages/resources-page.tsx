import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Loader2,
  Search,
  BookOpen,
  Play,
  MessageSquare,
  ChevronRight,
  Clock,
} from "lucide-react";
import { Resource } from "@shared/schema";
import { resourceCategories } from "@/data/resources";

export default function ResourcesPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  // Fetch resources
  const { data: resources, isLoading, error } = useQuery<Resource[]>({
    queryKey: ["/api/resources"],
  });

  // Filter resources based on search and category
  const filteredResources = resources
    ? resources.filter((resource) => {
        const matchesSearch =
          searchQuery === "" ||
          resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          resource.content.toLowerCase().includes(searchQuery.toLowerCase());

        const matchesCategory =
          selectedCategory === "all" || resource.category === selectedCategory;

        return matchesSearch && matchesCategory;
      })
    : [];

  return (
    <div className="bg-neutral-50 min-h-screen">
      <div className="bg-primary py-12">
        <div className="container mx-auto px-4">
          <h1 className="font-heading font-bold text-3xl md:text-4xl text-white mb-4">
            Pet Care Resources
          </h1>
          <p className="text-white text-lg opacity-90 mb-8 max-w-2xl">
            Access expert advice, educational content, and community discussions to provide the best care for your pets.
          </p>

          {/* Search Bar */}
          <div className="bg-white p-4 rounded-xl shadow-md max-w-2xl mx-auto">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 h-5 w-5" />
              <Input 
                type="text" 
                className="pl-10 pr-4 py-6 rounded-lg border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-primary" 
                placeholder="Search resources, articles, and topics"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        {/* Resource Types Tabs */}
        <Tabs defaultValue="articles" className="mb-8">
          <TabsList className="bg-white p-1 rounded-lg">
            <TabsTrigger value="articles">
              <BookOpen className="h-4 w-4 mr-2" />
              Articles & Guides
            </TabsTrigger>
            <TabsTrigger value="videos">
              <Play className="h-4 w-4 mr-2" />
              Training Videos
            </TabsTrigger>
            <TabsTrigger value="community">
              <MessageSquare className="h-4 w-4 mr-2" />
              Community Forums
            </TabsTrigger>
          </TabsList>

          {/* Articles & Guides */}
          <TabsContent value="articles">
            {/* Categories */}
            <div className="flex flex-wrap gap-2 mb-6">
              <Button
                variant={selectedCategory === "all" ? "default" : "outline"}
                className="rounded-full"
                onClick={() => setSelectedCategory("all")}
              >
                All Topics
              </Button>
              {resourceCategories.map((category) => (
                <Button
                  key={category.value}
                  variant={selectedCategory === category.value ? "default" : "outline"}
                  className="rounded-full"
                  onClick={() => setSelectedCategory(category.value)}
                >
                  {category.label}
                </Button>
              ))}
            </div>

            {/* Featured Article */}
            <Card className="mb-8">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-neutral-200 min-h-[300px] md:min-h-full"></div>
                <div className="p-6 flex flex-col justify-center">
                  <div className="text-xs text-neutral-500 mb-2">
                    <span>Nutrition</span>
                    <span className="mx-2">•</span>
                    <span>10 min read</span>
                  </div>
                  <h2 className="font-heading font-bold text-2xl text-neutral-800 mb-3">
                    A Complete Guide to Balanced Nutrition for Dogs and Cats
                  </h2>
                  <p className="text-neutral-600 mb-4">
                    Understanding what to feed your pets is crucial for their health and longevity. This comprehensive guide covers essential nutrients, feeding schedules, and special dietary needs.
                  </p>
                  <div className="flex items-center mb-4">
                    <div className="w-10 h-10 rounded-full bg-neutral-300 mr-3"></div>
                    <div>
                      <div className="font-semibold text-neutral-800">Dr. Michael Brown</div>
                      <div className="text-xs text-neutral-500">Veterinary Nutritionist</div>
                    </div>
                  </div>
                  <Button className="self-start">Read Full Article</Button>
                </div>
              </div>
            </Card>

            {/* Articles Grid */}
            <h3 className="font-heading font-bold text-2xl mb-4">Latest Articles</h3>
            {isLoading ? (
              <div className="flex items-center justify-center h-64">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : error ? (
              <div className="bg-white rounded-xl p-6 text-center">
                <p className="text-red-500">Error loading resources. Please try again.</p>
              </div>
            ) : filteredResources.length === 0 ? (
              <div className="bg-white rounded-xl p-6 text-center">
                <p>No resources found matching your criteria.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Using mock data from resources */}
                <ArticleCard
                  title="5 Essential Vaccinations for Puppies"
                  category="Veterinary Care"
                  readTime={5}
                  excerpt="Learn about the critical vaccines your new puppy needs in their first year to stay healthy and protected."
                  author="Dr. Sarah Wilson"
                  date="May 15, 2023"
                />
                <ArticleCard
                  title="Understanding Cat Behavior: What Your Cat Is Trying to Tell You"
                  category="Behavior"
                  readTime={7}
                  excerpt="Decode your cat's body language and vocalizations to better understand their needs and emotions."
                  author="Emma Chen"
                  date="Jun 2, 2023"
                />
                <ArticleCard
                  title="Nutritional Guide for Senior Dogs: What to Feed Your Aging Companion"
                  category="Nutrition"
                  readTime={6}
                  excerpt="Tailored dietary recommendations to support your senior dog's health, mobility, and cognitive function."
                  author="Dr. Mark Johnson"
                  date="May 28, 2023"
                />
              </div>
            )}

            <div className="text-center mt-8">
              <Button variant="outline" className="rounded-full">
                View All Articles
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </TabsContent>

          {/* Videos Tab */}
          <TabsContent value="videos">
            <div className="bg-white p-8 rounded-xl text-center">
              <Play className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="font-heading font-bold text-xl mb-2">Training Videos</h3>
              <p className="text-neutral-600 mb-4">
                Our video section is coming soon. Check back for professional training tutorials and educational content.
              </p>
              <Button>Notify Me When Available</Button>
            </div>
          </TabsContent>

          {/* Community Tab */}
          <TabsContent value="community">
            <div className="bg-white p-8 rounded-xl text-center">
              <MessageSquare className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="font-heading font-bold text-xl mb-2">Community Forums</h3>
              <p className="text-neutral-600 mb-4">
                Our community forums are launching soon. Join discussions with other pet owners and experts.
              </p>
              <Button>Notify Me When Available</Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

type ArticleCardProps = {
  title: string;
  category: string;
  readTime: number;
  excerpt: string;
  author: string;
  date: string;
};

function ArticleCard({
  title,
  category,
  readTime,
  excerpt,
  author,
  date,
}: ArticleCardProps) {
  return (
    <Card className="overflow-hidden hover:shadow-md transition cursor-pointer">
      <div className="h-40 bg-neutral-200"></div>
      <CardContent className="p-5">
        <div className="flex items-center text-xs text-neutral-500 mb-2">
          <span>{category}</span>
          <span className="mx-2">•</span>
          <div className="flex items-center">
            <Clock className="h-3 w-3 mr-1" />
            <span>{readTime} min read</span>
          </div>
        </div>
        <h4 className="font-heading font-bold text-lg text-neutral-800 mb-2 line-clamp-2">{title}</h4>
        <p className="text-neutral-600 text-sm mb-3 line-clamp-2">{excerpt}</p>
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-neutral-300 mr-3"></div>
          <div className="text-xs">
            <div className="font-semibold text-neutral-800">{author}</div>
            <div className="text-neutral-500">{date}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
