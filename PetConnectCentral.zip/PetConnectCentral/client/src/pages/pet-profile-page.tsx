import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Pet } from "@shared/schema";

// Extended type for our UI needs
type ExtendedPet = {
  id: number;
  name: string;
  type: string;
  breed: string | null;
  age: number | null;
  gender: string | null;
  description: string | null;
  adoptionStatus: string;
  shelterId: number | null;
  createdAt: Date;
  // UI extensions
  images?: string[];
  story?: string;
  color?: string;
  weight?: string;
  size?: string;
  healthStatus?: {
    vaccinated: boolean;
    neutered: boolean;
    microchipped: boolean;
    specialNeeds: boolean;
  };
  compatibility?: {
    children: number;
    otherDogs: number;
    cats: number;
    smallPets: number;
    apartmentLiving: number;
  };
  activityLevel?: number;
  training?: {
    housebroken: boolean;
    basicCommands: boolean;
    leashTrained: boolean;
    advancedTraining: boolean;
  };
  shelter?: {
    id: number;
    name: string;
    location: string;
    phone: string;
    email: string;
    website: string;
  };
  adoptionFee?: string;
};
import { 
  Loader2, 
  Heart, 
  Clock, 
  Calendar, 
  MapPin, 
  Phone, 
  Mail, 
  ExternalLink,
  BarChart,
  Activity,
  CheckCircle,
  Award,
  Shield,
  ArrowLeft,
  Share2
} from "lucide-react";

// Utility function to safely access nested properties
const safeAccess = <T, K extends keyof T>(obj: T | undefined, key: K): T[K] | undefined => {
  return obj ? obj[key] : undefined;
};

export default function PetProfilePage() {
  const params = useParams();
  const petId = params?.id ? params.id : null; // Keep as string
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [isFavorite, setIsFavorite] = useState(false);

  // Fetch pet details - in a real implementation, we would fetch by ID
  // Placeholder for now, we'll use dummy data
  const { data: pet, isLoading, error } = useQuery<ExtendedPet | undefined>({
    queryKey: ['/api/pets', petId],
    enabled: !!petId
  });

  // Placeholder pet data until API is connected
  const petData: ExtendedPet = {
    id: 1,
    name: "Max",
    type: "dog",
    breed: "German Shepherd",
    age: 2,
    gender: "Male",
    description: "Max is a friendly and energetic German Shepherd who loves outdoor activities and playing fetch. He's great with kids and other dogs, making him a perfect family companion. Max has been trained in basic commands and is house-trained.",
    adoptionStatus: "available",
    shelterId: 1,
    createdAt: new Date(),
    images: [
      "/placeholder-pet-1.jpg",
      "/placeholder-pet-2.jpg",
      "/placeholder-pet-3.jpg",
      "/placeholder-pet-4.jpg"
    ],
    story: "Max was found wandering near a highway three months ago, likely abandoned by previous owners who could no longer care for him. Despite his rough start, he's incredibly trusting and affectionate. Our team has worked with him extensively on socialization and training.",
    color: "Black and Tan",
    weight: "32 kg",
    size: "Large",
    healthStatus: {
      vaccinated: true,
      neutered: true,
      microchipped: true,
      specialNeeds: false
    },
    compatibility: {
      children: 5,
      otherDogs: 4,
      cats: 2,
      smallPets: 1,
      apartmentLiving: 3
    },
    activityLevel: 4,
    training: {
      housebroken: true,
      basicCommands: true,
      leashTrained: true,
      advancedTraining: false
    },
    shelter: {
      id: 1,
      name: "Happy Tails Animal Shelter",
      location: "Berlin, Germany",
      phone: "+49 123 4567890",
      email: "contact@happytails.org",
      website: "https://www.happytails.org"
    },
    adoptionFee: "€250"
  };

  const petImage = (index: number) => {
    // This is a placeholder. In real implementation, we would use actual images from the pet data
    const bgColors = ["bg-blue-200", "bg-green-200", "bg-yellow-200", "bg-red-200"];
    return <div className={`h-full w-full ${bgColors[index % bgColors.length]} rounded-lg flex items-center justify-center`}>
      <Heart className="h-12 w-12 text-primary opacity-50" />
    </div>;
  };

  const toggleFavorite = () => setIsFavorite(!isFavorite);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || (!pet && !petData)) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold text-red-500 mb-4">Error Loading Pet Profile</h1>
        <p className="mb-6">Sorry, we couldn't find details for this pet. Please try again later.</p>
        <Button asChild>
          <Link href="/adoption">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Adoption
          </Link>
        </Button>
      </div>
    );
  }

  // Use mock data for now
  const displayPet = pet || petData;
  
  // Provide default empty objects for optional properties to fix TypeScript errors
  const healthStatus = petData.healthStatus || { vaccinated: false, neutered: false, microchipped: false, specialNeeds: false };
  const compatibility = petData.compatibility || { children: 0, otherDogs: 0, cats: 0, smallPets: 0, apartmentLiving: 0 };
  const training = petData.training || { housebroken: false, basicCommands: false, leashTrained: false, advancedTraining: false };
  const shelter = petData.shelter || { id: 0, name: '', location: '', phone: '', email: '', website: '' };
  const activityLevel = petData.activityLevel || 0;

  return (
    <div className="bg-neutral-50 min-h-screen pb-12">
      {/* Back Navigation */}
      <div className="container mx-auto px-4 py-4">
        <Button variant="ghost" className="mb-4" asChild>
          <Link href="/adoption">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Adoption
          </Link>
        </Button>
      </div>

      {/* Hero Section */}
      <div className="container mx-auto px-4 mb-8">
        <div className="bg-white rounded-xl overflow-hidden shadow-md">
          <div className="grid md:grid-cols-2 gap-6 p-6">
            {/* Photo Gallery */}
            <div className="space-y-4">
              <div className="h-80 rounded-lg overflow-hidden">
                {petImage(activeImageIndex)}
              </div>
              <div className="grid grid-cols-4 gap-2">
                {[0, 1, 2, 3].map((index) => (
                  <div 
                    key={index}
                    className={`h-20 rounded-lg overflow-hidden cursor-pointer transition-all 
                      ${activeImageIndex === index ? 'ring-2 ring-primary' : 'opacity-70'}`}
                    onClick={() => setActiveImageIndex(index)}
                  >
                    {petImage(index)}
                  </div>
                ))}
              </div>
            </div>

            {/* Pet Info */}
            <div className="flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h1 className="font-heading font-bold text-3xl md:text-4xl text-neutral-800 mb-2">
                      {displayPet.name}
                    </h1>
                    <div className="flex flex-wrap gap-2 mb-4">
                      <Badge variant="outline" className="capitalize">{displayPet.type}</Badge>
                      <Badge variant="outline">{displayPet.breed}</Badge>
                      <Badge variant="outline">{displayPet.gender}</Badge>
                      <Badge variant="outline">{displayPet.age} {displayPet.age === 1 ? 'year' : 'years'}</Badge>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="icon"
                    className={`rounded-full ${isFavorite ? 'text-red-500' : ''}`}
                    onClick={toggleFavorite}
                  >
                    <Heart className={`h-5 w-5 ${isFavorite ? 'fill-current' : ''}`} />
                  </Button>
                </div>

                <div className="space-y-4 mb-6">
                  <div className="flex items-center">
                    <Badge className="bg-green-100 text-green-700 hover:bg-green-200 capitalize mr-2">
                      {displayPet.adoptionStatus}
                    </Badge>
                    {displayPet.adoptionStatus === "available" && (
                      <span className="text-sm text-neutral-500 flex items-center">
                        <Clock className="h-4 w-4 mr-1" />
                        Ready for adoption
                      </span>
                    )}
                  </div>

                  <div className="bg-neutral-50 p-4 rounded-lg">
                    <h3 className="font-heading font-semibold text-lg mb-3">Meet {displayPet.name}</h3>
                    <p className="text-neutral-600">{displayPet.description}</p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between text-sm text-neutral-500">
                  <span className="flex items-center">
                    <MapPin className="h-4 w-4 mr-1" />
                    {petData.shelter?.location}
                  </span>
                  <span>
                    Adoption Fee: <span className="font-semibold text-neutral-700">{petData.adoptionFee}</span>
                  </span>
                </div>

                <div className="flex gap-3">
                  <Button className="flex-1">Start Adoption Process</Button>
                  <Button variant="outline" size="icon">
                    <Share2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Pet Details Section */}
      <div className="container mx-auto px-4 grid md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-6">
          {/* Pet Story */}
          <Card>
            <CardHeader>
              <CardTitle>
                <h2 className="font-heading font-bold text-xl">
                  {displayPet.name}'s Story
                </h2>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-neutral-600 mb-4">{petData.story}</p>
              
              <h3 className="font-heading font-semibold text-lg mb-3">Personality Highlights</h3>
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="flex items-center p-3 bg-blue-50 rounded-lg">
                  <Award className="h-10 w-10 text-blue-400 mr-3" />
                  <div>
                    <h4 className="font-semibold">Friendly</h4>
                    <p className="text-sm text-neutral-600">Great with people</p>
                  </div>
                </div>
                <div className="flex items-center p-3 bg-green-50 rounded-lg">
                  <Activity className="h-10 w-10 text-green-400 mr-3" />
                  <div>
                    <h4 className="font-semibold">Energetic</h4>
                    <p className="text-sm text-neutral-600">Loves to play</p>
                  </div>
                </div>
                <div className="flex items-center p-3 bg-amber-50 rounded-lg">
                  <CheckCircle className="h-10 w-10 text-amber-400 mr-3" />
                  <div>
                    <h4 className="font-semibold">Trainable</h4>
                    <p className="text-sm text-neutral-600">Quick learner</p>
                  </div>
                </div>
                <div className="flex items-center p-3 bg-purple-50 rounded-lg">
                  <Shield className="h-10 w-10 text-purple-400 mr-3" />
                  <div>
                    <h4 className="font-semibold">Loyal</h4>
                    <p className="text-sm text-neutral-600">Strong bond</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Pet Details */}
          <Card>
            <CardHeader>
              <CardTitle>
                <h2 className="font-heading font-bold text-xl">Details</h2>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="basics">
                <TabsList>
                  <TabsTrigger value="basics">Basic Info</TabsTrigger>
                  <TabsTrigger value="health">Health</TabsTrigger>
                  <TabsTrigger value="compatibility">Compatibility</TabsTrigger>
                  <TabsTrigger value="training">Training</TabsTrigger>
                </TabsList>
                
                <TabsContent value="basics" className="pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="border rounded-lg p-3">
                      <span className="text-sm text-neutral-500">Breed</span>
                      <div className="font-semibold">{petData.breed}</div>
                    </div>
                    <div className="border rounded-lg p-3">
                      <span className="text-sm text-neutral-500">Color</span>
                      <div className="font-semibold">{petData.color}</div>
                    </div>
                    <div className="border rounded-lg p-3">
                      <span className="text-sm text-neutral-500">Age</span>
                      <div className="font-semibold">{displayPet.age} {displayPet.age === 1 ? 'year' : 'years'}</div>
                    </div>
                    <div className="border rounded-lg p-3">
                      <span className="text-sm text-neutral-500">Gender</span>
                      <div className="font-semibold">{displayPet.gender}</div>
                    </div>
                    <div className="border rounded-lg p-3">
                      <span className="text-sm text-neutral-500">Weight</span>
                      <div className="font-semibold">{petData.weight}</div>
                    </div>
                    <div className="border rounded-lg p-3">
                      <span className="text-sm text-neutral-500">Size</span>
                      <div className="font-semibold">{petData.size}</div>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="health" className="pt-4">
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="border rounded-lg p-3 flex items-center">
                      <div className={`h-4 w-4 rounded-full mr-2 ${healthStatus.vaccinated ? 'bg-green-500' : 'bg-neutral-200'}`}></div>
                      <span className="font-medium">Vaccinated</span>
                    </div>
                    <div className="border rounded-lg p-3 flex items-center">
                      <div className={`h-4 w-4 rounded-full mr-2 ${healthStatus.neutered ? 'bg-green-500' : 'bg-neutral-200'}`}></div>
                      <span className="font-medium">Neutered/Spayed</span>
                    </div>
                    <div className="border rounded-lg p-3 flex items-center">
                      <div className={`h-4 w-4 rounded-full mr-2 ${healthStatus.microchipped ? 'bg-green-500' : 'bg-neutral-200'}`}></div>
                      <span className="font-medium">Microchipped</span>
                    </div>
                    <div className="border rounded-lg p-3 flex items-center">
                      <div className={`h-4 w-4 rounded-full mr-2 ${healthStatus.specialNeeds ? 'bg-amber-500' : 'bg-neutral-200'}`}></div>
                      <span className="font-medium">Special Needs</span>
                    </div>
                  </div>
                  
                  <p className="text-neutral-600 text-sm">
                    This pet has received all necessary vaccinations and medical care.
                    Regular vet check-ups are recommended to maintain their health.
                  </p>
                </TabsContent>
                
                <TabsContent value="compatibility" className="pt-4">
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Good with children</span>
                        <span className="text-sm">{compatibility.children}/5</span>
                      </div>
                      <Progress value={compatibility.children ? compatibility.children * 20 : 0} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Good with other dogs</span>
                        <span className="text-sm">{compatibility.otherDogs}/5</span>
                      </div>
                      <Progress value={compatibility.otherDogs ? compatibility.otherDogs * 20 : 0} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Good with cats</span>
                        <span className="text-sm">{compatibility.cats}/5</span>
                      </div>
                      <Progress value={compatibility.cats * 20} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Good with small pets</span>
                        <span className="text-sm">{compatibility.smallPets}/5</span>
                      </div>
                      <Progress value={compatibility.smallPets * 20} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between mb-1">
                        <span className="text-sm font-medium">Suitable for apartment living</span>
                        <span className="text-sm">{compatibility.apartmentLiving}/5</span>
                      </div>
                      <Progress value={compatibility.apartmentLiving * 20} className="h-2" />
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="training" className="pt-4">
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="border rounded-lg p-3 flex items-center">
                      <div className={`h-4 w-4 rounded-full mr-2 ${training.housebroken ? 'bg-green-500' : 'bg-neutral-200'}`}></div>
                      <span className="font-medium">House-trained</span>
                    </div>
                    <div className="border rounded-lg p-3 flex items-center">
                      <div className={`h-4 w-4 rounded-full mr-2 ${training.basicCommands ? 'bg-green-500' : 'bg-neutral-200'}`}></div>
                      <span className="font-medium">Knows basic commands</span>
                    </div>
                    <div className="border rounded-lg p-3 flex items-center">
                      <div className={`h-4 w-4 rounded-full mr-2 ${training.leashTrained ? 'bg-green-500' : 'bg-neutral-200'}`}></div>
                      <span className="font-medium">Leash trained</span>
                    </div>
                    <div className="border rounded-lg p-3 flex items-center">
                      <div className={`h-4 w-4 rounded-full mr-2 ${training.advancedTraining ? 'bg-green-500' : 'bg-neutral-200'}`}></div>
                      <span className="font-medium">Advanced training</span>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Activity Level</span>
                      <span className="text-sm">{activityLevel}/5</span>
                    </div>
                    <Progress value={activityLevel * 20} className="h-2" />
                  </div>
                  
                  <p className="text-neutral-600 text-sm">
                    {displayPet.name} has received basic training and is well-behaved.
                    With consistent training and positive reinforcement, they will continue to learn and thrive.
                  </p>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Shelter Information */}
          <Card>
            <CardHeader>
              <CardTitle>
                <h2 className="font-heading font-bold text-xl">Adoption Contact</h2>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <h3 className="font-heading font-semibold text-lg mb-3">{shelter.name}</h3>
              <div className="space-y-3 mb-6">
                <div className="flex items-center">
                  <MapPin className="h-4 w-4 text-neutral-500 mr-2" />
                  <span className="text-neutral-600">{shelter.location}</span>
                </div>
                <div className="flex items-center">
                  <Phone className="h-4 w-4 text-neutral-500 mr-2" />
                  <span className="text-neutral-600">{shelter.phone}</span>
                </div>
                <div className="flex items-center">
                  <Mail className="h-4 w-4 text-neutral-500 mr-2" />
                  <span className="text-neutral-600">{shelter.email}</span>
                </div>
                <div className="flex items-center">
                  <ExternalLink className="h-4 w-4 text-neutral-500 mr-2" />
                  <a href={shelter.website} className="text-primary hover:underline" target="_blank" rel="noopener noreferrer">
                    Visit shelter website
                  </a>
                </div>
              </div>
              
              <Button className="w-full mb-3">Contact About {displayPet.name}</Button>
              <Button variant="outline" className="w-full">Schedule Visit</Button>
            </CardContent>
          </Card>

          {/* Adoption Process */}
          <Card>
            <CardHeader>
              <CardTitle>
                <h2 className="font-heading font-bold text-xl">Adoption Process</h2>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ol className="space-y-3 relative pl-6 before:absolute before:left-[0.4375rem] before:h-full before:w-[1px] before:bg-neutral-200">
                <li className="relative">
                  <div className="absolute left-[-1.375rem] flex h-6 w-6 items-center justify-center rounded-full bg-primary text-white">1</div>
                  <h3 className="font-semibold">Submit Application</h3>
                  <p className="text-sm text-neutral-600">Fill out the adoption form online</p>
                </li>
                <li className="relative">
                  <div className="absolute left-[-1.375rem] flex h-6 w-6 items-center justify-center rounded-full bg-neutral-200 text-neutral-600">2</div>
                  <h3 className="font-semibold">Application Review</h3>
                  <p className="text-sm text-neutral-600">Shelter reviews your application</p>
                </li>
                <li className="relative">
                  <div className="absolute left-[-1.375rem] flex h-6 w-6 items-center justify-center rounded-full bg-neutral-200 text-neutral-600">3</div>
                  <h3 className="font-semibold">Meet & Greet</h3>
                  <p className="text-sm text-neutral-600">Visit the shelter to meet {displayPet.name}</p>
                </li>
                <li className="relative">
                  <div className="absolute left-[-1.375rem] flex h-6 w-6 items-center justify-center rounded-full bg-neutral-200 text-neutral-600">4</div>
                  <h3 className="font-semibold">Adoption Finalization</h3>
                  <p className="text-sm text-neutral-600">Complete paperwork and pay adoption fee</p>
                </li>
                <li className="relative">
                  <div className="absolute left-[-1.375rem] flex h-6 w-6 items-center justify-center rounded-full bg-neutral-200 text-neutral-600">5</div>
                  <h3 className="font-semibold">Welcome Home</h3>
                  <p className="text-sm text-neutral-600">Bring {displayPet.name} to their forever home</p>
                </li>
              </ol>
            </CardContent>
          </Card>

          {/* Need Help */}
          <Card>
            <CardContent className="p-6">
              <h3 className="font-heading font-semibold text-lg mb-3">Need Help?</h3>
              <p className="text-neutral-600 text-sm mb-4">
                Unsure if {displayPet.name} is the right pet for you? Our adoption counselors can help you make the right decision.
              </p>
              <Button variant="outline" className="w-full">Ask a Question</Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}