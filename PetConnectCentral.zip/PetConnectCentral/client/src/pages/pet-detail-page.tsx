import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, Link, useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import BehaviorTab from "@/components/pets/tab-behavior";
import DocumentsTab from "@/components/pets/tab-documents";
import GalleryTab from "@/components/pets/tab-gallery";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { 
  Loader2, 
  Heart, 
  Calendar, 
  Clock, 
  AlertCircle,
  Download,
  Upload,
  Edit3,
  FileText,
  Camera,
  Trash2,
  ChevronLeft,
  MapPin,
  Phone,
  Mail,
  ExternalLink,
  Share2,
  Shield,
  Activity,
  Award,
  CheckCircle,
  PenTool,
} from "lucide-react";

// Sample pet data for demo purposes
const samplePet = {
  id: 1,
  name: "Max",
  type: "dog",
  breed: "German Shepherd",
  age: 3,
  gender: "male",
  size: "large",
  color: "Black and Tan",
  weight: "32 kg",
  description: "Max is a friendly and energetic German Shepherd who loves outdoor activities and playing fetch. He's great with kids and other dogs, making him a perfect family companion. Max has been trained in basic commands and is house-trained.",
  mainImageUrl: null,
  imageUrls: [],
  createdAt: new Date(),
  healthStatus: {
    isVaccinated: true,
    isNeutered: true,
    isMicrochipped: true,
    hasSpecialNeeds: false,
    lastCheckup: "2023-11-15",
    medications: ["Heartworm preventative"],
    allergies: ["Chicken"],
    vaccinations: [
      { name: "Rabies", date: "2023-05-10", dueDate: "2025-05-10" },
      { name: "DHPP", date: "2023-04-15", dueDate: "2024-04-15" },
      { name: "Bordetella", date: "2023-06-20", dueDate: "2024-06-20" },
    ],
    medicalRecords: [
      { title: "Annual Checkup", date: "2023-11-15", notes: "All healthy, slight tartar buildup on teeth" },
      { title: "Spay/Neuter", date: "2022-03-18", notes: "Procedure completed successfully" },
    ]
  },
  compatibility: {
    goodWithChildren: true,
    goodWithDogs: true,
    goodWithCats: false,
    goodWithOtherPets: false,
    apartmentFriendly: 3
  },
  behavior: {
    energy: 4,
    sociability: 5,
    independence: 3,
    vocalization: 2,
    training: 4
  },
  training: {
    isHousetrained: true,
    knowsBasicCommands: true,
    isLeashTrained: true,
    advancedTraining: false
  },
  diet: {
    foodType: "Dry kibble",
    specialDiet: false,
    feedingSchedule: "Twice daily",
    treats: "Dental chews, training treats"
  },
  care: {
    grooming: "Weekly brushing, monthly bath",
    exercise: "Daily walks and play sessions",
    activities: ["Fetch", "Agility training", "Hiking"],
    appointments: [
      { type: "Grooming", date: "2023-12-10", provider: "Paws & Claws Grooming" },
      { type: "Vet Checkup", date: "2024-05-15", provider: "Happy Tails Veterinary Clinic" }
    ]
  },
  notes: "Max is afraid of thunderstorms and needs a safe space during storms. He loves playing with his rope toy and tennis balls."
};

export default function PetDetailPage() {
  const params = useParams();
  const petId = params?.id;
  const [, navigate] = useLocation();
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("info");
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [notesEdit, setNotesEdit] = useState(false);
  const [petNotes, setPetNotes] = useState("");

  // Fetch pet details
  const { data: pet, isLoading, error } = useQuery({
    queryKey: ['/api/pets', petId],
    enabled: !!petId,
    queryFn: async () => {
      // Get real pet data from the API
      const petData = await (await apiRequest("GET", `/api/pets/${petId}`)).json();
      // Initialize pet notes when the pet is loaded
      if (petData && petData.notes) {
        setPetNotes(petData.notes);
      }
      return petData;
    }
  });

  // Delete pet mutation
  const deletePetMutation = useMutation({
    mutationFn: async () => {
      // Call the real API to delete the pet
      await apiRequest("DELETE", `/api/pets/${petId}`);
      return true;
    },
    onSuccess: () => {
      toast({
        title: "Pet deleted",
        description: "Your pet has been successfully removed",
      });
      navigate("/pets");
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to delete pet. Please try again.",
        variant: "destructive",
      });
      console.error("Error deleting pet:", error);
    }
  });

  // Update pet notes mutation
  const updateNotesMutation = useMutation({
    mutationFn: async (notes: string) => {
      // Call the real API to update pet notes
      await apiRequest("PUT", `/api/pets/${petId}`, { notes });
      return true;
    },
    onSuccess: () => {
      toast({
        title: "Notes updated",
        description: "Your pet's notes have been updated",
      });
      setNotesEdit(false);
      // Invalidate the pet query to refresh the data
      queryClient.invalidateQueries({ queryKey: ['/api/pets', petId] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update notes. Please try again.",
        variant: "destructive",
      });
      console.error("Error updating pet notes:", error);
    }
  });

  const handleSaveNotes = () => {
    updateNotesMutation.mutate(petNotes);
  };

  const handleDeletePet = () => {
    deletePetMutation.mutate();
    setShowDeleteDialog(false);
  };

  const handleAddHealthRecord = () => {
    // This would open a form to add a health record
    toast({
      title: "Coming soon",
      description: "This feature is not yet implemented",
    });
  };

  const handleUploadDocument = () => {
    // This would open a file selector to upload a document
    toast({
      title: "Coming soon",
      description: "This feature is not yet implemented",
    });
  };
  
  // Create Plus icon component with props
  const PlusIcon = ({ className = "" }: { className?: string }) => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M5 12h14" />
      <path d="M12 5v14" />
    </svg>
  );

  const handleBookAppointment = () => {
    navigate(`/services/book?petId=${petId}`);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error || !pet) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h1 className="text-2xl font-bold text-red-500 mb-4">Error Loading Pet Profile</h1>
        <p className="mb-6">Sorry, we couldn't find details for this pet. Please try again later.</p>
        <Button asChild>
          <Link href="/pets">
            <ChevronLeft className="mr-2 h-4 w-4" />
            Back to My Pets
          </Link>
        </Button>
      </div>
    );
  }

  // Create a placeholder image with the pet's initial
  const placeholderBgColors = {
    dog: "bg-blue-100",
    cat: "bg-green-100",
    bird: "bg-yellow-100",
    rabbit: "bg-purple-100",
    fish: "bg-cyan-100",
    hamster: "bg-pink-100",
    reptile: "bg-amber-100",
    other: "bg-gray-100"
  };

  const petTypeColor = placeholderBgColors[pet.type as keyof typeof placeholderBgColors] || "bg-gray-100";

  const petImage = (index: number) => {
    // This is a placeholder. In real implementation, we would use actual images from the pet data
    if (pet.imageUrls && pet.imageUrls[index]) {
      return (
        <img 
          src={pet.imageUrls[index]} 
          alt={`${pet.name} photo ${index + 1}`} 
          className="w-full h-full object-cover"
        />
      );
    }
    return (
      <div className={`h-full w-full ${petTypeColor} flex items-center justify-center`}>
        <span className="text-4xl font-bold text-gray-500">{pet.name.charAt(0)}</span>
      </div>
    );
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      {/* Breadcrumb */}
      <Breadcrumb className="mb-6">
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink href="/dashboard">Dashboard</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink href="/pets">My Pets</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbPage>{pet.name}</BreadcrumbPage>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="space-y-6">
          {/* Pet Profile Card */}
          <Card>
            <CardHeader className="pb-2">
              <div className="flex justify-between items-start">
                <CardTitle className="text-2xl font-bold">{pet.name}</CardTitle>
                <Button variant="ghost" size="icon" asChild>
                  <Link href={`/pets/${pet.id}/edit`}>
                    <Edit3 className="h-4 w-4" />
                  </Link>
                </Button>
              </div>
              <CardDescription>
                {pet.type && <Badge variant="outline" className="capitalize mr-1">{pet.type}</Badge>}
                {pet.breed && <Badge variant="outline">{pet.breed}</Badge>}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative mb-4">
                {pet.mainImageUrl ? (
                  <img 
                    src={pet.mainImageUrl} 
                    alt={pet.name} 
                    className="w-full h-48 object-cover rounded-md"
                  />
                ) : (
                  <div className={`w-full h-48 ${petTypeColor} flex items-center justify-center rounded-md`}>
                    <span className="text-5xl font-bold text-gray-500">{pet.name.charAt(0)}</span>
                  </div>
                )}
                
                <Button 
                  variant="ghost" 
                  size="icon"
                  className="absolute bottom-2 right-2 bg-white/80 hover:bg-white rounded-full p-1"
                  asChild
                >
                  <Link href={`/pets/${pet.id}/photos`}>
                    <Camera className="h-4 w-4" />
                  </Link>
                </Button>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Age:</span>
                  <span>{pet.age} {pet.age === 1 ? 'year' : 'years'}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Gender:</span>
                  <span className="capitalize">{pet.gender}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Size:</span>
                  <span className="capitalize">{pet.size}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Weight:</span>
                  <span>{pet.weight || "Not specified"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Color:</span>
                  <span>{pet.color}</span>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between pt-0">
              <Button variant="outline" size="sm" className="w-full" onClick={handleBookAppointment}>
                <Calendar className="h-4 w-4 mr-2" />
                Book Appointment
              </Button>
            </CardFooter>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="pb-3">
              <div className="space-y-2">
                <Button variant="outline" size="sm" className="w-full justify-start" asChild>
                  <Link href={`/pets/${pet.id}/health`}>
                    <Shield className="h-4 w-4 mr-2" />
                    Health Records
                  </Link>
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start" asChild>
                  <Link href={`/pets/${pet.id}/care`}>
                    <Heart className="h-4 w-4 mr-2" />
                    Care Plan
                  </Link>
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start" asChild>
                  <Link href={`/appointments?petId=${pet.id}`}>
                    <Calendar className="h-4 w-4 mr-2" />
                    Appointments
                  </Link>
                </Button>
                <Button variant="outline" size="sm" className="w-full justify-start" asChild>
                  <Link href={`/pets/${pet.id}/documents`}>
                    <FileText className="h-4 w-4 mr-2" />
                    Documents
                  </Link>
                </Button>
              </div>
            </CardContent>
            <CardFooter className="pt-0">
              <Button 
                variant="ghost" 
                size="sm" 
                className="w-full text-red-500 hover:text-red-700 hover:bg-red-50"
                onClick={() => setShowDeleteDialog(true)}
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Delete Pet
              </Button>
            </CardFooter>
          </Card>
        </div>

        {/* Main Content */}
        <div className="lg:col-span-3 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>About {pet.name}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">{pet.description}</p>
            </CardContent>
          </Card>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full grid grid-cols-3 md:grid-cols-6">
              <TabsTrigger value="info">Info</TabsTrigger>
              <TabsTrigger value="health">Health</TabsTrigger>
              <TabsTrigger value="care">Care</TabsTrigger>
              <TabsTrigger value="behavior">Behavior</TabsTrigger>
              <TabsTrigger value="documents">Documents</TabsTrigger>
              <TabsTrigger value="gallery">Gallery</TabsTrigger>
            </TabsList>

            {/* Info Tab */}
            <TabsContent value="info" className="space-y-6 pt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Compatibility</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span>Good with Children</span>
                          <span className="font-semibold">
                            {pet.compatibility?.goodWithChildren ? "Yes" : "No"}
                          </span>
                        </div>
                        <Progress 
                          value={pet.compatibility?.goodWithChildren ? 100 : 0} 
                          className="h-2" 
                        />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span>Good with Dogs</span>
                          <span className="font-semibold">
                            {pet.compatibility?.goodWithDogs ? "Yes" : "No"}
                          </span>
                        </div>
                        <Progress 
                          value={pet.compatibility?.goodWithDogs ? 100 : 0} 
                          className="h-2" 
                        />
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span>Good with Cats</span>
                          <span className="font-semibold">
                            {pet.compatibility?.goodWithCats ? "Yes" : "No"}
                          </span>
                        </div>
                        <Progress 
                          value={pet.compatibility?.goodWithCats ? 100 : 0} 
                          className="h-2" 
                        />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span>Apartment Friendly</span>
                          <span className="font-semibold">
                            {pet.compatibility?.apartmentFriendly ? 
                              pet.compatibility?.apartmentFriendly + "/5" : 
                              "N/A"
                            }
                          </span>
                        </div>
                        <Progress 
                          value={pet.compatibility?.apartmentFriendly ? 
                            (pet.compatibility?.apartmentFriendly / 5) * 100 : 0
                          } 
                          className="h-2" 
                        />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Behavior & Training</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span>Energy Level</span>
                          <span className="font-semibold">
                            {pet.behavior?.energy ? pet.behavior.energy + "/5" : "N/A"}
                          </span>
                        </div>
                        <Progress 
                          value={pet.behavior?.energy ? (pet.behavior.energy / 5) * 100 : 0} 
                          className="h-2" 
                        />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span>Sociability</span>
                          <span className="font-semibold">
                            {pet.behavior?.sociability ? pet.behavior.sociability + "/5" : "N/A"}
                          </span>
                        </div>
                        <Progress 
                          value={pet.behavior?.sociability ? (pet.behavior.sociability / 5) * 100 : 0} 
                          className="h-2" 
                        />
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div>
                        <div className="flex justify-between mb-1">
                          <span>Independence</span>
                          <span className="font-semibold">
                            {pet.behavior?.independence ? pet.behavior.independence + "/5" : "N/A"}
                          </span>
                        </div>
                        <Progress 
                          value={pet.behavior?.independence ? (pet.behavior.independence / 5) * 100 : 0} 
                          className="h-2" 
                        />
                      </div>
                      <div>
                        <div className="flex justify-between mb-1">
                          <span>Trainability</span>
                          <span className="font-semibold">
                            {pet.behavior?.training ? pet.behavior.training + "/5" : "N/A"}
                          </span>
                        </div>
                        <Progress 
                          value={pet.behavior?.training ? (pet.behavior.training / 5) * 100 : 0} 
                          className="h-2" 
                        />
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div className="flex items-center p-3 bg-muted rounded-lg">
                      <CheckCircle className={`h-5 w-5 mr-3 ${pet.training?.isHousetrained ? "text-green-500" : "text-gray-300"}`} />
                      <span>Housetrained</span>
                    </div>
                    <div className="flex items-center p-3 bg-muted rounded-lg">
                      <CheckCircle className={`h-5 w-5 mr-3 ${pet.training?.knowsBasicCommands ? "text-green-500" : "text-gray-300"}`} />
                      <span>Basic Commands</span>
                    </div>
                    <div className="flex items-center p-3 bg-muted rounded-lg">
                      <CheckCircle className={`h-5 w-5 mr-3 ${pet.training?.isLeashTrained ? "text-green-500" : "text-gray-300"}`} />
                      <span>Leash Trained</span>
                    </div>
                    <div className="flex items-center p-3 bg-muted rounded-lg">
                      <CheckCircle className={`h-5 w-5 mr-3 ${pet.training?.advancedTraining ? "text-green-500" : "text-gray-300"}`} />
                      <span>Advanced Training</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Diet & Nutrition</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <div>
                        <span className="text-muted-foreground">Food Type:</span>{" "}
                        <span>{pet.diet?.foodType || "Not specified"}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Special Diet:</span>{" "}
                        <span>{pet.diet?.specialDiet ? "Yes" : "No"}</span>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div>
                        <span className="text-muted-foreground">Feeding Schedule:</span>{" "}
                        <span>{pet.diet?.feedingSchedule || "Not specified"}</span>
                      </div>
                      <div>
                        <span className="text-muted-foreground">Favorite Treats:</span>{" "}
                        <span>{pet.diet?.treats || "Not specified"}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Health Tab */}
            <TabsContent value="health" className="space-y-6 pt-6">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">Health Records</h3>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={handleAddHealthRecord}>
                    <PlusIcon className="h-4 w-4 mr-2" />
                    Add Record
                  </Button>
                  <Button variant="outline" size="sm" onClick={handleUploadDocument}>
                    <Upload className="h-4 w-4 mr-2" />
                    Upload Document
                  </Button>
                </div>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Health Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                    <div className="flex flex-col items-center justify-center p-4 bg-muted rounded-lg">
                      <Shield className={`h-6 w-6 mb-2 ${pet.healthStatus?.isVaccinated ? "text-green-500" : "text-gray-300"}`} />
                      <span className="text-sm font-medium">Vaccinated</span>
                      <span className="text-xs text-muted-foreground">{pet.healthStatus?.isVaccinated ? "Yes" : "No"}</span>
                    </div>
                    <div className="flex flex-col items-center justify-center p-4 bg-muted rounded-lg">
                      <Activity className={`h-6 w-6 mb-2 ${pet.healthStatus?.isNeutered ? "text-green-500" : "text-gray-300"}`} />
                      <span className="text-sm font-medium">Neutered/Spayed</span>
                      <span className="text-xs text-muted-foreground">{pet.healthStatus?.isNeutered ? "Yes" : "No"}</span>
                    </div>
                    <div className="flex flex-col items-center justify-center p-4 bg-muted rounded-lg">
                      <Award className={`h-6 w-6 mb-2 ${pet.healthStatus?.isMicrochipped ? "text-green-500" : "text-gray-300"}`} />
                      <span className="text-sm font-medium">Microchipped</span>
                      <span className="text-xs text-muted-foreground">{pet.healthStatus?.isMicrochipped ? "Yes" : "No"}</span>
                    </div>
                    <div className="flex flex-col items-center justify-center p-4 bg-muted rounded-lg">
                      <AlertCircle className={`h-6 w-6 mb-2 ${pet.healthStatus?.hasSpecialNeeds ? "text-amber-500" : "text-gray-300"}`} />
                      <span className="text-sm font-medium">Special Needs</span>
                      <span className="text-xs text-muted-foreground">{pet.healthStatus?.hasSpecialNeeds ? "Yes" : "No"}</span>
                    </div>
                  </div>

                  {pet.healthStatus?.lastCheckup && (
                    <div className="mb-6">
                      <h4 className="text-sm font-semibold mb-2">Last Checkup</h4>
                      <div className="flex items-center bg-muted p-3 rounded-lg">
                        <Calendar className="h-5 w-5 mr-3 text-primary" />
                        <div>
                          <span className="font-medium">{new Date(pet.healthStatus.lastCheckup).toLocaleDateString()}</span>
                          <p className="text-xs text-muted-foreground">
                            {new Date() > new Date(pet.healthStatus.lastCheckup) ? 
                              `${Math.round((new Date().getTime() - new Date(pet.healthStatus.lastCheckup).getTime()) / (1000 * 60 * 60 * 24 * 30))} months ago` : 
                              "Upcoming"
                            }
                          </p>
                        </div>
                      </div>
                    </div>
                  )}

                  {pet.healthStatus?.vaccinations && pet.healthStatus.vaccinations.length > 0 && (
                    <div className="mb-6">
                      <h4 className="text-sm font-semibold mb-2">Vaccinations</h4>
                      <div className="space-y-2">
                        {pet.healthStatus.vaccinations.map((vaccination, index) => (
                          <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                            <div className="flex items-center">
                              <Shield className="h-5 w-5 mr-3 text-primary" />
                              <div>
                                <span className="font-medium">{vaccination.name}</span>
                                <p className="text-xs text-muted-foreground">
                                  Administered: {new Date(vaccination.date).toLocaleDateString()}
                                </p>
                              </div>
                            </div>
                            <div className="text-right">
                              <span className="text-xs text-muted-foreground">Next Due:</span>
                              <p className={`text-sm font-medium ${
                                new Date() > new Date(vaccination.dueDate) ? "text-red-500" : ""
                              }`}>
                                {new Date(vaccination.dueDate).toLocaleDateString()}
                              </p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {pet.healthStatus?.medications && pet.healthStatus.medications.length > 0 && (
                    <div className="mb-6">
                      <h4 className="text-sm font-semibold mb-2">Current Medications</h4>
                      <div className="space-y-2">
                        {pet.healthStatus.medications.map((medication, index) => (
                          <div key={index} className="flex items-center p-3 border rounded-lg">
                            <PenTool className="h-5 w-5 mr-3 text-primary" />
                            <span>{medication}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {pet.healthStatus?.allergies && pet.healthStatus.allergies.length > 0 && (
                    <div>
                      <h4 className="text-sm font-semibold mb-2">Allergies</h4>
                      <div className="space-y-2">
                        {pet.healthStatus.allergies.map((allergy, index) => (
                          <div key={index} className="flex items-center p-3 border rounded-lg">
                            <AlertCircle className="h-5 w-5 mr-3 text-amber-500" />
                            <span>{allergy}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              {pet.healthStatus?.medicalRecords && pet.healthStatus.medicalRecords.length > 0 && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Medical History</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {pet.healthStatus.medicalRecords.map((record, index) => (
                        <div key={index} className="border rounded-lg overflow-hidden">
                          <div className="flex justify-between items-center bg-muted p-3">
                            <div className="flex items-center">
                              <FileText className="h-5 w-5 mr-2 text-primary" />
                              <span className="font-medium">{record.title}</span>
                            </div>
                            <span className="text-sm text-muted-foreground">
                              {new Date(record.date).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="p-3">
                            <p className="text-sm">{record.notes}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Care Tab */}
            <TabsContent value="care" className="space-y-6 pt-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Care Requirements</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="text-sm font-semibold mb-2">Grooming</h4>
                      <p className="text-sm text-muted-foreground mb-4">
                        {pet.care?.grooming || "No grooming information provided"}
                      </p>

                      <h4 className="text-sm font-semibold mb-2">Exercise</h4>
                      <p className="text-sm text-muted-foreground">
                        {pet.care?.exercise || "No exercise information provided"}
                      </p>
                    </div>
                    
                    <div>
                      <h4 className="text-sm font-semibold mb-2">Favorite Activities</h4>
                      {pet.care?.activities && pet.care.activities.length > 0 ? (
                        <div className="flex flex-wrap gap-2 mb-4">
                          {pet.care.activities.map((activity, index) => (
                            <Badge key={index} variant="secondary">{activity}</Badge>
                          ))}
                        </div>
                      ) : (
                        <p className="text-sm text-muted-foreground mb-4">
                          No favorite activities listed
                        </p>
                      )}

                      <h4 className="text-sm font-semibold mb-2">Services & Appointments</h4>
                      {pet.care?.appointments && pet.care.appointments.length > 0 ? (
                        <div className="space-y-2">
                          {pet.care.appointments.map((appointment, index) => (
                            <div key={index} className="flex justify-between items-center p-2 border rounded">
                              <div>
                                <p className="font-medium text-sm">{appointment.type}</p>
                                <p className="text-xs text-muted-foreground">{appointment.provider}</p>
                              </div>
                              <p className="text-sm">
                                {new Date(appointment.date).toLocaleDateString()}
                              </p>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-sm text-muted-foreground">
                          No upcoming appointments
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recommended Services</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="border rounded-lg p-4 flex flex-col">
                      <div className="flex items-center mb-2">
                        <Shield className="h-5 w-5 mr-2 text-primary" />
                        <h4 className="font-medium">Veterinary Checkup</h4>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3 flex-1">
                        Regular checkups help maintain your pet's health and detect issues early.
                      </p>
                      <Button size="sm" variant="outline" className="w-full" asChild>
                        <Link href="/services?category=veterinary">Find Vets</Link>
                      </Button>
                    </div>

                    <div className="border rounded-lg p-4 flex flex-col">
                      <div className="flex items-center mb-2">
                        <Activity className="h-5 w-5 mr-2 text-primary" />
                        <h4 className="font-medium">Grooming Service</h4>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3 flex-1">
                        Professional grooming keeps your pet clean, healthy, and looking their best.
                      </p>
                      <Button size="sm" variant="outline" className="w-full" asChild>
                        <Link href="/services?category=grooming">Find Groomers</Link>
                      </Button>
                    </div>

                    <div className="border rounded-lg p-4 flex flex-col">
                      <div className="flex items-center mb-2">
                        <Award className="h-5 w-5 mr-2 text-primary" />
                        <h4 className="font-medium">Training Sessions</h4>
                      </div>
                      <p className="text-sm text-muted-foreground mb-3 flex-1">
                        Training helps build better communication and behavior with your pet.
                      </p>
                      <Button size="sm" variant="outline" className="w-full" asChild>
                        <Link href="/services?category=training">Find Trainers</Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Behavior Tab */}
            <TabsContent value="behavior" className="space-y-6 pt-6">
              <BehaviorTab pet={pet} />
            </TabsContent>

            {/* Documents Tab */}
            <TabsContent value="documents" className="space-y-6 pt-6">
              <DocumentsTab pet={pet} />
            </TabsContent>
            
            {/* Gallery Tab */}
            <TabsContent value="gallery" className="space-y-6 pt-6">
              <GalleryTab pet={pet} petTypeColor={petTypeColor} />
            </TabsContent>

            {/* Notes Tab */}
            <TabsContent value="notes" className="space-y-6 pt-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-lg">Notes & Reminders</CardTitle>
                  {!notesEdit ? (
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      onClick={() => setNotesEdit(true)}
                    >
                      <Edit3 className="h-4 w-4 mr-2" />
                      Edit
                    </Button>
                  ) : (
                    <div className="flex space-x-2">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => {
                          setNotesEdit(false);
                          setPetNotes(pet.notes || "");
                        }}
                      >
                        Cancel
                      </Button>
                      <Button 
                        variant="default" 
                        size="sm" 
                        onClick={handleSaveNotes}
                        disabled={updateNotesMutation.isPending}
                      >
                        {updateNotesMutation.isPending ? (
                          <>
                            <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          "Save"
                        )}
                      </Button>
                    </div>
                  )}
                </CardHeader>
                <CardContent>
                  {!notesEdit ? (
                    <div className="min-h-[150px]">
                      {pet.notes ? (
                        <p className="text-muted-foreground whitespace-pre-line">{pet.notes}</p>
                      ) : (
                        <p className="text-muted-foreground italic">
                          No notes added yet. Click edit to add notes about your pet's preferences, habits, or other important information.
                        </p>
                      )}
                    </div>
                  ) : (
                    <Textarea 
                      value={petNotes}
                      onChange={(e) => setPetNotes(e.target.value)}
                      placeholder="Add notes about your pet's preferences, habits, or other important information..."
                      className="min-h-[150px]"
                    />
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Pet Profile</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete {pet.name}'s profile? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <div className="bg-amber-50 border border-amber-200 rounded-md p-3 text-amber-800 text-sm flex">
            <AlertCircle className="h-5 w-5 mr-2 flex-shrink-0" />
            <p>
              Deleting this profile will remove all information including health records, appointments, and other data associated with your pet.
            </p>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowDeleteDialog(false)}
            >
              Cancel
            </Button>
            <Button 
              variant="destructive" 
              onClick={handleDeletePet}
              disabled={deletePetMutation.isPending}
            >
              {deletePetMutation.isPending ? (
                <>
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                  Deleting...
                </>
              ) : (
                "Delete Pet Profile"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}