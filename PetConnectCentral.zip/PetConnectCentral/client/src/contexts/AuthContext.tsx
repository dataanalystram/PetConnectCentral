import React, { createContext, useContext, useEffect, useState } from 'react';
import { User as FirebaseUser, onAuthStateChanged } from 'firebase/auth';
import { auth } from '@/lib/firebase';
import { User, UserType } from '@shared/schema';
import { logoutUser } from '@/lib/auth';
import { apiRequest } from '@/lib/queryClient';

interface AuthContextType {
  currentUser: FirebaseUser | null;
  userProfile: User | null;
  isLoading: boolean;
  logout: () => Promise<void>;
  updateUserRole: (userType: UserType) => Promise<any>;
  logoutMutation: {
    mutateAsync: () => Promise<void>;
    isPending: boolean;
  };
}

const AuthContext = createContext<AuthContextType | null>(null);

// Export the hook
export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Listen for auth state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      setIsLoading(true);
      
      if (user) {
        try {
          // Get the token and store it in localStorage for API calls
          const token = await user.getIdToken();
          localStorage.setItem('firebaseToken', token);
          
          // Fetch user profile from our database
          const userProfileResponse = await apiRequest('GET', '/api/user/profile');
          if (userProfileResponse.ok) {
            const profile = await userProfileResponse.json();
            setUserProfile(profile);
          }
        } catch (error) {
          console.error('Error fetching user profile:', error);
        }
      } else {
        localStorage.removeItem('firebaseToken');
        setUserProfile(null);
      }
      
      setIsLoading(false);
    });

    return unsubscribe;
  }, []);

  // Logout function
  const logout = async () => {
    try {
      await logoutUser();
      setUserProfile(null);
    } catch (error) {
      console.error('Error logging out:', error);
      throw error;
    }
  };

  // Update user role
  const updateUserRole = async (userType: UserType) => {
    try {
      console.log(`Attempting to update user role to: ${userType}`);
      
      // Ensure the user has a Firebase token before making the request
      if (currentUser) {
        const token = await currentUser.getIdToken(true); // Refresh token to ensure it's valid
        localStorage.setItem('firebaseToken', token);
      } else {
        throw new Error('No authenticated user found');
      }
      
      const response = await apiRequest('PUT', '/api/user/role', { userType });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error('API error updating user role:', errorData);
        throw new Error(errorData.error || 'Failed to update user role');
      }
      
      const updatedProfile = await response.json();
      console.log('User role updated successfully:', updatedProfile);
      
      // Update the profile in state
      setUserProfile(updatedProfile);
      
      // Create appropriate profile based on user type if it doesn't exist
      await createProfileIfNeeded(updatedProfile.id, userType, updatedProfile.name);
      
      return updatedProfile;
    } catch (error) {
      console.error('Error updating user role:', error);
      throw error;
    }
  };
  
  // Create the appropriate user profile if it doesn't exist yet
  const createProfileIfNeeded = async (userId: number, userType: UserType, name: string) => {
    try {
      let profileData = {};
      
      // Check if profile already exists
      if (userType === UserType.PET_OWNER) {
        const petOwnerResponse = await apiRequest('GET', `/api/pet-owners/${userId}`);
        
        if (!petOwnerResponse.ok) {
          console.log('Creating new pet owner profile');
          const createResponse = await apiRequest('POST', '/api/pet-owners', { userId });
          profileData = await createResponse.json();
        }
      } 
      else if (userType === UserType.SERVICE_PROVIDER) {
        const providerResponse = await apiRequest('GET', `/api/service-providers/${userId}`);
        
        if (!providerResponse.ok) {
          console.log('Creating new service provider profile');
          const createResponse = await apiRequest('POST', '/api/service-providers', { 
            userId, 
            businessName: name,
            category: "other"
          });
          profileData = await createResponse.json();
        }
      } 
      else if (userType === UserType.SHELTER) {
        const shelterResponse = await apiRequest('GET', `/api/shelters/${userId}`);
        
        if (!shelterResponse.ok) {
          console.log('Creating new shelter profile');
          const createResponse = await apiRequest('POST', '/api/shelters', {
            userId,
            organizationName: name
          });
          profileData = await createResponse.json();
        }
      }
      
      return profileData;
    } catch (error) {
      console.error('Error creating profile:', error);
      throw error;
    }
  };

  // Create a logoutMutation object that matches the expected interface
  const [isPending, setIsPending] = useState(false);
  
  const logoutMutation = {
    mutateAsync: async () => {
      setIsPending(true);
      try {
        await logout();
      } finally {
        setIsPending(false);
      }
    },
    isPending,
  };

  const value = {
    currentUser,
    userProfile,
    isLoading,
    logout,
    updateUserRole,
    logoutMutation,
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};