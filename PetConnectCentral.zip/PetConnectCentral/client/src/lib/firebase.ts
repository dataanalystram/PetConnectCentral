import { initializeApp, getApp } from "firebase/app";
import { getAuth, User as FirebaseUser } from "firebase/auth";

// Get the current hostname to use for auth domain
const getCurrentDomain = () => {
  // In a browser environment, use the current window location
  if (typeof window !== 'undefined') {
    return window.location.hostname;
  }
  // Default fallback for server-side rendering
  return `${import.meta.env.VITE_FIREBASE_PROJECT_ID}.firebaseapp.com`;
};

const firebaseConfig = {
  apiKey: import.meta.env.VITE_FIREBASE_API_KEY || "AIzaSyAzKsulonWv1CwZR6CS7KuxkOAwRkXO75U",
  authDomain: "petpaw-2e644.firebaseapp.com",
  projectId: import.meta.env.VITE_FIREBASE_PROJECT_ID || "petpaw-2e644",
  storageBucket: "petpaw-2e644.firebasestorage.app",
  messagingSenderId: "849050997353",
  appId: import.meta.env.VITE_FIREBASE_APP_ID || "1:849050997353:web:5b67940e1d000753b9c8f8",
  measurementId: "G-NJNLYQYSY0"
};

// Initialize Firebase only once (prevents duplicate app error)
let app;

try {
  // Try to get existing app instance
  app = getApp();
} catch (error) {
  // If no app exists, initialize a new one
  app = initializeApp(firebaseConfig);
}

// Get auth instance
const auth = getAuth(app);

// Use Firebase auth even when domain verification isn't set up
auth.useDeviceLanguage();

export { auth };

// Optional: Connect to emulator if you run a local Firebase emulator
// Uncomment this if you're running Firebase emulators locally
// if (window.location.hostname === 'localhost' || window.location.hostname.includes('replit.dev')) {
//   import('firebase/auth/connect-auth-emulator').then(() => {
//     connectAuthEmulator(auth, 'http://127.0.0.1:9099');
//   });
// }

// Function to get current user
export const getCurrentUser = (): Promise<FirebaseUser | null> => {
  return new Promise((resolve, reject) => {
    const unsubscribe = auth.onAuthStateChanged((user: FirebaseUser | null) => {
      unsubscribe();
      resolve(user);
    }, reject);
  });
};

export type { FirebaseUser };