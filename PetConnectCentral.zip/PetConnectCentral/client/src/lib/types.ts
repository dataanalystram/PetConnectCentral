// Common types for the application
import { Coordinates } from './geolocation';

// Service Provider Types
export interface ServiceProviderType {
  id: number;
  name: string;
  category: string;
  description: string;
  location: Coordinates | string;
  distance?: number | string;
  rating: number;
  price: string;
  image?: string;
}

// Pet Types
export interface PetType {
  id: number;
  name: string;
  type: string;
  breed: string;
  age: number;
  gender: string;
  description: string;
  status: string;
  shelterId: number;
  shelterName: string;
  image?: string;
}

// Resource Types
export interface ResourceType {
  id: number;
  title: string;
  content: string;
  category: string;
  author: string;
  readTime: number;
  date?: string;
  image?: string;
}

// Categories
export interface CategoryType {
  value: string;
  label: string;
  icon: string;
}

// Review Types
export interface ReviewType {
  id: number;
  rating: number;
  title: string;
  content: string;
  author: string;
  date: string;
  userImage?: string;
}
