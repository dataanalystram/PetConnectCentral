import { useMemo } from 'react';
import { useLocation } from 'wouter';

/**
 * A hook to get URL search parameters
 * @returns An object with the search parameters from the URL
 */
export function useSearchParams(): Record<string, string> {
  const [location] = useLocation();

  const searchParams = useMemo(() => {
    const params = new URLSearchParams(
      location.includes('?') ? location.split('?')[1] : ''
    );
    
    const result: Record<string, string> = {};
    
    // Convert iterator to array to avoid downlevelIteration issue
    Array.from(params.entries()).forEach(([key, value]) => {
      result[key] = value;
    });
    
    return result;
  }, [location]);

  return searchParams;
}