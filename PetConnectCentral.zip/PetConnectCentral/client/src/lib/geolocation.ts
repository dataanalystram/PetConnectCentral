/**
 * Geolocation service for handling location-based operations
 */

export interface Coordinates {
  lat: number;
  lng: number;
}

export interface Location extends Coordinates {
  address: string;
}

/**
 * Calculate distance between two coordinates using the Haversine formula
 * @param coords1 First coordinates
 * @param coords2 Second coordinates
 * @returns Distance in kilometers
 */
export function calculateDistance(coords1: Coordinates, coords2: Coordinates): number {
  const R = 6371; // Radius of the Earth in km
  const dLat = degToRad(coords2.lat - coords1.lat);
  const dLng = degToRad(coords2.lng - coords1.lng);
  
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(degToRad(coords1.lat)) * Math.cos(degToRad(coords2.lat)) * 
    Math.sin(dLng / 2) * Math.sin(dLng / 2);
  
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const distance = R * c;
  
  return distance;
}

/**
 * Convert degrees to radians
 * @param degrees Angle in degrees
 * @returns Angle in radians
 */
function degToRad(degrees: number): number {
  return degrees * (Math.PI / 180);
}

/**
 * Get current location using browser geolocation API
 * @returns Promise with coordinates
 */
export function getCurrentLocation(): Promise<Coordinates> {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) {
      reject(new Error("Geolocation is not supported by your browser"));
      return;
    }
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        resolve({ lat: latitude, lng: longitude });
      },
      (error) => {
        let errorMessage = "Unknown error occurred";
        switch(error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "User denied the request for geolocation";
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = "Location information is unavailable";
            break;
          case error.TIMEOUT:
            errorMessage = "The request to get user location timed out";
            break;
        }
        reject(new Error(errorMessage));
      }
    );
  });
}

/**
 * Filter services by proximity to a location
 * @param services Array of services with location data
 * @param center Center location for proximity calculation
 * @param maxDistance Maximum distance in kilometers (default: 20)
 * @returns Filtered and sorted array of services with distance added
 */
export function filterServicesByProximity<T extends { location: Coordinates }>(
  services: T[],
  center: Coordinates,
  maxDistance: number = 20
): (T & { distance: number })[] {
  return services
    .map(service => {
      const distance = calculateDistance(center, service.location);
      return { ...service, distance };
    })
    .filter(service => service.distance <= maxDistance)
    .sort((a, b) => a.distance - b.distance);
}

/**
 * Format distance for display
 * @param distance Distance in kilometers
 * @returns Formatted distance string
 */
export function formatDistance(distance: number): string {
  if (distance < 1) {
    return `${Math.round(distance * 1000)} m`;
  }
  return `${distance.toFixed(1)} km`;
}

/**
 * OpenStreetMap & Overpass API integration
 */

export interface PetService {
  id: string;
  name: string;
  type: string;
  lat: number;
  lon: number;
  address?: string;
  opening_hours?: string;
  phone?: string;
  website?: string;
  distance?: number;
}

/**
 * Convert Overpass API results to PetService objects
 * @param data Results from Overpass API
 * @param userLocation User's location for distance calculation
 * @returns Array of PetService objects
 */
export function parseOverpassResults(data: any, userLocation?: Coordinates): PetService[] {
  if (!data?.elements || !Array.isArray(data.elements)) return [];
  
  return data.elements.map((element: any) => {
    const tags = element.tags || {};
    
    // Create a readable address from available address components
    const addressParts = [];
    if (tags['addr:housenumber']) addressParts.push(tags['addr:housenumber']);
    if (tags['addr:street']) addressParts.push(tags['addr:street']);
    if (tags['addr:city']) addressParts.push(tags['addr:city']);
    
    const service: PetService = {
      id: element.id.toString(),
      name: tags.name || `${tags.shop || tags.amenity || 'Unnamed'}`,
      type: tags.shop || tags.amenity || 'unknown',
      lat: element.lat,
      lon: element.lon,
      address: addressParts.length > 0 ? addressParts.join(', ') : undefined,
      opening_hours: tags.opening_hours,
      phone: tags.phone,
      website: tags.website
    };
    
    // Calculate distance if user location provided
    if (userLocation) {
      service.distance = calculateDistance(
        userLocation, 
        { lat: element.lat, lng: element.lon }
      );
    }
    
    return service;
  })
  .sort((a: PetService, b: PetService) => (a.distance || 0) - (b.distance || 0));
}

/**
 * Fetch pet-related services from OpenStreetMap via Overpass API
 * @param center Center location for search
 * @param radius Search radius in meters
 * @returns Promise with parsed pet services
 */
export async function fetchPetServicesNearby(center: Coordinates, radius: number = 5000): Promise<PetService[]> {
  try {
    // Overpass API query for pet-related services
    const query = `
      [out:json][timeout:25];
      (
        node["shop"="pet"](around:${radius},${center.lat},${center.lng});
        node["shop"="veterinary"](around:${radius},${center.lat},${center.lng});
        node["amenity"="veterinary"](around:${radius},${center.lat},${center.lng});
        node["amenity"="animal_shelter"](around:${radius},${center.lat},${center.lng});
        node["shop"="pet_grooming"](around:${radius},${center.lat},${center.lng});
        way["shop"="pet"](around:${radius},${center.lat},${center.lng});
        way["shop"="veterinary"](around:${radius},${center.lat},${center.lng});
        way["amenity"="veterinary"](around:${radius},${center.lat},${center.lng});
        way["amenity"="animal_shelter"](around:${radius},${center.lat},${center.lng});
        relation["shop"="pet"](around:${radius},${center.lat},${center.lng});
        relation["shop"="veterinary"](around:${radius},${center.lat},${center.lng});
        relation["amenity"="veterinary"](around:${radius},${center.lat},${center.lng});
        relation["amenity"="animal_shelter"](around:${radius},${center.lat},${center.lng});
      );
      out body;
      >;
      out skel qt;
    `;
    
    // URL encode the query
    const encodedQuery = encodeURIComponent(query);
    const url = `https://overpass-api.de/api/interpreter?data=${encodedQuery}`;
    
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error(`Overpass API error: ${response.status} ${response.statusText}`);
    }
    
    const data = await response.json();
    return parseOverpassResults(data, center);
  } catch (error) {
    console.error('Error fetching pet services:', error);
    throw error;
  }
}

/**
 * Get default New York City location
 * @returns Default coordinates (Manhattan, NYC)
 */
export function getDefaultLocation(): Coordinates {
  return { lat: 40.7128, lng: -74.0060 };
}

/**
 * Reverse geocode coordinates to get address
 * @param coords Coordinates to reverse geocode
 * @returns Promise with location address
 */
export async function reverseGeocode(coords: Coordinates): Promise<string> {
  try {
    const url = `https://nominatim.openstreetmap.org/reverse?lat=${coords.lat}&lon=${coords.lng}&format=json`;
    const response = await fetch(url, {
      headers: {
        'Accept-Language': 'en-US,en',
        'User-Agent': 'PetPal/1.0'
      }
    });
    
    if (!response.ok) {
      throw new Error(`Geocoding error: ${response.status} ${response.statusText}`);
    }
    
    const data = await response.json();
    return data.display_name || 'Unknown location';
  } catch (error) {
    console.error('Error in reverse geocoding:', error);
    return 'Unknown location';
  }
}