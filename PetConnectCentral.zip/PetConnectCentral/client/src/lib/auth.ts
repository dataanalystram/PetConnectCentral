import { 
  createUserWithEmailAndPassword, 
  signInWithEmailAndPassword as firebaseSignIn, 
  signInWithPopup, 
  GoogleAuthProvider,
  signOut 
} from "firebase/auth";
import { auth } from "./firebase";
import { UserType } from "@shared/schema";
import { apiRequest } from "./queryClient";
import { queryClient } from "./queryClient";

// Register with email and password
export const registerWithEmailAndPassword = async (
  email: string, 
  password: string, 
  name: string,
  userType: UserType
) => {
  try {
    // Create the user in Firebase Authentication
    const userCredential = await createUserWithEmailAndPassword(auth, email, password);
    const user = userCredential.user;
    
    // Register the user in our database with their Firebase UID
    await registerUserInDatabase(user.uid, {
      name,
      email,
      userType,
      firebaseUid: user.uid
    });
    
    return user;
  } catch (error) {
    console.error("Error registering user:", error);
    throw error;
  }
};

// Login with email and password
export const loginWithEmailAndPassword = async (email: string, password: string) => {
  try {
    const userCredential = await firebaseSignIn(auth, email, password);
    return userCredential.user;
  } catch (error) {
    console.error("Error logging in:", error);
    throw error;
  }
};

// Sign in with Google
export const signInWithGoogle = async () => {
  try {
    console.log("Attempting Google sign in");
    const provider = new GoogleAuthProvider();
    
    // In development, we may need to add the replit domain to the provider
    if (process.env.NODE_ENV === 'development') {
      // Get the current URL's hostname
      const hostname = window.location.hostname;
      provider.setCustomParameters({
        // Allow the Replit domain to redirect
        prompt: 'select_account'
      });
    }
    
    // Use redirect instead of popup for better compatibility with Replit
    try {
      const result = await signInWithPopup(auth, provider);
      
      // This gives you a Google Access Token
      const credential = GoogleAuthProvider.credentialFromResult(result);
      const user = result.user;
      
      // Check if the user exists in our database, if not register them
      await checkAndRegisterGoogleUser(user);
      
      return user;
    } catch (popupError) {
      console.log("Google sign in error:", popupError);
      // If you want to try redirect as a fallback
      // However user will need to handle the redirect return separately
      // auth.signInWithRedirect(provider);
      throw popupError;
    }
  } catch (error) {
    console.error("Error signing in with Google:", error);
    throw error;
  }
};

// Logout
export const logoutUser = async () => {
  try {
    await signOut(auth);
  } catch (error) {
    console.error("Error logging out:", error);
    throw error;
  }
};

// Delete user account (both Firebase and database)
export const deleteUserAccount = async () => {
  try {
    const user = auth.currentUser;
    
    if (!user) {
      throw new Error("No authenticated user found");
    }
    
    // First delete the user in our database
    const token = await user.getIdToken();
    const response = await apiRequest("DELETE", "/api/user");
    
    if (!response.ok) {
      throw new Error("Failed to delete user account in the database");
    }
    
    // Then delete the Firebase user
    await user.delete();
    
    // Update query client data to reflect logged out state
    queryClient.setQueryData(["/api/user"], null);
    
    console.log("User account successfully deleted");
    
    return { success: true, message: "Account deleted successfully" };
  } catch (error) {
    console.error("Error deleting user account:", error);
    throw error;
  }
};

// Login with test UID (for development/testing purposes)
export const loginWithTestUid = async (testUid: string) => {
  try {
    console.log("Attempting test login with UID:", testUid);
    
    // Call the server API to login with the test UID
    const response = await apiRequest("POST", "/api/test-login", { testUid });
    
    if (!response.ok) {
      throw new Error("Failed to login with test UID");
    }
    
    const userData = await response.json();
    
    // Update query client data to simulate authenticated state
    queryClient.setQueryData(["/api/user"], userData);
    
    return userData;
  } catch (error) {
    console.error("Error logging in with test UID:", error);
    throw error;
  }
};

// Register user in our database
async function registerUserInDatabase(uid: string, userData: {
  name: string, 
  email: string, 
  userType: UserType,
  firebaseUid: string
}) {
  try {
    // Make API call to register user in our database using the Firebase registration endpoint
    const response = await apiRequest("POST", "/api/firebase-register", userData);
    if (!response.ok) {
      throw new Error("Failed to register user in the database");
    }
    return await response.json();
  } catch (error) {
    console.error("Error registering user in database:", error);
    throw error;
  }
}

// Check if Google user exists in our database, if not register them
async function checkAndRegisterGoogleUser(user: any) {
  if (!user) return null;
  
  try {
    // Check if user exists in our database by firebase UID
    const checkResponse = await apiRequest("GET", `/api/users/firebase/${user.uid}`);
    
    // If user doesn't exist, register them
    if (!checkResponse.ok) {
      // Default to PET_OWNER for Google sign-ins, can be updated later
      await registerUserInDatabase(user.uid, {
        name: user.displayName || "",
        email: user.email || "",
        userType: UserType.PET_OWNER, 
        firebaseUid: user.uid
      });
    }
    
    return user;
  } catch (error) {
    console.error("Error checking/registering Google user:", error);
    throw error;
  }
}