import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Navigation, Search, Loader2, RefreshCcw, Map } from "lucide-react";
import { motion } from "framer-motion";
import LeafletMap from "./leaflet-map";
import { Coordinates, PetService, getCurrentLocation, reverseGeocode, fetchPetServicesNearby, getDefaultLocation } from "@/lib/geolocation";

interface MapViewProps {
  onLocationSelect: (location: { lat: number; lng: number; address: string }) => void;
}

export default function MapView({ onLocationSelect }: MapViewProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<Coordinates | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [address, setAddress] = useState<string>("");
  const [petServices, setPetServices] = useState<PetService[]>([]);
  const [isLoadingServices, setIsLoadingServices] = useState(false);
  const [serviceError, setServiceError] = useState<string | null>(null);
  
  // Function to get user's current location
  const getUserLocation = async () => {
    setIsLoading(true);
    setLocationError(null);
    
    try {
      const location = await getCurrentLocation();
      setCurrentLocation(location);
      
      // Get address using reverse geocoding
      const addressResult = await reverseGeocode(location);
      setAddress(addressResult);
      
      // Load nearby pet services
      await loadPetServices(location);
    } catch (error) {
      console.error('Error getting location:', error);
      setLocationError((error as Error).message || "Failed to get your location");
    } finally {
      setIsLoading(false);
    }
  };
  
  // Load pet services around the location
  const loadPetServices = async (location: Coordinates) => {
    setIsLoadingServices(true);
    setServiceError(null);
    
    try {
      const services = await fetchPetServicesNearby(location);
      setPetServices(services);
    } catch (error) {
      console.error('Error fetching pet services:', error);
      setServiceError("Failed to load nearby pet services. Please try again.");
    } finally {
      setIsLoadingServices(false);
    }
  };
  
  // Handle map center change
  const handleMapCenterChange = async (newCenter: Coordinates) => {
    setCurrentLocation(newCenter);
    
    // Update address for the new location
    const addressResult = await reverseGeocode(newCenter);
    setAddress(addressResult);
  };
  
  const handleSearch = () => {
    if (currentLocation && address) {
      onLocationSelect({ 
        ...currentLocation, 
        address 
      });
    }
  };
  
  // Refresh services at current location
  const refreshServices = () => {
    if (currentLocation) {
      loadPetServices(currentLocation);
    }
  };
  
  return (
    <Card className="w-full overflow-hidden">
      <CardContent className="p-6">
        <div className="text-center mb-6">
          <h3 className="text-2xl font-bold text-neutral-800 mb-2">Find Pet Services Near You</h3>
          <p className="text-neutral-600">
            Allow location access to discover pet services in your area
          </p>
        </div>
        
        <div className="bg-neutral-50 p-6 rounded-lg border border-neutral-200 mb-6">
          {!currentLocation ? (
            <div className="text-center">
              <div className="relative w-48 h-48 mx-auto mb-6">
                <div className="absolute inset-0 bg-primary/10 rounded-full animate-ping opacity-75"></div>
                <div className="relative bg-primary/20 rounded-full w-full h-full flex items-center justify-center z-10">
                  <MapPin className="h-16 w-16 text-primary" />
                </div>
              </div>
              
              <div className="flex flex-col gap-3">
                <Button 
                  onClick={getUserLocation}
                  disabled={isLoading}
                  className="bg-primary hover:bg-primary-dark text-white font-medium"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Locating...
                    </>
                  ) : (
                    <>
                      <Navigation className="h-4 w-4 mr-2" />
                      Use Current Location
                    </>
                  )}
                </Button>
                
                <Button 
                  onClick={async () => {
                    setIsLoading(true);
                    setIsLoadingServices(true);
                    const defaultLocation = getDefaultLocation();
                    setCurrentLocation(defaultLocation);
                    
                    try {
                      // Get address for the default location
                      const addressResult = await reverseGeocode(defaultLocation);
                      setAddress(addressResult);
                      
                      // Load services for the default location
                      await loadPetServices(defaultLocation);
                    } catch (error) {
                      console.error('Error setting up default location:', error);
                      setServiceError("Failed to load default services. Please try again.");
                    } finally {
                      setIsLoading(false);
                      setIsLoadingServices(false);
                    }
                  }}
                  disabled={isLoading}
                  variant="outline"
                  className="border-primary text-primary hover:bg-primary/10"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                      Loading New York...
                    </>
                  ) : (
                    <>
                      <Map className="h-4 w-4 mr-2" />
                      Browse New York Area
                    </>
                  )}
                </Button>
              </div>
              
              {locationError && (
                <motion.p 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-red-500 mt-4"
                >
                  {locationError}
                </motion.p>
              )}
            </div>
          ) : (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-4"
            >
              <div className="flex items-center bg-white p-3 rounded-md border border-neutral-200">
                <MapPin className="h-5 w-5 text-primary mr-2" />
                <span className="text-neutral-800 text-sm">{address}</span>
              </div>
              
              <div className="flex gap-2">
                <Button 
                  onClick={handleSearch}
                  className="flex-1 bg-primary hover:bg-primary-dark text-white font-medium"
                >
                  <Search className="h-4 w-4 mr-2" />
                  Find Services
                </Button>
                
                <Button 
                  variant="outline"
                  onClick={refreshServices}
                  disabled={isLoadingServices}
                  className="aspect-square px-2"
                  title="Refresh services"
                >
                  {isLoadingServices ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <RefreshCcw className="h-4 w-4" />
                  )}
                </Button>
              </div>
              
              <Button 
                variant="outline"
                onClick={() => {
                  setCurrentLocation(null);
                  setAddress("");
                  setPetServices([]);
                }}
                className="w-full"
              >
                Change Location
              </Button>
            </motion.div>
          )}
        </div>
        
        {/* Service count display */}
        {currentLocation && (
          <div className="mb-4 flex items-center justify-between">
            <div>
              <span className="font-medium">{petServices.length}</span>
              <span className="text-neutral-600"> pet services found nearby</span>
            </div>
            {serviceError && (
              <span className="text-red-500 text-sm">{serviceError}</span>
            )}
          </div>
        )}
        
        {/* Interactive map display */}
        {currentLocation && (
          <div className="border border-neutral-200 rounded-lg overflow-hidden">
            <LeafletMap 
              center={currentLocation}
              services={petServices}
              onMoveEnd={handleMapCenterChange}
              height="400px"
              zoom={14}
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
}