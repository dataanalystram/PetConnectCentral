import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Search,
  MapPin,
  Filter,
  Loader2,
  Star,
  AlertCircle,
  Clock,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Slider } from "@/components/ui/slider";
import { Card, CardContent } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { serviceCategories } from "@/data/services";
import { ServiceProviderType } from "@/lib/types";
import {
  filterServicesByProximity,
  formatDistance,
  Coordinates,
} from "@/lib/geolocation";

interface ServiceSearchProps {
  initialLocation?: Coordinates | null;
  onLocationChange?: (location: Coordinates) => void;
}

export default function ServiceSearch({
  initialLocation,
  onLocationChange,
}: ServiceSearchProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [category, setCategory] = useState<string>("");
  const [maxDistance, setMaxDistance] = useState<number>(10);
  const [minRating, setMinRating] = useState<number>(0);
  const [showFilters, setShowFilters] = useState(false);
  const [userLocation, setUserLocation] = useState<Coordinates | null>(
    initialLocation || null,
  );

  // Use TanStack Query to fetch data
  const {
    data: serviceProviders = [],
    isLoading,
    error,
  } = useQuery<ServiceProviderType[]>({
    queryKey: ["/api/service-providers"],
    // The queryFn is already set up in the queryClient
  });

  // Filter service providers based on search criteria and location
  const filteredProviders = serviceProviders
    .filter((provider) => {
      const matchesSearch =
        searchTerm === "" ||
        provider.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        provider.description.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesCategory = category === "" || provider.category === category;

      const matchesRating = provider.rating >= minRating;

      return matchesSearch && matchesCategory && matchesRating;
    })
    .map((provider) => {
      // Add mock location data for providers
      // In a real app, this would come from the database
      const mockLocation = {
        lat: 40.7128 + (Math.random() * 0.1 - 0.05),
        lng: -74.006 + (Math.random() * 0.1 - 0.05),
      };
      console.log(provider);
      if (provider.rating == null) provider.rating = 0;
      if (provider.price == null) provider.price = "Free";
      return {
        ...provider,
        location: mockLocation,
      };
    });

  // Filter by proximity if we have user location
  const providersWithDistance = userLocation
    ? filterServicesByProximity(filteredProviders, userLocation, maxDistance)
    : filteredProviders.map((provider) => ({
        ...provider,
        // If provider location is not a string (meaning it's a Coordinates object),
        // calculate a placeholder distance (since we don't have user location)
        distance:
          typeof provider.location !== "string"
            ? Math.random() * 10 // Random distance between 0-10km for display purposes
            : 0,
      }));

  // Reset filters
  const resetFilters = () => {
    setSearchTerm("");
    setCategory("");
    setMaxDistance(10);
    setMinRating(0);
  };

  return (
    <div className="space-y-6">
      {/* Search and Filters */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row gap-2">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400" />
            <Input
              type="text"
              placeholder="Search pet services..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          <Button
            variant="outline"
            onClick={() => setShowFilters(!showFilters)}
            className="sm:w-auto w-full"
          >
            <Filter className="h-4 w-4 mr-2" />
            Filters
          </Button>
        </div>

        <AnimatePresence>
          {showFilters && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
              className="overflow-hidden"
            >
              <Card>
                <CardContent className="p-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Category</label>
                    <Select value={category} onValueChange={setCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="All Categories" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All Categories</SelectItem>
                        {serviceCategories.map((category) => (
                          <SelectItem
                            key={category.value}
                            value={category.value}
                          >
                            {category.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Distance (km)</label>
                    <div className="pt-2">
                      <Slider
                        value={[maxDistance]}
                        min={1}
                        max={50}
                        step={1}
                        onValueChange={(value) => setMaxDistance(value[0])}
                      />
                      <div className="flex justify-between text-xs text-neutral-500 mt-1">
                        <span>1km</span>
                        <span>{maxDistance}km</span>
                        <span>50km</span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">
                      Minimum Rating
                    </label>
                    <div className="pt-2">
                      <Slider
                        value={[minRating]}
                        min={0}
                        max={5}
                        step={0.5}
                        onValueChange={(value) => setMinRating(value[0])}
                      />
                      <div className="flex justify-between text-xs text-neutral-500 mt-1">
                        <span>Any</span>
                        <span>{minRating} stars</span>
                        <span>5 stars</span>
                      </div>
                    </div>
                  </div>

                  <div className="md:col-span-3 flex justify-end">
                    <Button variant="outline" size="sm" onClick={resetFilters}>
                      Reset Filters
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Location indicator */}
      <div className="bg-neutral-50 p-3 rounded-md border border-neutral-200 flex items-center">
        <MapPin className="h-5 w-5 text-primary mr-2" />
        <span className="text-neutral-700 text-sm">
          {userLocation
            ? `Showing results within ${maxDistance}km of your location`
            : "Location filter not active - showing all services"}
        </span>
      </div>

      {/* Results */}
      <div>
        {isLoading ? (
          <div className="text-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary mx-auto mb-4" />
            <p className="text-neutral-600">Loading service providers...</p>
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <AlertCircle className="h-8 w-8 text-red-500 mx-auto mb-4" />
            <p className="text-neutral-800 font-medium">
              Error loading services
            </p>
            <p className="text-neutral-600">Please try again later</p>
          </div>
        ) : providersWithDistance.length === 0 ? (
          <div className="text-center py-12 bg-neutral-50 rounded-lg border border-neutral-200">
            <Search className="h-8 w-8 text-neutral-400 mx-auto mb-4" />
            <p className="text-neutral-800 font-medium">No services found</p>
            <p className="text-neutral-600 mb-4">
              Try adjusting your filters or search term
            </p>
            <Button variant="outline" onClick={resetFilters}>
              Reset Filters
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {providersWithDistance.map((provider) => (
              <ServiceProviderCard key={provider.id} provider={provider} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

interface ServiceProviderCardProps {
  provider: ServiceProviderType & { distance: number };
}

function ServiceProviderCard({ provider }: ServiceProviderCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="overflow-hidden h-full">
        <CardContent className="p-0">
          <div className="aspect-video bg-neutral-200 relative">
            {provider.image ? (
              <img
                src={provider.image}
                alt={provider.name}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-primary/10">
                <span className="text-primary font-medium">
                  {provider.category}
                </span>
              </div>
            )}
            <Badge className="absolute top-2 right-2 bg-primary text-white">
              {provider.category}
            </Badge>
          </div>

          <div className="p-4">
            <h3 className="font-semibold text-lg mb-1">{provider.name}</h3>

            <div className="flex items-center mb-2">
              <div className="flex items-center text-amber-500 mr-2">
                <Star className="fill-current h-4 w-4" />
                <span className="ml-1 text-sm font-medium">
                  {provider?.rating.toFixed(1)}
                </span>
              </div>
              <span className="text-neutral-500 text-sm">•</span>
              <div className="flex items-center ml-2 text-neutral-600 text-sm">
                <MapPin className="h-3 w-3 mr-1" />
                {formatDistance(provider.distance)}
              </div>
            </div>

            <p className="text-neutral-600 text-sm mb-3 line-clamp-2">
              {provider.description}
            </p>

            <div className="flex items-center justify-between mt-auto">
              <div className="text-neutral-900 font-semibold">
                {provider.price}
              </div>
              <Button size="sm" className="bg-primary hover:bg-primary-dark">
                <Clock className="h-3 w-3 mr-1" />
                Book Now
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}
