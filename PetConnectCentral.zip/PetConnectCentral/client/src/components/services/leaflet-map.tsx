import { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import { Icon } from 'leaflet';
import { Coordinates, PetService } from '@/lib/geolocation';

// Import Leaflet CSS in the component to ensure it's loaded
// This is required for the map to display properly
import 'leaflet/dist/leaflet.css';

// Fix for default marker icon issue in react-leaflet
// Create custom icons for different service types
const createCustomIcon = (color: string) => new Icon({
  iconUrl: `https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-${color}.png`,
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

const defaultIcon = createCustomIcon('blue');
const veterinaryIcon = createCustomIcon('red');
const petShopIcon = createCustomIcon('green');
const shelterIcon = createCustomIcon('orange');
const groomingIcon = createCustomIcon('violet');

// Helper to determine which icon to use based on service type
const getServiceIcon = (serviceType: string) => {
  if (serviceType.includes('veterinary')) return veterinaryIcon;
  if (serviceType.includes('pet')) return petShopIcon;
  if (serviceType.includes('animal_shelter')) return shelterIcon;
  if (serviceType.includes('pet_grooming')) return groomingIcon;
  return defaultIcon;
};

// Component to handle map view updates based on center changes
function MapViewUpdater({ center }: { center: Coordinates | null }) {
  const map = useMap();
  
  useEffect(() => {
    // Only update the map view if we have valid coordinates
    if (center && 
        typeof center.lat === 'number' && !isNaN(center.lat) && 
        typeof center.lng === 'number' && !isNaN(center.lng)) {
      map.setView([center.lat, center.lng], map.getZoom());
    }
  }, [center, map]);
  
  return null;
}

interface LeafletMapProps {
  center?: Coordinates | null;
  services: PetService[];
  onMoveEnd?: (newCenter: Coordinates) => void;
  height?: string;
  zoom?: number;
}

// Ensure center is always Coordinates | null, never undefined
function ensureCenter(center: Coordinates | null | undefined): Coordinates | null {
  return center || null;
}

export default function LeafletMap({ 
  center, 
  services, 
  onMoveEnd,
  height = '600px',
  zoom = 14
}: LeafletMapProps) {
  // Use default coordinates (New York City) if center is not provided
  const defaultLat = 40.7128;
  const defaultLng = -74.0060;
  
  // Ensure we have valid coordinates for the initial map center
  const initialLat = (center && typeof center.lat === 'number' && !isNaN(center.lat)) 
    ? center.lat : defaultLat;
  const initialLng = (center && typeof center.lng === 'number' && !isNaN(center.lng))
    ? center.lng : defaultLng;
  
  const [mapCenter, setMapCenter] = useState<[number, number]>([initialLat, initialLng]);
  
  // Update local state when center prop changes
  useEffect(() => {
    if (center && 
        typeof center.lat === 'number' && !isNaN(center.lat) && 
        typeof center.lng === 'number' && !isNaN(center.lng)) {
      setMapCenter([center.lat, center.lng]);
    }
  }, [center]);
  
  // Handle map movement if needed
  const handleMoveEnd = (e: any) => {
    if (onMoveEnd) {
      const center = e.target.getCenter();
      onMoveEnd({ lat: center.lat, lng: center.lng });
    }
  };

  return (
    <div style={{ height }}>
      <MapContainer
        center={mapCenter}
        zoom={zoom}
        scrollWheelZoom={true}
        style={{ height: '100%', width: '100%' }}
        // @ts-ignore: React Leaflet typing issue
        whenReady={(map: any) => {
          if (onMoveEnd) {
            map.target.on('moveend', handleMoveEnd);
          }
        }}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <MapViewUpdater center={ensureCenter(center)} />
        
        {/* User's location marker */}
        {center && 
         typeof center.lat === 'number' && !isNaN(center.lat) &&
         typeof center.lng === 'number' && !isNaN(center.lng) && (
          <Marker position={[center.lat, center.lng]} icon={defaultIcon}>
            <Popup>
              <div className="text-center">
                <div className="font-semibold">Your Location</div>
                <div className="text-xs text-gray-500">Drag map to explore different areas</div>
              </div>
            </Popup>
          </Marker>
        )}
        
        {/* Service markers */}
        {services.filter(service => 
          typeof service.lat === 'number' && !isNaN(service.lat) &&
          typeof service.lon === 'number' && !isNaN(service.lon)
        ).map((service) => (
          <Marker 
            key={service.id} 
            position={[service.lat, service.lon]} 
            icon={getServiceIcon(service.type)}
          >
            <Popup>
              <div className="min-w-[200px]">
                <h3 className="font-semibold text-lg">{service.name}</h3>
                <div className="text-sm">
                  <div className="text-neutral-500 capitalize mb-1">{service.type.replace('_', ' ')}</div>
                  {service.address && (
                    <div className="mb-1">
                      <span className="font-semibold">Address:</span> {service.address}
                    </div>
                  )}
                  {service.opening_hours && (
                    <div className="mb-1">
                      <span className="font-semibold">Hours:</span> {service.opening_hours}
                    </div>
                  )}
                  {service.phone && (
                    <div className="mb-1">
                      <span className="font-semibold">Phone:</span> {service.phone}
                    </div>
                  )}
                  {service.distance !== undefined && (
                    <div className="text-primary font-semibold mt-2">
                      {service.distance.toFixed(2)} km away
                    </div>
                  )}
                  {service.website && (
                    <a 
                      href={service.website} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-primary hover:underline block mt-2"
                    >
                      Visit Website
                    </a>
                  )}
                </div>
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}