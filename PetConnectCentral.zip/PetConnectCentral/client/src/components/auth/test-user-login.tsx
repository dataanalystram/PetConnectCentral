import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { PawPrint, User, Building, UserCog } from "lucide-react";

// Helper function to make auth header request
const loginWithTestUid = async (firebaseUid: string) => {
  try {
    // Store the test token in localStorage first
    localStorage.setItem('firebaseToken', firebaseUid);
    
    // Then make the profile request with the token
    const response = await fetch('/api/user/profile', {
      headers: {
        'Authorization': `Bearer ${firebaseUid}`
      }
    });

    if (!response.ok) {
      console.log('Response status:', response.status);
      const errorText = await response.text();
      console.log('Error response:', errorText);
      throw new Error('Failed to login with test UID');
    }
    
    return await response.json();
  } catch (error) {
    console.error("Error logging in with test UID:", error);
    throw error;
  }
};

export default function TestUserLogin() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [customUid, setCustomUid] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleTestUserLogin = async (uid: string) => {
    setIsLoading(true);
    try {
      const result = await loginWithTestUid(uid);
      toast({
        title: "Login Successful",
        description: "You've been logged in with the test account.",
      });
      
      // Redirect based on user type
      if (uid === 'test-firebase-uid-petowner') {
        setLocation("/dashboard");
      } else if (uid === 'test-firebase-uid-provider') {
        setLocation("/provider-dashboard");
      } else if (uid === 'test-firebase-uid-shelter') {
        setLocation("/shelter-dashboard");
      } else {
        setLocation("/dashboard");
      }
    } catch (error) {
      toast({
        title: "Login Failed",
        description: "Failed to login with the test account.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>Test User Login</CardTitle>
        <CardDescription>
          You can login with these test accounts during development
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <Button 
            className="w-full flex justify-between items-center"
            onClick={() => handleTestUserLogin("test-firebase-uid-petowner")}
            disabled={isLoading}
          >
            <div className="flex items-center">
              <User className="mr-2 h-4 w-4" />
              <span>Login as Pet Owner</span>
            </div>
            <PawPrint className="h-4 w-4" />
          </Button>
          
          <Button
            className="w-full flex justify-between items-center"
            onClick={() => handleTestUserLogin("test-firebase-uid-provider")}
            disabled={isLoading}
          >
            <div className="flex items-center">
              <UserCog className="mr-2 h-4 w-4" />
              <span>Login as Service Provider</span>
            </div>
            <PawPrint className="h-4 w-4" />
          </Button>
          
          <Button
            className="w-full flex justify-between items-center"
            onClick={() => handleTestUserLogin("test-firebase-uid-shelter")}
            disabled={isLoading}
          >
            <div className="flex items-center">
              <Building className="mr-2 h-4 w-4" />
              <span>Login as Shelter</span>
            </div>
            <PawPrint className="h-4 w-4" />
          </Button>
          
          <div className="pt-2">
            <Label htmlFor="custom-uid">Or enter a custom Firebase UID:</Label>
            <div className="flex gap-2 mt-1">
              <Input
                id="custom-uid"
                value={customUid}
                onChange={(e) => setCustomUid(e.target.value)}
                placeholder="Enter a custom Firebase UID"
              />
              <Button 
                onClick={() => handleTestUserLogin(customUid)}
                disabled={!customUid || isLoading}
              >
                Login
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}