import { useState } from "react";
import { UserType } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ArrowLeft, ArrowRight, CheckCircle2 } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

interface RegistrationFlowProps {
  userType: UserType;
  onBack: () => void;
  onComplete: (formData: any) => void;
}

export default function RegistrationFlow({ userType, onBack, onComplete }: RegistrationFlowProps) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState<any>({});
  
  // Go to next step
  const nextStep = (data: any) => {
    setFormData({...formData, ...data});
    setStep(step + 1);
  };
  
  // Go to previous step
  const prevStep = () => {
    setStep(step - 1);
  };
  
  // Handle final submit
  const handleComplete = (data: any) => {
    const finalData = {...formData, ...data};
    onComplete(finalData);
  };
  
  return (
    <div>
      <div className="mb-8">
        <Button variant="ghost" size="sm" onClick={onBack} className="mb-4">
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back
        </Button>
        
        <h2 className="font-heading font-bold text-2xl text-neutral-800 mb-2">
          {userType === UserType.PET_OWNER && "Tell us about yourself"}
          {userType === UserType.SERVICE_PROVIDER && "Tell us about your business"}
          {userType === UserType.SHELTER && "Tell us about your organization"}
        </h2>
        
        <p className="text-neutral-600">
          {userType === UserType.PET_OWNER && "Help us personalize your experience by sharing some information"}
          {userType === UserType.SERVICE_PROVIDER && "Set up your service provider account with the essential details"}
          {userType === UserType.SHELTER && "Set up your shelter profile to help pets find homes"}
        </p>
      </div>
      
      <div className="mb-6">
        <div className="flex items-center justify-between">
          <StepIndicator currentStep={step} totalSteps={getStepCount(userType)} />
        </div>
      </div>
      
      {/* Steps for each user type */}
      {userType === UserType.PET_OWNER && renderPetOwnerSteps(step, nextStep, prevStep, handleComplete)}
      {userType === UserType.SERVICE_PROVIDER && renderProviderSteps(step, nextStep, prevStep, handleComplete)}
      {userType === UserType.SHELTER && renderShelterSteps(step, nextStep, prevStep, handleComplete)}
    </div>
  );
}

// Get number of steps for each user type
function getStepCount(userType: UserType): number {
  switch(userType) {
    case UserType.PET_OWNER:
      return 2;
    case UserType.SERVICE_PROVIDER:
      return 3;
    case UserType.SHELTER:
      return 3;
    default:
      return 2;
  }
}

// Step indicator component
function StepIndicator({ currentStep, totalSteps }: { currentStep: number; totalSteps: number }) {
  return (
    <div className="w-full">
      <div className="flex justify-between mb-2">
        {Array.from({ length: totalSteps }).map((_, i) => (
          <div key={i} className="text-xs font-medium text-neutral-600">
            Step {i + 1}
          </div>
        ))}
      </div>
      <div className="w-full bg-neutral-200 rounded-full h-2 mb-1">
        <div 
          className="bg-primary h-2 rounded-full transition-all duration-300"
          style={{ width: `${(currentStep / totalSteps) * 100}%` }}
        ></div>
      </div>
    </div>
  );
}

// Pet Owner Steps
function renderPetOwnerSteps(step: number, nextStep: (data: any) => void, prevStep: () => void, handleComplete: (data: any) => void) {
  switch (step) {
    case 1:
      return <PetOwnerStep1 onNext={nextStep} />;
    case 2:
      return <PetOwnerStep2 onBack={prevStep} onComplete={handleComplete} />;
    default:
      return null;
  }
}

// Service Provider Steps
function renderProviderSteps(step: number, nextStep: (data: any) => void, prevStep: () => void, handleComplete: (data: any) => void) {
  switch (step) {
    case 1:
      return <ProviderStep1 onNext={nextStep} />;
    case 2:
      return <ProviderStep2 onBack={prevStep} onNext={nextStep} />;
    case 3:
      return <ProviderStep3 onBack={prevStep} onComplete={handleComplete} />;
    default:
      return null;
  }
}

// Shelter Steps
function renderShelterSteps(step: number, nextStep: (data: any) => void, prevStep: () => void, handleComplete: (data: any) => void) {
  switch (step) {
    case 1:
      return <ShelterStep1 onNext={nextStep} />;
    case 2:
      return <ShelterStep2 onBack={prevStep} onNext={nextStep} />;
    case 3:
      return <ShelterStep3 onBack={prevStep} onComplete={handleComplete} />;
    default:
      return null;
  }
}

// Pet Owner Steps Components
function PetOwnerStep1({ onNext }: { onNext: (data: any) => void }) {
  const formSchema = z.object({
    location: z.string().min(2, "Please enter your location"),
    petTypes: z.string().min(1, "Please select at least one pet type"),
  });
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      location: "",
      petTypes: "",
    },
  });
  
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    onNext(values);
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Your Location</CardTitle>
        <CardDescription>This helps us find services near you</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Your Location</FormLabel>
                  <FormControl>
                    <Input placeholder="City, State" {...field} />
                  </FormControl>
                  <FormDescription>
                    Enter your city and state to find nearby services
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="petTypes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>What pets do you have?</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select pet type" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="dog">Dog</SelectItem>
                      <SelectItem value="cat">Cat</SelectItem>
                      <SelectItem value="bird">Bird</SelectItem>
                      <SelectItem value="small_mammal">Small Mammal</SelectItem>
                      <SelectItem value="reptile">Reptile</SelectItem>
                      <SelectItem value="fish">Fish</SelectItem>
                      <SelectItem value="other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Choose the type of pets you currently have
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" className="w-full">
              Next
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

function PetOwnerStep2({ onBack, onComplete }: { onBack: () => void; onComplete: (data: any) => void }) {
  const formSchema = z.object({
    preferences: z.string().optional(),
  });
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      preferences: "",
    },
  });
  
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    onComplete(values);
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Your Preferences</CardTitle>
        <CardDescription>Tell us more about your pet care interests</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="preferences"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>What pet services are you interested in?</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="E.g. Grooming, training, boarding, veterinary care..." 
                      className="min-h-[120px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    This helps us personalize recommendations for you
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex justify-between">
              <Button type="button" variant="outline" onClick={onBack}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
              <Button type="submit">
                Complete
                <CheckCircle2 className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

// Service Provider Steps Components
function ProviderStep1({ onNext }: { onNext: (data: any) => void }) {
  const formSchema = z.object({
    businessName: z.string().min(2, "Business name is required"),
    category: z.string().min(1, "Please select a service category"),
  });
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      businessName: "",
      category: "",
    },
  });
  
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    onNext(values);
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Business Information</CardTitle>
        <CardDescription>Tell us about your pet service business</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="businessName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Business Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Your business name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Service Category</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select primary service category" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="veterinary">Veterinary Care</SelectItem>
                      <SelectItem value="grooming">Grooming</SelectItem>
                      <SelectItem value="training">Training</SelectItem>
                      <SelectItem value="sitting">Pet Sitting & Walking</SelectItem>
                      <SelectItem value="boarding">Boarding & Daycare</SelectItem>
                      <SelectItem value="retail">Pet Supplies & Retail</SelectItem>
                      <SelectItem value="other">Other Services</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Choose the main category that describes your services
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" className="w-full">
              Next
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

function ProviderStep2({ onBack, onNext }: { onBack: () => void; onNext: (data: any) => void }) {
  const formSchema = z.object({
    address: z.string().min(5, "Please provide your business address"),
    phone: z.string().min(10, "Please provide a valid phone number"),
  });
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      address: "",
      phone: "",
    },
  });
  
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    onNext(values);
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Contact Information</CardTitle>
        <CardDescription>How clients can reach your business</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="address"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Business Address</FormLabel>
                  <FormControl>
                    <Input placeholder="Full address" {...field} />
                  </FormControl>
                  <FormDescription>
                    Your business location will be shown on maps
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Business Phone</FormLabel>
                  <FormControl>
                    <Input placeholder="Phone number" {...field} />
                  </FormControl>
                  <FormDescription>
                    Your contact phone for client inquiries
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex justify-between">
              <Button type="button" variant="outline" onClick={onBack}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
              <Button type="submit">
                Next
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

function ProviderStep3({ onBack, onComplete }: { onBack: () => void; onComplete: (data: any) => void }) {
  const formSchema = z.object({
    description: z.string().min(10, "Please provide a description of your services"),
    priceRange: z.string().min(1, "Please select your price range"),
  });
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      description: "",
      priceRange: "",
    },
  });
  
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    onComplete(values);
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Service Details</CardTitle>
        <CardDescription>Describe what you offer to pet owners</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Service Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Describe your services, expertise, and what makes you unique..." 
                      className="min-h-[120px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    This will be shown on your business profile
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="priceRange"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Price Range</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select your price range" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="$">$ - Budget-friendly</SelectItem>
                      <SelectItem value="$$">$$ - Mid-range</SelectItem>
                      <SelectItem value="$$$">$$$ - Premium</SelectItem>
                      <SelectItem value="varies">Varies by service</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    Give clients an idea of your pricing
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex justify-between">
              <Button type="button" variant="outline" onClick={onBack}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
              <Button type="submit">
                Complete
                <CheckCircle2 className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

// Shelter Steps Components
function ShelterStep1({ onNext }: { onNext: (data: any) => void }) {
  const formSchema = z.object({
    organizationName: z.string().min(2, "Organization name is required"),
    mission: z.string().min(10, "Please provide your mission statement"),
  });
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      organizationName: "",
      mission: "",
    },
  });
  
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    onNext(values);
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Organization Information</CardTitle>
        <CardDescription>Tell us about your shelter or rescue</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="organizationName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Organization Name</FormLabel>
                  <FormControl>
                    <Input placeholder="Your shelter or rescue name" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="mission"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Mission Statement</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Describe your organization's mission and values..." 
                      className="min-h-[120px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    This helps potential adopters understand your purpose
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" className="w-full">
              Next
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

function ShelterStep2({ onBack, onNext }: { onBack: () => void; onNext: (data: any) => void }) {
  const formSchema = z.object({
    address: z.string().min(5, "Please provide your organization address"),
    phone: z.string().min(10, "Please provide a valid phone number"),
  });
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      address: "",
      phone: "",
    },
  });
  
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    onNext(values);
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Contact Information</CardTitle>
        <CardDescription>How adopters can reach your organization</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="address"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Organization Address</FormLabel>
                  <FormControl>
                    <Input placeholder="Full address" {...field} />
                  </FormControl>
                  <FormDescription>
                    Your location will be shown on maps
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Contact Phone</FormLabel>
                  <FormControl>
                    <Input placeholder="Phone number" {...field} />
                  </FormControl>
                  <FormDescription>
                    Your contact phone for adoption inquiries
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex justify-between">
              <Button type="button" variant="outline" onClick={onBack}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
              <Button type="submit">
                Next
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}

function ShelterStep3({ onBack, onComplete }: { onBack: () => void; onComplete: (data: any) => void }) {
  const formSchema = z.object({
    petTypes: z.string().min(1, "Please select the types of pets you offer for adoption"),
    adoptionProcess: z.string().min(10, "Please describe your adoption process"),
  });
  
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      petTypes: "",
      adoptionProcess: "",
    },
  });
  
  const onSubmit = (values: z.infer<typeof formSchema>) => {
    onComplete(values);
  };
  
  return (
    <Card>
      <CardHeader>
        <CardTitle>Adoption Information</CardTitle>
        <CardDescription>Tell us about the pets you help and your adoption process</CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="petTypes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Pet Types Available for Adoption</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select pet types" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="dogs">Dogs</SelectItem>
                      <SelectItem value="cats">Cats</SelectItem>
                      <SelectItem value="both">Both Dogs and Cats</SelectItem>
                      <SelectItem value="small_animals">Small Animals</SelectItem>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="specialized">Specialized (e.g., certain breeds)</SelectItem>
                    </SelectContent>
                  </Select>
                  <FormDescription>
                    The main types of pets your organization helps
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="adoptionProcess"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Adoption Process</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Describe your adoption process, requirements, and fees..." 
                      className="min-h-[120px]"
                      {...field} 
                    />
                  </FormControl>
                  <FormDescription>
                    This helps potential adopters understand what to expect
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="flex justify-between">
              <Button type="button" variant="outline" onClick={onBack}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Button>
              <Button type="submit">
                Complete
                <CheckCircle2 className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}