import { UserType } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { PawPrint, Store, Building } from "lucide-react";

interface WelcomeScreenProps {
  onUserTypeSelect: (userType: UserType) => void;
  onSkip: () => void;
}

export default function WelcomeScreen({ onUserTypeSelect, onSkip }: WelcomeScreenProps) {
  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="font-heading font-bold text-2xl md:text-3xl text-neutral-800 mb-2">
          Choose your role on PetPals
        </h2>
        <p className="text-neutral-600">
          Select how you'll be using our platform to get a personalized experience
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <UserTypeCard
          title="Pet Owner"
          description="Looking for services and resources for your pet"
          icon={<PawPrint className="h-10 w-10 text-primary" />}
          onClick={() => onUserTypeSelect(UserType.PET_OWNER)}
        />
        
        <UserTypeCard
          title="Service Provider"
          description="Offering pet care services to pet owners"
          icon={<Store className="h-10 w-10 text-primary" />}
          onClick={() => onUserTypeSelect(UserType.SERVICE_PROVIDER)}
        />
        
        <UserTypeCard
          title="Shelter/Rescue"
          description="Facilitating pet adoptions and fostering"
          icon={<Building className="h-10 w-10 text-primary" />}
          onClick={() => onUserTypeSelect(UserType.SHELTER)}
        />
      </div>

      <div className="text-center mt-4">
        <Button variant="link" onClick={onSkip}>
          Skip for now
        </Button>
      </div>
    </div>
  );
}

interface UserTypeCardProps {
  title: string;
  description: string;
  icon: React.ReactNode;
  onClick: () => void;
}

function UserTypeCard({ title, description, icon, onClick }: UserTypeCardProps) {
  return (
    <Card 
      className="border-2 hover:border-primary hover:shadow-md transition-all duration-300 cursor-pointer"
      onClick={onClick}
    >
      <CardHeader className="text-center pb-2">
        <div className="mx-auto mb-4">{icon}</div>
        <CardTitle className="text-xl">{title}</CardTitle>
      </CardHeader>
      <CardContent className="text-center text-neutral-600 text-sm">
        <p>{description}</p>
      </CardContent>
      <CardFooter className="justify-center pt-2">
        <Button variant="secondary">Select</Button>
      </CardFooter>
    </Card>
  );
}