import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";
import DashboardHeader from "./dashboard-header";
import { UserType } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Calendar,
  Clock,
  Heart,
  Home,
  MapPin,
  Plus,
  Search,
  Loader2,
  FileText,
  Settings,
} from "lucide-react";

// Custom PawPrint icon component
function PawPrint(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      {...props}
    >
      <circle cx="11" cy="4" r="2.5" />
      <circle cx="18" cy="8" r="2.5" />
      <circle cx="4" cy="8" r="2.5" />
      <circle cx="7.5" cy="14" r="2.5" />
      <circle cx="16.5" cy="14" r="2.5" />
      <path d="M12 16a8 8 0 0 1 5.333 2h-10.666A8 8 0 0 1 12 16z" />
    </svg>
  );
}

export default function PetOwnerDashboard() {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");
  
  // Define types for the data
  interface Pet {
    id: number;
    name: string;
    type: string;
    breed?: string;
    age?: number;
    mainImageUrl?: string;
  }
  
  interface Appointment {
    id: number;
    dateTime: string;
    serviceType: string;
    status: string;
  }
  
  interface Favorite {
    id: number;
    pet: Pet;
  }
  
  interface Service {
    id: number;
    name: string;
    description: string;
    price: number;
    category: string;
  }

  // Fetch user appointments
  const { 
    data: appointments = [] as Appointment[], 
    isLoading: isLoadingAppointments 
  } = useQuery<Appointment[]>({
    queryKey: ["/api/appointments"],
    enabled: !!userProfile,
  });
  
  // Fetch user favorite pets
  const { 
    data: favorites = [] as Favorite[], 
    isLoading: isLoadingFavorites 
  } = useQuery<Favorite[]>({
    queryKey: ["/api/favorites"],
    enabled: !!userProfile,
  });
  
  // Fetch nearby services (would be parameterized by user location in a real app)
  const { 
    data: services = [] as Service[], 
    isLoading: isLoadingServices 
  } = useQuery<Service[]>({
    queryKey: ["/api/services"],
    enabled: !!userProfile,
  });
  
  // Fetch user's pets
  const { 
    data: pets = [] as Pet[], 
    isLoading: isLoadingPets 
  } = useQuery<Pet[]>({
    queryKey: ["/api/pets"],
    enabled: !!userProfile,
  });
  
  // Fetch pet recommendations based on user preferences
  const { 
    data: recommendedPets = [] as Pet[], 
    isLoading: isLoadingRecommendedPets 
  } = useQuery<Pet[]>({
    queryKey: ["/api/pets/recommended"],
    enabled: !!userProfile,
  });
  
  // Handler for booking a new appointment
  const handleBookAppointment = (serviceId: number) => {
    toast({
      title: "Booking appointment",
      description: "This feature is coming soon!",
    });
  };
  
  // Handler for removing a favorite
  const handleRemoveFavorite = async (favoriteId: number) => {
    try {
      await apiRequest("DELETE", `/api/favorites/${favoriteId}`);
      toast({
        title: "Favorite removed",
        description: "Pet has been removed from your favorites",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to remove favorite",
        variant: "destructive",
      });
    }
  };
  
  // Handler for canceling an appointment
  const handleCancelAppointment = async (appointmentId: number) => {
    try {
      await apiRequest("PATCH", `/api/appointments/${appointmentId}`, {
        status: "cancelled",
      });
      toast({
        title: "Appointment cancelled",
        description: "Your appointment has been cancelled",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to cancel appointment",
        variant: "destructive",
      });
    }
  };
  
  if (!userProfile) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
          Welcome, {userProfile.name ? userProfile.name.split(' ')[0] : 'Pet Parent'}
        </h1>
        <p className="text-muted-foreground mt-1">Here's what's happening with your pets today.</p>
      </div>
      
      {/* Quick Actions - Redesigned for better visual appeal */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6 mb-10">
        <Link href="/services" className="no-underline">
          <div className="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-primary/5 to-primary/10 rounded-lg border border-border/40 shadow-sm hover:shadow-md transition-all hover:scale-[1.02] hover:border-primary/30 cursor-pointer group">
            <div className="p-3 rounded-full bg-primary/10 mb-3 group-hover:bg-primary/20 transition-colors">
              <Search className="h-6 w-6 text-primary" />
            </div>
            <span className="font-medium text-center">Find Services</span>
          </div>
        </Link>
        
        <Link href="/adoption" className="no-underline">
          <div className="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-primary/5 to-primary/10 rounded-lg border border-border/40 shadow-sm hover:shadow-md transition-all hover:scale-[1.02] hover:border-primary/30 cursor-pointer group">
            <div className="p-3 rounded-full bg-primary/10 mb-3 group-hover:bg-primary/20 transition-colors">
              <PawPrint className="h-6 w-6 text-primary" />
            </div>
            <span className="font-medium text-center">Adopt a Pet</span>
          </div>
        </Link>
        
        <Link href="/resources" className="no-underline">
          <div className="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-primary/5 to-primary/10 rounded-lg border border-border/40 shadow-sm hover:shadow-md transition-all hover:scale-[1.02] hover:border-primary/30 cursor-pointer group">
            <div className="p-3 rounded-full bg-primary/10 mb-3 group-hover:bg-primary/20 transition-colors">
              <FileText className="h-6 w-6 text-primary" />
            </div>
            <span className="font-medium text-center">Pet Resources</span>
          </div>
        </Link>
        
        <Link href="/account-settings" className="no-underline">
          <div className="flex flex-col items-center justify-center p-6 bg-gradient-to-br from-primary/5 to-primary/10 rounded-lg border border-border/40 shadow-sm hover:shadow-md transition-all hover:scale-[1.02] hover:border-primary/30 cursor-pointer group">
            <div className="p-3 rounded-full bg-primary/10 mb-3 group-hover:bg-primary/20 transition-colors">
              <Settings className="h-6 w-6 text-primary" />
            </div>
            <span className="font-medium text-center">Account Settings</span>
          </div>
        </Link>
      </div>
      
      {/* My Pets Section with visual improvements */}
      <div className="mb-10">
        <div className="flex justify-between items-center mb-5">
          <h2 className="text-2xl font-semibold">My Pets</h2>
          <Button asChild variant="outline" size="sm" className="gap-2">
            <Link href="/pets/add">
              <Plus className="h-4 w-4" />
              Add Pet
            </Link>
          </Button>
        </div>
        
        <div className="overflow-x-auto pb-4">
          <div className="flex gap-5">
            {isLoadingPets ? (
              Array.from({ length: 2 }).map((_, index) => (
                <div key={index} className="flex-shrink-0 w-40 h-52 rounded-lg bg-muted animate-pulse" />
              ))
            ) : (pets as Pet[]).length === 0 ? (
              <div className="w-full">
                <Card className="bg-muted/50 border-dashed">
                  <CardContent className="flex flex-col items-center justify-center py-12">
                    <PawPrint className="h-12 w-12 text-muted-foreground/40 mb-4" />
                    <p className="text-center text-muted-foreground mb-4">No pets added yet</p>
                    <Button asChild>
                      <Link href="/pets/add">Add Your First Pet</Link>
                    </Button>
                  </CardContent>
                </Card>
              </div>
            ) : (
              <>
                {(pets as Pet[]).map((pet) => (
                  <Link href={`/pets/${pet.id}`} key={pet.id} className="no-underline">
                    <div className="flex-shrink-0 w-40 group cursor-pointer">
                      <div className="relative h-40 rounded-lg overflow-hidden border-2 border-transparent group-hover:border-primary transition-all duration-200">
                        {pet.mainImageUrl ? (
                          <img 
                            src={pet.mainImageUrl} 
                            alt={pet.name} 
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        ) : (
                          <div className={`w-full h-full flex items-center justify-center ${
                            pet.type === 'dog' ? 'bg-blue-100' : 
                            pet.type === 'cat' ? 'bg-green-100' : 
                            'bg-purple-100'
                          }`}>
                            <span className="text-4xl font-bold text-gray-500">{pet.name.charAt(0)}</span>
                          </div>
                        )}
                        <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-3">
                          <h3 className="text-white font-bold">{pet.name}</h3>
                        </div>
                      </div>
                      <div className="mt-2">
                        <p className="text-sm text-muted-foreground">{pet.breed || pet.type}</p>
                      </div>
                    </div>
                  </Link>
                ))}
                
                <Link href="/pets/add" className="no-underline">
                  <div className="flex-shrink-0 w-40 h-40 rounded-lg border-2 border-dashed border-primary/30 flex flex-col items-center justify-center bg-primary/5 hover:bg-primary/10 transition-colors cursor-pointer">
                    <Plus className="h-8 w-8 text-primary/50 mb-2" />
                    <span className="text-sm font-medium text-primary">Add Another Pet</span>
                  </div>
                </Link>
              </>
            )}
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid grid-cols-3 md:grid-cols-4 lg:w-auto bg-primary/5 text-primary">
          <TabsTrigger value="overview" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Home className="h-4 w-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="appointments" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Calendar className="h-4 w-4 mr-2" />
            Appointments
          </TabsTrigger>
          <TabsTrigger value="favorites" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Heart className="h-4 w-4 mr-2" />
            Favorites
          </TabsTrigger>
          <TabsTrigger value="services" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Search className="h-4 w-4 mr-2" />
            Find Services
          </TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {/* Upcoming Appointments Card */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-medium">Upcoming Appointments</CardTitle>
                <CardDescription>Your scheduled appointments</CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                {isLoadingAppointments ? (
                  <div className="flex justify-center py-6">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : appointments.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    <p>No upcoming appointments</p>
                    <Button variant="link" onClick={() => setActiveTab("services")}>
                      Book an appointment
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {(appointments as Appointment[]).slice(0, 3).map((appointment) => (
                      <div key={appointment.id} className="flex items-start space-x-3 border-b border-border pb-3 last:border-0">
                        <div className="bg-primary/10 rounded-md p-2">
                          <Calendar className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{appointment.serviceType}</p>
                          <div className="flex items-center text-sm text-muted-foreground mt-1">
                            <Clock className="h-3 w-3 mr-1" />
                            <span>{new Date(appointment.dateTime).toLocaleDateString()}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => setActiveTab("appointments")}>
                  View All Appointments
                </Button>
              </CardFooter>
            </Card>
            
            {/* Favorites Card */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-medium">Favorite Pets</CardTitle>
                <CardDescription>Pets you've saved</CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                {isLoadingFavorites ? (
                  <div className="flex justify-center py-6">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : favorites.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    <p>No favorite pets yet</p>
                    <Button variant="link" asChild>
                      <Link href="/adoption">Browse pets</Link>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {(favorites as Favorite[]).map((favorite) => (
                      <div key={favorite.id} className="flex items-start space-x-3 border-b border-border pb-3 last:border-0">
                        <div className="relative w-14 h-14 rounded-md overflow-hidden bg-primary/10">
                          {favorite.pet.mainImageUrl ? (
                            <img 
                              src={favorite.pet.mainImageUrl} 
                              alt={favorite.pet.name} 
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="flex items-center justify-center h-full">
                              <svg className="h-6 w-6 text-primary" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                              </svg>
                            </div>
                          )}
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{favorite.pet.name}</p>
                          <div className="flex items-center text-sm text-muted-foreground mt-1">
                            <span>{favorite.pet.breed}, {favorite.pet.age} years</span>
                          </div>
                          <div className="mt-2">
                            <Button variant="link" className="h-auto p-0 text-sm" asChild>
                              <Link href={`/adopt/${favorite.pet.id}`}>View Profile</Link>
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => setActiveTab("favorites")}>
                  View All Favorites
                </Button>
              </CardFooter>
            </Card>
            
            {/* Recommended Pets Card */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-medium">Recommended Pets</CardTitle>
                <CardDescription>Based on your preferences</CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                {isLoadingRecommendedPets ? (
                  <div className="flex justify-center py-6">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : recommendedPets.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    <p>No recommendations yet</p>
                    <Button variant="link" asChild>
                      <Link href="/profile">Update your preferences</Link>
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {(recommendedPets as Pet[]).map((pet) => (
                      <div key={pet.id} className="flex items-start space-x-3 border-b border-border pb-3 last:border-0">
                        <div className="relative w-14 h-14 rounded-md overflow-hidden bg-primary/10">
                          {pet.mainImageUrl ? (
                            <img 
                              src={pet.mainImageUrl} 
                              alt={pet.name} 
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="flex items-center justify-center h-full">
                              <span className="text-xl font-bold text-primary/60">{pet.name.charAt(0)}</span>
                            </div>
                          )}
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{pet.name}</p>
                          <div className="flex items-center text-sm text-muted-foreground mt-1">
                            <span>{pet.breed}, {pet.age} years</span>
                          </div>
                          <div className="mt-2">
                            <Button variant="link" className="h-auto p-0 text-sm" asChild>
                              <Link href={`/adopt/${pet.id}`}>View Profile</Link>
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" asChild>
                  <Link href="/adoption">Browse All Pets</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        {/* Appointments Tab */}
        <TabsContent value="appointments" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Your Appointments</h2>
            <Button asChild>
              <Link href="/services">
                <Plus className="h-4 w-4 mr-2" />
                Book New Appointment
              </Link>
            </Button>
          </div>
          
          {isLoadingAppointments ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : appointments.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Calendar className="h-16 w-16 text-primary/20 mb-4" />
                <h3 className="text-xl font-medium mb-2">No appointments yet</h3>
                <p className="text-muted-foreground mb-6 text-center max-w-md">
                  You don't have any scheduled appointments. Book a service appointment to get started.
                </p>
                <Button asChild>
                  <Link href="/services">Browse Services</Link>
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {/* Appointment list would go here */}
              <p className="text-muted-foreground text-center py-8">
                Your appointments will appear here once you book them.
              </p>
            </div>
          )}
        </TabsContent>
        
        {/* Favorites Tab */}
        <TabsContent value="favorites" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Your Favorite Pets</h2>
            <Button asChild variant="outline">
              <Link href="/adoption">
                <Search className="h-4 w-4 mr-2" />
                Find More Pets
              </Link>
            </Button>
          </div>
          
          {isLoadingFavorites ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : favorites.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Heart className="h-16 w-16 text-primary/20 mb-4" />
                <h3 className="text-xl font-medium mb-2">No favorite pets yet</h3>
                <p className="text-muted-foreground mb-6 text-center max-w-md">
                  You haven't added any pets to your favorites yet. Browse pets for adoption and save them to your favorites.
                </p>
                <Button asChild>
                  <Link href="/adoption">Browse Pets</Link>
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {/* Favorites grid would go here */}
              <p className="text-muted-foreground text-center py-8 col-span-full">
                Your favorite pets will appear here once you add them.
              </p>
            </div>
          )}
        </TabsContent>
        
        {/* Services Tab */}
        <TabsContent value="services" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Nearby Pet Services</h2>
            <div className="flex items-center bg-background rounded-md border px-3 py-1">
              <MapPin className="h-4 w-4 text-muted-foreground mr-2" />
              <span className="text-sm">{userProfile.location || "New York Area"}</span>
            </div>
          </div>
          
          {isLoadingServices ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : services.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Search className="h-16 w-16 text-primary/20 mb-4" />
                <h3 className="text-xl font-medium mb-2">No services available</h3>
                <p className="text-muted-foreground mb-6 text-center max-w-md">
                  We couldn't find any pet services in your area. Try updating your location or check back later.
                </p>
                <Button variant="outline" asChild>
                  <Link href="/profile">Update Location</Link>
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {/* Services grid would go here */}
              <p className="text-muted-foreground text-center py-8 col-span-full">
                Pet services will appear here once providers are available in your area.
              </p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}