import { UserType } from "@shared/schema";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Building, User, Briefcase } from "lucide-react";

interface DashboardHeaderProps {
  title: string;
  subtitle: string;
  userType: UserType;
  name: string;
}

export default function DashboardHeader({ title, subtitle, userType, name }: DashboardHeaderProps) {
  // Get initials from name for avatar
  const initials = name
    .split(' ')
    .map(word => word[0])
    .join('')
    .toUpperCase()
    .substring(0, 2);
  
  // Get the right icon based on user type
  const getUserIcon = () => {
    switch (userType) {
      case UserType.PET_OWNER:
        return <User className="h-5 w-5 text-primary" />;
      case UserType.SERVICE_PROVIDER:
        return <Briefcase className="h-5 w-5 text-primary" />;
      case UserType.SHELTER:
        return <Building className="h-5 w-5 text-primary" />;
      default:
        return <User className="h-5 w-5 text-primary" />;
    }
  };
  
  // Get the appropriate role text
  const getRoleText = () => {
    switch (userType) {
      case UserType.PET_OWNER:
        return "Pet Owner";
      case UserType.SERVICE_PROVIDER:
        return "Service Provider";
      case UserType.SHELTER:
        return "Animal Shelter";
      default:
        return "User";
    }
  };
  
  return (
    <div className="mb-8">
      {/* Header content with user info */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold">{title}</h1>
          <p className="text-muted-foreground mt-1">{subtitle}</p>
        </div>
        
        <div className="flex items-center space-x-3 bg-primary/5 rounded-lg px-4 py-2">
          <Avatar className="h-10 w-10 border-2 border-primary/20">
            <AvatarFallback className="bg-primary/10 text-primary">
              {initials}
            </AvatarFallback>
          </Avatar>
          <div>
            <p className="font-medium">{name}</p>
            <div className="flex items-center text-sm text-muted-foreground">
              <span className="flex items-center gap-1">
                {getUserIcon()}
                <span>{getRoleText()}</span>
              </span>
            </div>
          </div>
        </div>
      </div>
      
      {/* Bottom border line */}
      <div className="h-1 w-full bg-gradient-to-r from-primary/30 to-primary/5 rounded-full mb-6"></div>
    </div>
  );
}