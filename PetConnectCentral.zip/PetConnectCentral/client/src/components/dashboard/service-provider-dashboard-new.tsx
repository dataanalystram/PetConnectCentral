import { useState, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";
import DashboardHeader from "./dashboard-header";
import { UserType } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Progress } from "@/components/ui/progress";
import {
  Calendar,
  CalendarIcon,
  Check,
  CheckCircle,
  ChevronRight,
  Clock,
  Clipboard,
  FileCheck,
  FileText,
  Image,
  Info,
  LineChart,
  MessageSquare,
  Pencil,
  Plus,
  RefreshCw,
  Settings,
  Shield,
  ShieldCheck,
  Star,
  Loader2,
  MapPin,
  XCircle,
  AlertCircle,
  User,
  DollarSign,
  CheckCircle2,
  CircleX,
  Clock3,
} from "lucide-react";

export default function ServiceProviderDashboard() {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");
  const [isServiceModalOpen, setIsServiceModalOpen] = useState(false);
  const [isSettingsModalOpen, setIsSettingsModalOpen] = useState(false);
  const [isReviewResponseModalOpen, setIsReviewResponseModalOpen] = useState(false);
  const [currentReviewId, setCurrentReviewId] = useState<number | null>(null);
  const [responseText, setResponseText] = useState("");
  const queryClient = useQueryClient();
  const [serviceFormData, setServiceFormData] = useState({
    title: "",
    description: "",
    category: "",
    price: "",
    duration: "",
    available: true
  });
  const [settingsFormData, setSettingsFormData] = useState({
    workHours: "",
    emailAlerts: true,
    smsAlerts: false
  });
  
  // If user is not authenticated, don't try to fetch provider ID
  const providerId = userProfile?.id || null;

  // Fetch provider's settings
  const { 
    data: settings = [], 
    isLoading: isLoadingSettings,
    refetch: refetchSettings
  } = useQuery({
    queryKey: [`/api/service-provider/${providerId}/settings`],
    enabled: !!providerId,
  });

  // Fetch services for this provider
  const { 
    data: services = [], 
    isLoading: isLoadingServices,
    refetch: refetchServices
  } = useQuery({
    queryKey: ["/api/services"],
    enabled: !!providerId,
  });

  // Filter services by provider ID
  const providerServices = services.filter((service: any) => 
    service.providerId === providerId
  );
  
  // Fetch provider's bookings/appointments
  const { 
    data: bookings = [], 
    isLoading: isLoadingBookings,
    refetch: refetchBookings
  } = useQuery({
    queryKey: [`/api/service-provider/${providerId}/bookings`],
    enabled: !!providerId,
  });
  
  // Fetch provider reviews
  const { 
    data: reviews = [], 
    isLoading: isLoadingReviews,
    refetch: refetchReviews
  } = useQuery({
    queryKey: [`/api/service-provider/${providerId}/reviews`],
    enabled: !!providerId,
  });
  
  // Filter bookings by status
  const pendingBookings = bookings.filter((booking: any) => 
    booking.status === "pending"
  );
  
  const confirmedBookings = bookings.filter((booking: any) => 
    booking.status === "confirmed"
  );
  
  const completedBookings = bookings.filter((booking: any) => 
    booking.status === "completed"
  );
  
  const cancelledBookings = bookings.filter((booking: any) => 
    booking.status === "cancelled"
  );

  // Calculate total revenue and other metrics
  const totalRevenue = completedBookings.reduce((sum: number, booking: any) => {
    const service = services.find((s: any) => s.id === booking.serviceId);
    return sum + (service?.price ? parseFloat(service.price) : 0);
  }, 0);
  
  const completionRate = bookings.length > 0 
    ? (completedBookings.length / bookings.length * 100).toFixed(0) 
    : "0";
  
  const averageRating = reviews.length > 0
    ? (reviews.reduce((sum: number, review: any) => sum + review.rating, 0) / reviews.length).toFixed(1)
    : "N/A";

  // Create a new service
  const createServiceMutation = useMutation({
    mutationFn: async (newService: any) => {
      return await apiRequest("POST", `/api/service-provider/${providerId}/services`, newService);
    },
    onSuccess: () => {
      toast({
        title: "Service created",
        description: "Your new service has been added successfully",
      });
      setIsServiceModalOpen(false);
      setServiceFormData({
        title: "",
        description: "",
        category: "",
        price: "",
        duration: "",
        available: true
      });
      // Refetch services list
      queryClient.invalidateQueries({ queryKey: ["/api/services"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create service. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Update booking status
  const updateBookingStatusMutation = useMutation({
    mutationFn: async ({ bookingId, status }: { bookingId: number, status: string }) => {
      return await apiRequest("PATCH", `/api/service-provider/${providerId}/bookings/${bookingId}`, { status });
    },
    onSuccess: () => {
      toast({
        title: "Booking updated",
        description: "The booking status has been updated successfully",
      });
      // Refetch bookings
      refetchBookings();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update booking status. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Update provider settings
  const updateSettingsMutation = useMutation({
    mutationFn: async (settings: any) => {
      return await apiRequest("POST", `/api/service-provider/${providerId}/settings`, settings);
    },
    onSuccess: () => {
      toast({
        title: "Settings updated",
        description: "Your settings have been saved successfully",
      });
      setIsSettingsModalOpen(false);
      // Refetch settings
      refetchSettings();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update settings. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Respond to review
  const respondToReviewMutation = useMutation({
    mutationFn: async ({ reviewId, responseText }: { reviewId: number, responseText: string }) => {
      return await apiRequest("PATCH", `/api/service-provider/${providerId}/reviews/${reviewId}`, { responseText });
    },
    onSuccess: () => {
      toast({
        title: "Response added",
        description: "Your response to the review has been saved",
      });
      setIsReviewResponseModalOpen(false);
      setResponseText("");
      setCurrentReviewId(null);
      // Refetch reviews
      refetchReviews();
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to respond to review. Please try again.",
        variant: "destructive",
      });
    }
  });

  // Handler for accepting a booking
  const handleUpdateBookingStatus = (bookingId: number, status: string) => {
    updateBookingStatusMutation.mutate({ bookingId, status });
  };

  // Handler for responding to a review
  const handleRespondToReview = (reviewId: number) => {
    setCurrentReviewId(reviewId);
    setResponseText("");
    setIsReviewResponseModalOpen(true);
  };

  // Handler for submitting review response
  const handleSubmitReviewResponse = () => {
    if (currentReviewId && responseText.trim()) {
      respondToReviewMutation.mutate({ reviewId: currentReviewId, responseText });
    }
  };

  // Handler for saving service provider settings
  const handleSaveSettings = () => {
    const settingsToSave = [
      { settingName: "workHours", settingValue: settingsFormData.workHours, settingCategory: "availability" },
      { settingName: "emailAlerts", settingValue: settingsFormData.emailAlerts.toString(), settingCategory: "notifications" },
      { settingName: "smsAlerts", settingValue: settingsFormData.smsAlerts.toString(), settingCategory: "notifications" }
    ];
    updateSettingsMutation.mutate(settingsToSave);
  };

  // Handler for creating a new service
  const handleCreateService = (e: React.FormEvent) => {
    e.preventDefault();
    createServiceMutation.mutate({
      title: serviceFormData.title,
      description: serviceFormData.description,
      category: serviceFormData.category,
      price: serviceFormData.price,
      duration: serviceFormData.duration,
      available: serviceFormData.available
    });
  };

  // Update settings form when settings data is loaded
  useEffect(() => {
    if (settings && settings.length > 0) {
      const workHoursSetting = settings.find((s: any) => s.settingName === "workHours");
      const emailAlertsSetting = settings.find((s: any) => s.settingName === "emailAlerts");
      const smsAlertsSetting = settings.find((s: any) => s.settingName === "smsAlerts");

      setSettingsFormData({
        workHours: workHoursSetting?.settingValue || "9:00-17:00",
        emailAlerts: emailAlertsSetting?.settingValue === "true",
        smsAlerts: smsAlertsSetting?.settingValue === "true"
      });
    }
  }, [settings]);
  
  if (!userProfile) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <DashboardHeader
        title="Service Provider Dashboard"
        subtitle="Manage your services, bookings, and reviews"
        userType={UserType.SERVICE_PROVIDER}
        name={userProfile.name}
      />
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:w-auto bg-primary/5 text-primary">
          <TabsTrigger value="overview" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Clipboard className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Overview</span>
            <span className="sm:hidden">Home</span>
          </TabsTrigger>
          <TabsTrigger value="bookings" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Calendar className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Bookings</span>
            <span className="sm:hidden">Book</span>
          </TabsTrigger>
          <TabsTrigger value="services" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <FileText className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Services</span>
            <span className="sm:hidden">Serv</span>
          </TabsTrigger>
          <TabsTrigger value="reviews" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Star className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Reviews</span>
            <span className="sm:hidden">Rev</span>
          </TabsTrigger>
          <TabsTrigger value="compliance" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <ShieldCheck className="h-4 w-4 mr-2" />
            <span className="hidden sm:inline">Compliance</span>
            <span className="sm:hidden">Comp</span>
          </TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          {/* Performance Metrics */}
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Total Bookings</p>
                    <h3 className="text-2xl font-bold mt-1">{bookings.length}</h3>
                  </div>
                  <div className="bg-primary/10 p-2 rounded-full">
                    <Calendar className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-xs text-muted-foreground">
                  <div className="flex items-center text-green-500 mr-3">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    <span>{completedBookings.length} completed</span>
                  </div>
                  <div className="flex items-center text-red-500">
                    <XCircle className="h-3 w-3 mr-1" />
                    <span>{cancelledBookings.length} cancelled</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Revenue</p>
                    <h3 className="text-2xl font-bold mt-1">€{totalRevenue.toFixed(2)}</h3>
                  </div>
                  <div className="bg-primary/10 p-2 rounded-full">
                    <DollarSign className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-xs text-muted-foreground">
                  <div className="flex items-center text-green-500">
                    <span>From {completedBookings.length} completed bookings</span>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Completion Rate</p>
                    <h3 className="text-2xl font-bold mt-1">{completionRate}%</h3>
                  </div>
                  <div className="bg-primary/10 p-2 rounded-full">
                    <CheckCircle2 className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <div className="mt-2">
                  <Progress value={parseInt(completionRate)} className="h-2" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Average Rating</p>
                    <h3 className="text-2xl font-bold mt-1 flex items-center">
                      {averageRating} 
                      <Star className="h-4 w-4 text-yellow-400 ml-1 fill-yellow-400" />
                    </h3>
                  </div>
                  <div className="bg-primary/10 p-2 rounded-full">
                    <Star className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <div className="mt-4 flex items-center text-xs text-muted-foreground">
                  <span>Based on {reviews.length} reviews</span>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {/* Pending Bookings Card */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-medium">Pending Bookings</CardTitle>
                <CardDescription>Bookings requiring your confirmation</CardDescription>
              </CardHeader>
              <CardContent className="pt-0 max-h-[300px] overflow-y-auto">
                {isLoadingBookings ? (
                  <div className="flex justify-center py-6">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : pendingBookings.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    <p>No pending bookings</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pendingBookings.map((booking: any) => (
                      <div key={booking.id} className="flex items-start space-x-3 border-b border-border pb-3 last:border-0">
                        <div className="bg-primary/10 rounded-md p-2">
                          <Calendar className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{booking.service?.title}</p>
                          <div className="flex items-center text-sm text-muted-foreground mt-1">
                            <Clock className="h-3 w-3 mr-1" />
                            <span>{new Date(booking.bookingDate).toLocaleDateString()}</span>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">
                            <User className="h-3 w-3 mr-1 inline" />
                            {booking.userName} 
                            <span className="mx-1">•</span>
                            {booking.pet?.type} - {booking.pet?.name}
                          </p>
                          <div className="flex space-x-2 mt-2">
                            <Button 
                              size="sm" 
                              onClick={() => handleUpdateBookingStatus(booking.id, "confirmed")}
                              className="h-8"
                            >
                              Accept
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={() => handleUpdateBookingStatus(booking.id, "cancelled")}
                              className="h-8"
                            >
                              Decline
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => setActiveTab("bookings")}>
                  View All Bookings
                </Button>
              </CardFooter>
            </Card>
            
            {/* Upcoming Bookings Card */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-medium">Upcoming Bookings</CardTitle>
                <CardDescription>Your confirmed schedule</CardDescription>
              </CardHeader>
              <CardContent className="pt-0 max-h-[300px] overflow-y-auto">
                {isLoadingBookings ? (
                  <div className="flex justify-center py-6">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : confirmedBookings.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    <p>No upcoming bookings</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {confirmedBookings.map((booking: any) => (
                      <div key={booking.id} className="flex items-start space-x-3 border-b border-border pb-3 last:border-0">
                        <div className="bg-primary/10 rounded-md p-2">
                          <Calendar className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{booking.service?.title}</p>
                          <div className="flex items-center text-sm text-muted-foreground mt-1">
                            <Clock className="h-3 w-3 mr-1" />
                            <span>{new Date(booking.bookingDate).toLocaleDateString()}</span>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1">
                            <User className="h-3 w-3 mr-1 inline" />
                            {booking.userName} 
                            <span className="mx-1">•</span>
                            {booking.pet?.type} - {booking.pet?.name}
                          </p>
                          <div className="flex space-x-2 mt-2">
                            <Button 
                              size="sm" 
                              onClick={() => handleUpdateBookingStatus(booking.id, "completed")}
                              className="h-8"
                            >
                              Complete
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={() => handleUpdateBookingStatus(booking.id, "cancelled")}
                              className="h-8"
                            >
                              Cancel
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => setActiveTab("bookings")}>
                  View Calendar
                </Button>
              </CardFooter>
            </Card>
            
            {/* Services Card */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-medium">Your Services</CardTitle>
                <CardDescription>Services you offer</CardDescription>
              </CardHeader>
              <CardContent className="pt-0 max-h-[300px] overflow-y-auto">
                {isLoadingServices ? (
                  <div className="flex justify-center py-6">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : providerServices.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    <p>No services listed yet</p>
                    <Button variant="link" onClick={() => setActiveTab("services")}>
                      Add a service
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {providerServices.map((service: any) => (
                      <div key={service.id} className="flex items-start space-x-3 border-b border-border pb-3 last:border-0">
                        <div className="bg-primary/10 rounded-md p-2">
                          <FileText className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{service.title}</p>
                          <div className="flex items-center text-sm text-muted-foreground mt-1">
                            <span>€{service.price} • {service.duration} min</span>
                          </div>
                          <p className="text-sm text-muted-foreground mt-1 line-clamp-1">
                            {service.description || 'No description'}
                          </p>
                          <Button variant="link" className="h-auto p-0 text-sm mt-1" onClick={() => setActiveTab("services")}>
                            Edit Service
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button onClick={() => { setIsServiceModalOpen(true) }} className="w-full">
                  <Plus className="h-4 w-4 mr-2" />
                  Add New Service
                </Button>
              </CardFooter>
            </Card>

            {/* Recent Reviews */}
            <Card className="md:col-span-2 lg:col-span-3">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="text-lg font-medium">Recent Reviews</CardTitle>
                    <CardDescription>Latest feedback from your clients</CardDescription>
                  </div>
                  <Button 
                    variant="outline" 
                    onClick={() => setActiveTab("reviews")} 
                    className="hidden sm:flex"
                  >
                    <Star className="h-4 w-4 mr-2" />
                    View All Reviews
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                {isLoadingReviews ? (
                  <div className="flex justify-center py-6">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : reviews.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    <Star className="h-12 w-12 mx-auto text-primary/20 mb-3" />
                    <p>No reviews yet</p>
                    <p className="text-sm mt-1">Reviews will appear here as clients rate your services</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {reviews.slice(0, 3).map((review: any) => (
                      <div key={review.id} className="p-4 border rounded-lg">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h4 className="font-medium">{review.serviceName}</h4>
                            <p className="text-sm text-muted-foreground">
                              {review.userName} • {new Date(review.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                          <div className="flex items-center bg-primary/10 text-primary font-medium rounded-full px-2 py-0.5">
                            <Star className="h-3 w-3 mr-1 fill-primary" />
                            <span>{review.rating}</span>
                          </div>
                        </div>
                        <p className="text-sm mb-3">{review.reviewText}</p>
                        
                        {review.responseText ? (
                          <div className="bg-muted/50 p-3 rounded-md mt-2">
                            <p className="text-xs font-medium">Your Response:</p>
                            <p className="text-sm mt-1">{review.responseText}</p>
                          </div>
                        ) : (
                          <Button 
                            variant="outline" 
                            size="sm" 
                            onClick={() => handleRespondToReview(review.id)}
                          >
                            <MessageSquare className="h-3 w-3 mr-1" /> 
                            Respond
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
              <CardFooter className="sm:hidden">
                <Button variant="outline" className="w-full" onClick={() => setActiveTab("reviews")}>
                  View All Reviews
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        {/* Bookings Tab */}
        <TabsContent value="bookings" className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h2 className="text-xl font-semibold">Manage Bookings</h2>
              <p className="text-muted-foreground">View and manage all your client bookings</p>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" onClick={() => refetchBookings()}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              <Button variant="outline" onClick={() => setIsSettingsModalOpen(true)}>
                <Settings className="h-4 w-4 mr-2" />
                Availability Settings
              </Button>
            </div>
          </div>

          <Tabs defaultValue="all" className="w-full">
            <TabsList className="grid grid-cols-5 mb-4">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="pending">
                Pending
                <Badge variant="outline" className="ml-2">{pendingBookings.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="confirmed">
                Confirmed
                <Badge variant="outline" className="ml-2">{confirmedBookings.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="completed">
                Completed
                <Badge variant="outline" className="ml-2">{completedBookings.length}</Badge>
              </TabsTrigger>
              <TabsTrigger value="cancelled">
                Cancelled
                <Badge variant="outline" className="ml-2">{cancelledBookings.length}</Badge>
              </TabsTrigger>
            </TabsList>
            
            {isLoadingBookings ? (
              <div className="flex justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : bookings.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <Calendar className="h-16 w-16 text-primary/20 mb-4" />
                  <h3 className="text-xl font-medium mb-2">No bookings yet</h3>
                  <p className="text-muted-foreground mb-6 text-center max-w-md">
                    You don't have any bookings yet. They will appear here once clients book your services.
                  </p>
                </CardContent>
              </Card>
            ) : (
              <>
                <TabsContent value="all">
                  <BookingsTable 
                    bookings={bookings} 
                    handleUpdateBookingStatus={handleUpdateBookingStatus}
                  />
                </TabsContent>
                <TabsContent value="pending">
                  <BookingsTable 
                    bookings={pendingBookings} 
                    handleUpdateBookingStatus={handleUpdateBookingStatus}
                  />
                </TabsContent>
                <TabsContent value="confirmed">
                  <BookingsTable 
                    bookings={confirmedBookings} 
                    handleUpdateBookingStatus={handleUpdateBookingStatus}
                  />
                </TabsContent>
                <TabsContent value="completed">
                  <BookingsTable 
                    bookings={completedBookings} 
                    handleUpdateBookingStatus={handleUpdateBookingStatus}
                    isCompleted
                  />
                </TabsContent>
                <TabsContent value="cancelled">
                  <BookingsTable 
                    bookings={cancelledBookings} 
                    handleUpdateBookingStatus={handleUpdateBookingStatus}
                    isCancelled
                  />
                </TabsContent>
              </>
            )}
          </Tabs>
        </TabsContent>
        
        {/* Services Tab */}
        <TabsContent value="services" className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h2 className="text-xl font-semibold">Your Services</h2>
              <p className="text-muted-foreground">Manage the services you offer to clients</p>
            </div>
            <Button onClick={() => setIsServiceModalOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Add New Service
            </Button>
          </div>
          
          {isLoadingServices ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : providerServices.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <FileText className="h-16 w-16 text-primary/20 mb-4" />
                <h3 className="text-xl font-medium mb-2">No services listed</h3>
                <p className="text-muted-foreground mb-6 text-center max-w-md">
                  You haven't added any services yet. Add services to let pet owners know what you offer.
                </p>
                <Button onClick={() => setIsServiceModalOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Your First Service
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {providerServices.map((service: any) => (
                <Card key={service.id} className="overflow-hidden">
                  <CardHeader className="pb-2 relative">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg font-medium">{service.title}</CardTitle>
                      <div className="bg-primary/10 text-primary font-medium rounded-full px-2 py-0.5 text-xs">
                        €{service.price}
                      </div>
                    </div>
                    <CardDescription>{service.category || 'General'}</CardDescription>
                    
                    <div className="absolute top-2 right-2">
                      <Badge variant={service.available ? "default" : "secondary"}>
                        {service.available ? "Available" : "Unavailable"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center text-sm text-muted-foreground mb-2">
                      <Clock className="h-3.5 w-3.5 mr-1" />
                      <span>{service.duration} minutes</span>
                    </div>
                    <p className="text-sm mt-2 line-clamp-3">{service.description || 'No description provided'}</p>
                  </CardContent>
                  <CardFooter className="bg-muted/20 pt-3 flex justify-between">
                    <Button variant="outline" size="sm">
                      <Pencil className="h-3.5 w-3.5 mr-1" />
                      Edit
                    </Button>
                    <div className="flex gap-2">
                      <Button variant="ghost" size="sm" className="text-red-500 hover:text-red-600 hover:bg-red-50">
                        Delete
                      </Button>
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        className={service.available ? "text-amber-500" : "text-green-500"}
                      >
                        {service.available ? "Disable" : "Enable"}
                      </Button>
                    </div>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        {/* Reviews Tab */}
        <TabsContent value="reviews" className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h2 className="text-xl font-semibold">Client Reviews</h2>
              <p className="text-muted-foreground">Manage and respond to all your client reviews</p>
            </div>
            <div className="flex items-center gap-2 bg-primary/10 text-primary font-medium rounded-full px-3 py-1.5">
              <Star className="h-4 w-4 fill-primary" />
              <span>Rating: {reviews.length > 0 ? (reviews.reduce((sum: number, review: any) => sum + review.rating, 0) / reviews.length).toFixed(1) : 'N/A'}</span>
              <span className="text-xs text-muted-foreground">({reviews.length} reviews)</span>
            </div>
          </div>
          
          {isLoadingReviews ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : reviews.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Star className="h-16 w-16 text-primary/20 mb-4" />
                <h3 className="text-xl font-medium mb-2">No reviews yet</h3>
                <p className="text-muted-foreground mb-6 text-center max-w-md">
                  You haven't received any client reviews yet. They will appear here once clients rate your services.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {reviews.map((review: any) => (
                <Card key={review.id}>
                  <CardHeader className="pb-2">
                    <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
                      <div>
                        <CardTitle className="text-lg font-medium flex items-center">
                          {review.serviceName}
                          <Badge className="ml-2" variant={
                            review.rating >= 4 ? "default" : 
                            review.rating >= 3 ? "outline" : "destructive"
                          }>
                            {review.rating} <Star className="h-3 w-3 ml-0.5 fill-current" />
                          </Badge>
                        </CardTitle>
                        <CardDescription className="flex items-center">
                          <User className="h-3 w-3 mr-1" />
                          {review.userName} • {new Date(review.createdAt).toLocaleDateString()}
                        </CardDescription>
                      </div>
                      <div className="flex items-center text-xs text-muted-foreground">
                        <Calendar className="h-3 w-3 mr-1" />
                        <span>Service date: {new Date(review.bookingDate).toLocaleDateString()}</span>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm">{review.reviewText}</p>
                    {review.responseText && (
                      <div className="mt-4 pt-4 border-t border-border bg-muted/30 p-3 rounded-md">
                        <p className="text-sm font-medium flex items-center">
                          <MessageSquare className="h-4 w-4 mr-1 text-primary" />
                          Your Response:
                          <span className="text-xs text-muted-foreground ml-2">
                            {review.responseDate ? new Date(review.responseDate).toLocaleDateString() : ''}
                          </span>
                        </p>
                        <p className="text-sm mt-1">{review.responseText}</p>
                      </div>
                    )}
                  </CardContent>
                  {!review.responseText && (
                    <CardFooter className="pt-0 flex justify-end">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        onClick={() => handleRespondToReview(review.id)}
                      >
                        <MessageSquare className="h-3.5 w-3.5 mr-1" />
                        Respond to Review
                      </Button>
                    </CardFooter>
                  )}
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        {/* Compliance Tab */}
        <TabsContent value="compliance" className="space-y-6">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <h2 className="text-xl font-semibold">Compliance Center</h2>
              <p className="text-muted-foreground">Ensure your compliance with EU regulations</p>
            </div>
            <Button variant="outline">
              <ShieldCheck className="h-4 w-4 mr-2" />
              Verify Documents
            </Button>
          </div>
          
          <div className="grid gap-6 md:grid-cols-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <Shield className="h-5 w-5 mr-2 text-primary" />
                  Compliance Status
                </CardTitle>
                <CardDescription>Summary of your regulatory compliance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between pb-2 border-b">
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
                      <span>Data Protection (GDPR)</span>
                    </div>
                    <Badge>Compliant</Badge>
                  </div>
                  <div className="flex items-center justify-between pb-2 border-b">
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
                      <span>Animal Welfare Standards</span>
                    </div>
                    <Badge>Compliant</Badge>
                  </div>
                  <div className="flex items-center justify-between pb-2 border-b">
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 mr-2 text-green-500" />
                      <span>Business Registration</span>
                    </div>
                    <Badge>Verified</Badge>
                  </div>
                  <div className="flex items-center justify-between pb-2 border-b">
                    <div className="flex items-center">
                      <AlertCircle className="h-5 w-5 mr-2 text-amber-500" />
                      <span>Tax Documentation</span>
                    </div>
                    <Badge variant="outline">Pending</Badge>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  <FileCheck className="h-4 w-4 mr-2" />
                  Complete Verification
                </Button>
              </CardFooter>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <FileText className="h-5 w-5 mr-2 text-primary" />
                  Regulatory Updates
                </CardTitle>
                <CardDescription>Recent changes in regulations affecting your business</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-start space-x-3 pb-3 border-b">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <Info className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">EU Pet Transportation Guidelines</h4>
                      <p className="text-xs text-muted-foreground mt-1">Effective: June 15, 2025</p>
                      <p className="text-sm mt-2">New guidelines for safe pet transportation services requiring additional documentation and safety measures.</p>
                      <Button variant="link" className="p-0 h-auto text-primary text-sm mt-1">
                        Read More <ChevronRight className="h-3 w-3 ml-1" />
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-start space-x-3">
                    <div className="bg-primary/10 p-2 rounded-full mt-1">
                      <Info className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-medium">Updated Data Processing Requirements</h4>
                      <p className="text-xs text-muted-foreground mt-1">Effective: May 25, 2025</p>
                      <p className="text-sm mt-2">Enhanced GDPR requirements for processing pet health data and owner information.</p>
                      <Button variant="link" className="p-0 h-auto text-primary text-sm mt-1">
                        Read More <ChevronRight className="h-3 w-3 ml-1" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  View All Updates
                </Button>
              </CardFooter>
            </Card>
            
            <Card className="md:col-span-2">
              <CardHeader>
                <CardTitle className="flex items-center text-lg">
                  <FileCheck className="h-5 w-5 mr-2 text-primary" />
                  Required Documents
                </CardTitle>
                <CardDescription>Documents you need to provide for regulatory compliance</CardDescription>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="item-1">
                    <AccordionTrigger>
                      <div className="flex items-center">
                        <FileText className="h-4 w-4 mr-2 text-primary" />
                        <span>Business Documentation</span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2 pt-2">
                        <div className="flex justify-between items-center p-2 rounded-md bg-muted/50">
                          <div className="flex items-center">
                            <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                            <span>Business Registration Certificate</span>
                          </div>
                          <Badge variant="outline" className="bg-green-50">Verified</Badge>
                        </div>
                        <div className="flex justify-between items-center p-2 rounded-md bg-muted/50">
                          <div className="flex items-center">
                            <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                            <span>Tax Identification Number</span>
                          </div>
                          <Badge variant="outline" className="bg-green-50">Verified</Badge>
                        </div>
                        <div className="flex justify-between items-center p-2 rounded-md bg-muted/50">
                          <div className="flex items-center">
                            <AlertCircle className="h-4 w-4 mr-2 text-amber-500" />
                            <span>Service Liability Insurance</span>
                          </div>
                          <Badge variant="outline">Pending</Badge>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-2">
                    <AccordionTrigger>
                      <div className="flex items-center">
                        <FileText className="h-4 w-4 mr-2 text-primary" />
                        <span>Professional Qualifications</span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2 pt-2">
                        <div className="flex justify-between items-center p-2 rounded-md bg-muted/50">
                          <div className="flex items-center">
                            <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                            <span>Professional Certification</span>
                          </div>
                          <Badge variant="outline" className="bg-green-50">Verified</Badge>
                        </div>
                        <div className="flex justify-between items-center p-2 rounded-md bg-muted/50">
                          <div className="flex items-center">
                            <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                            <span>Regulatory Training Certification</span>
                          </div>
                          <Badge variant="outline" className="bg-green-50">Verified</Badge>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                  <AccordionItem value="item-3">
                    <AccordionTrigger>
                      <div className="flex items-center">
                        <FileText className="h-4 w-4 mr-2 text-primary" />
                        <span>Data Protection Documentation</span>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-2 pt-2">
                        <div className="flex justify-between items-center p-2 rounded-md bg-muted/50">
                          <div className="flex items-center">
                            <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                            <span>Privacy Policy</span>
                          </div>
                          <Badge variant="outline" className="bg-green-50">Verified</Badge>
                        </div>
                        <div className="flex justify-between items-center p-2 rounded-md bg-muted/50">
                          <div className="flex items-center">
                            <CheckCircle className="h-4 w-4 mr-2 text-green-500" />
                            <span>Data Processing Records</span>
                          </div>
                          <Badge variant="outline" className="bg-green-50">Verified</Badge>
                        </div>
                        <div className="flex justify-between items-center p-2 rounded-md bg-muted/50">
                          <div className="flex items-center">
                            <AlertCircle className="h-4 w-4 mr-2 text-amber-500" />
                            <span>Annual GDPR Audit</span>
                          </div>
                          <Badge variant="outline">Due in 60 days</Badge>
                        </div>
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      
      {/* Add Service Modal */}
      <Dialog open={isServiceModalOpen} onOpenChange={setIsServiceModalOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Add New Service</DialogTitle>
            <DialogDescription>
              Create a new service to offer to your clients.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleCreateService}>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <label htmlFor="title" className="text-right text-sm font-medium">
                  Title
                </label>
                <Input
                  id="title"
                  value={serviceFormData.title}
                  onChange={(e) => setServiceFormData({...serviceFormData, title: e.target.value})}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <label htmlFor="category" className="text-right text-sm font-medium">
                  Category
                </label>
                <Select 
                  value={serviceFormData.category} 
                  onValueChange={(value) => setServiceFormData({...serviceFormData, category: value})}
                >
                  <SelectTrigger className="col-span-3">
                    <SelectValue placeholder="Select a category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="grooming">Pet Grooming</SelectItem>
                    <SelectItem value="walking">Dog Walking</SelectItem>
                    <SelectItem value="sitting">Pet Sitting</SelectItem>
                    <SelectItem value="training">Pet Training</SelectItem>
                    <SelectItem value="veterinary">Veterinary Care</SelectItem>
                    <SelectItem value="boarding">Boarding</SelectItem>
                    <SelectItem value="daycare">Daycare</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <label htmlFor="price" className="text-right text-sm font-medium">
                  Price (€)
                </label>
                <Input
                  id="price"
                  type="number"
                  min="0"
                  step="0.01"
                  value={serviceFormData.price}
                  onChange={(e) => setServiceFormData({...serviceFormData, price: e.target.value})}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <label htmlFor="duration" className="text-right text-sm font-medium">
                  Duration (min)
                </label>
                <Input
                  id="duration"
                  type="number"
                  min="15"
                  step="15"
                  value={serviceFormData.duration}
                  onChange={(e) => setServiceFormData({...serviceFormData, duration: e.target.value})}
                  className="col-span-3"
                  required
                />
              </div>
              <div className="grid grid-cols-4 items-start gap-4">
                <label htmlFor="description" className="text-right text-sm font-medium pt-2">
                  Description
                </label>
                <Textarea
                  id="description"
                  value={serviceFormData.description}
                  onChange={(e) => setServiceFormData({...serviceFormData, description: e.target.value})}
                  className="col-span-3"
                  rows={4}
                />
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="outline" onClick={() => setIsServiceModalOpen(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={createServiceMutation.isPending}>
                {createServiceMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Add Service
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Provider Settings Modal */}
      <Dialog open={isSettingsModalOpen} onOpenChange={setIsSettingsModalOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Provider Settings</DialogTitle>
            <DialogDescription>
              Configure your availability and notification preferences.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="workHours" className="text-right text-sm font-medium">
                Work Hours
              </label>
              <Input
                id="workHours"
                placeholder="e.g. 9:00-17:00"
                value={settingsFormData.workHours}
                onChange={(e) => setSettingsFormData({...settingsFormData, workHours: e.target.value})}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label className="text-right text-sm font-medium">
                Email Alerts
              </label>
              <div className="flex items-center space-x-2 col-span-3">
                <input
                  type="checkbox"
                  id="emailAlerts"
                  checked={settingsFormData.emailAlerts}
                  onChange={(e) => setSettingsFormData({...settingsFormData, emailAlerts: e.target.checked})}
                  className="h-4 w-4 rounded border-gray-300"
                />
                <label htmlFor="emailAlerts" className="text-sm">
                  Receive booking notifications via email
                </label>
              </div>
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <label className="text-right text-sm font-medium">
                SMS Alerts
              </label>
              <div className="flex items-center space-x-2 col-span-3">
                <input
                  type="checkbox"
                  id="smsAlerts"
                  checked={settingsFormData.smsAlerts}
                  onChange={(e) => setSettingsFormData({...settingsFormData, smsAlerts: e.target.checked})}
                  className="h-4 w-4 rounded border-gray-300"
                />
                <label htmlFor="smsAlerts" className="text-sm">
                  Receive booking notifications via SMS
                </label>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsSettingsModalOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveSettings} disabled={updateSettingsMutation.isPending}>
              {updateSettingsMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Save Settings
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Review Response Modal */}
      <Dialog open={isReviewResponseModalOpen} onOpenChange={setIsReviewResponseModalOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Respond to Review</DialogTitle>
            <DialogDescription>
              Add your response to the client's review. This will be publicly visible.
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <label htmlFor="responseText" className="text-sm font-medium">
              Your Response
            </label>
            <Textarea
              id="responseText"
              value={responseText}
              onChange={(e) => setResponseText(e.target.value)}
              className="mt-2"
              rows={4}
              placeholder="Thank you for your feedback..."
            />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsReviewResponseModalOpen(false)}>
              Cancel
            </Button>
            <Button 
              onClick={handleSubmitReviewResponse} 
              disabled={!responseText.trim() || respondToReviewMutation.isPending}
            >
              {respondToReviewMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Submit Response
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// BookingsTable component for displaying bookings in a table format
function BookingsTable({ 
  bookings, 
  handleUpdateBookingStatus, 
  isCompleted = false, 
  isCancelled = false 
}: { 
  bookings: any[], 
  handleUpdateBookingStatus: (bookingId: number, status: string) => void,
  isCompleted?: boolean,
  isCancelled?: boolean
}) {
  return (
    <Table>
      <TableCaption>Your service bookings</TableCaption>
      <TableHeader>
        <TableRow>
          <TableHead>Booking Date</TableHead>
          <TableHead>Service</TableHead>
          <TableHead>Pet</TableHead>
          <TableHead>Client</TableHead>
          <TableHead>Status</TableHead>
          <TableHead className="text-right">Actions</TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {bookings.length === 0 ? (
          <TableRow>
            <TableCell colSpan={6} className="text-center py-6 text-muted-foreground">
              No bookings found
            </TableCell>
          </TableRow>
        ) : (
          bookings.map((booking) => (
            <TableRow key={booking.id}>
              <TableCell>
                <div className="font-medium">{new Date(booking.bookingDate).toLocaleDateString()}</div>
              </TableCell>
              <TableCell>{booking.service?.title || booking.serviceId}</TableCell>
              <TableCell>
                <div className="flex items-center gap-1">
                  {booking.pet?.name}
                  <span className="text-xs text-muted-foreground">({booking.pet?.type})</span>
                </div>
              </TableCell>
              <TableCell>{booking.userName}</TableCell>
              <TableCell>
                <StatusBadge status={booking.status} />
              </TableCell>
              <TableCell className="text-right">
                <div className="flex justify-end gap-2">
                  {booking.status === "pending" && (
                    <>
                      <Button 
                        size="sm" 
                        onClick={() => handleUpdateBookingStatus(booking.id, "confirmed")}
                      >
                        Accept
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => handleUpdateBookingStatus(booking.id, "cancelled")}
                      >
                        Decline
                      </Button>
                    </>
                  )}
                  {booking.status === "confirmed" && (
                    <>
                      <Button 
                        size="sm" 
                        onClick={() => handleUpdateBookingStatus(booking.id, "completed")}
                      >
                        Complete
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => handleUpdateBookingStatus(booking.id, "cancelled")}
                      >
                        Cancel
                      </Button>
                    </>
                  )}
                  {(isCompleted || isCancelled) && (
                    <Button size="sm" variant="outline">
                      <MessageSquare className="h-3.5 w-3.5 mr-1" />
                      Notes
                    </Button>
                  )}
                </div>
              </TableCell>
            </TableRow>
          ))
        )}
      </TableBody>
    </Table>
  );
}

// Status badge component for displaying booking status
function StatusBadge({ status }: { status: string }) {
  const getStatusDetails = (status: string) => {
    switch (status) {
      case "pending":
        return { variant: "outline", icon: <Clock3 className="h-3.5 w-3.5 mr-1" />, text: "Pending" };
      case "confirmed":
        return { variant: "default", icon: <CheckCircle2 className="h-3.5 w-3.5 mr-1" />, text: "Confirmed" };
      case "completed":
        return { variant: "success", icon: <Check className="h-3.5 w-3.5 mr-1" />, text: "Completed" };
      case "cancelled":
        return { variant: "destructive", icon: <CircleX className="h-3.5 w-3.5 mr-1" />, text: "Cancelled" };
      default:
        return { variant: "outline", icon: null, text: status };
    }
  };

  const { variant, icon, text } = getStatusDetails(status);
  
  // Override the variant since Badge doesn't have success variant by default
  const getVariantClass = () => {
    if (variant === "success") {
      return "bg-green-100 text-green-800 hover:bg-green-100/80";
    }
    return "";
  };

  return (
    <Badge 
      variant={variant === "success" ? "outline" : (variant as any)} 
      className={`flex items-center ${getVariantClass()}`}
    >
      {icon}
      {text}
    </Badge>
  );
}