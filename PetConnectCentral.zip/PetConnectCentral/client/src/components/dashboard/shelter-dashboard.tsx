import { useState } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";
import DashboardHeader from "./dashboard-header";
import { UserType } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import {
  Calendar,
  Clock,
  ClipboardList,
  Users,
  Plus,
  Check,
  X,
  FileText,
  Loader2,
  Home,
} from "lucide-react";
import { PawPrint as Paw } from "lucide-react";

export default function ShelterDashboard() {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");
  
  // Fetch shelter's pets
  const { 
    data: pets = [], 
    isLoading: isLoadingPets 
  } = useQuery({
    queryKey: ["/api/pets/shelter"],
    enabled: !!userProfile,
  });
  
  // Fetch shelter's adoption applications
  const { 
    data: applications = [], 
    isLoading: isLoadingApplications 
  } = useQuery({
    queryKey: ["/api/applications/shelter"],
    enabled: !!userProfile,
  });
  
  // Fetch shelter appointment requests
  const { 
    data: appointments = [], 
    isLoading: isLoadingAppointments 
  } = useQuery({
    queryKey: ["/api/appointments/shelter"],
    enabled: !!userProfile,
  });
  
  // Filter pending applications
  const pendingApplications = applications.filter((apt: any) => 
    apt.status === "pending"
  );
  
  // Filter upcoming appointments
  const upcomingAppointments = appointments.filter((apt: any) => 
    apt.status === "confirmed" && new Date(apt.dateTime) > new Date()
  );
  
  // Handler for accepting an application
  const handleAcceptApplication = async (applicationId: number) => {
    try {
      await apiRequest("PATCH", `/api/applications/${applicationId}`, {
        status: "approved",
      });
      toast({
        title: "Application approved",
        description: "The adoption application has been approved",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to approve the application",
        variant: "destructive",
      });
    }
  };
  
  // Handler for rejecting an application
  const handleRejectApplication = async (applicationId: number) => {
    try {
      await apiRequest("PATCH", `/api/applications/${applicationId}`, {
        status: "rejected",
      });
      toast({
        title: "Application rejected",
        description: "The adoption application has been rejected",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to reject the application",
        variant: "destructive",
      });
    }
  };
  
  if (!userProfile) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <DashboardHeader
        title="Shelter Dashboard"
        subtitle="Manage your pets, applications, and appointments"
        userType={UserType.SHELTER}
        name={userProfile.name}
      />
      
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid grid-cols-3 md:grid-cols-4 lg:w-auto bg-primary/5 text-primary">
          <TabsTrigger value="overview" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Home className="h-4 w-4 mr-2" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="pets" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Paw className="h-4 w-4 mr-2" />
            Pets
          </TabsTrigger>
          <TabsTrigger value="applications" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <ClipboardList className="h-4 w-4 mr-2" />
            Applications
          </TabsTrigger>
          <TabsTrigger value="appointments" className="data-[state=active]:bg-primary data-[state=active]:text-white">
            <Calendar className="h-4 w-4 mr-2" />
            Appointments
          </TabsTrigger>
        </TabsList>
        
        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {/* Pets Card */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-medium">Available Pets</CardTitle>
                <CardDescription>Pets ready for adoption</CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                {isLoadingPets ? (
                  <div className="flex justify-center py-6">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : pets.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    <p>No pets listed yet</p>
                    <Button variant="link" onClick={() => setActiveTab("pets")}>
                      Add a pet
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pets.slice(0, 3).map((pet: any) => (
                      <div key={pet.id} className="flex items-start space-x-3 border-b border-border pb-3 last:border-0">
                        <div className="relative w-14 h-14 rounded-md overflow-hidden bg-primary/10">
                          {pet.mainImageUrl ? (
                            <img 
                              src={pet.mainImageUrl} 
                              alt={pet.name} 
                              className="w-full h-full object-cover"
                            />
                          ) : (
                            <div className="flex items-center justify-center h-full">
                              <Paw className="h-6 w-6 text-primary" />
                            </div>
                          )}
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{pet.name}</p>
                          <div className="flex items-center text-sm text-muted-foreground mt-1">
                            <span>{pet.breed}, {pet.age} years</span>
                          </div>
                          <Button variant="link" className="h-auto p-0 text-sm mt-1" onClick={() => setActiveTab("pets")}>
                            View Details
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => setActiveTab("pets")}>
                  Manage Pets
                </Button>
              </CardFooter>
            </Card>
            
            {/* Pending Applications Card */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-medium">Pending Applications</CardTitle>
                <CardDescription>Applications requiring review</CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                {isLoadingApplications ? (
                  <div className="flex justify-center py-6">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : pendingApplications.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    <p>No pending applications</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {pendingApplications.map((application: any) => (
                      <div key={application.id} className="flex items-start space-x-3 border-b border-border pb-3 last:border-0">
                        <div className="bg-primary/10 rounded-md p-2">
                          <ClipboardList className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{application.applicantName}</p>
                          <div className="flex items-center text-sm text-muted-foreground mt-1">
                            <span>For: {application.petName}</span>
                          </div>
                          <div className="flex space-x-2 mt-2">
                            <Button 
                              size="sm" 
                              onClick={() => handleAcceptApplication(application.id)}
                              className="h-8"
                            >
                              <Check className="h-3 w-3 mr-1" />
                              Accept
                            </Button>
                            <Button 
                              size="sm" 
                              variant="outline" 
                              onClick={() => handleRejectApplication(application.id)}
                              className="h-8"
                            >
                              <X className="h-3 w-3 mr-1" />
                              Reject
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => setActiveTab("applications")}>
                  View All Applications
                </Button>
              </CardFooter>
            </Card>
            
            {/* Upcoming Visits Card */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg font-medium">Upcoming Visits</CardTitle>
                <CardDescription>Scheduled appointments</CardDescription>
              </CardHeader>
              <CardContent className="pt-0">
                {isLoadingAppointments ? (
                  <div className="flex justify-center py-6">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : upcomingAppointments.length === 0 ? (
                  <div className="text-center py-6 text-muted-foreground">
                    <p>No upcoming visits</p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {upcomingAppointments.map((apt: any) => (
                      <div key={apt.id} className="flex items-start space-x-3 border-b border-border pb-3 last:border-0">
                        <div className="bg-primary/10 rounded-md p-2">
                          <Calendar className="h-5 w-5 text-primary" />
                        </div>
                        <div className="flex-1">
                          <p className="font-medium">{apt.visitorName}</p>
                          <div className="flex items-center text-sm text-muted-foreground mt-1">
                            <Clock className="h-3 w-3 mr-1" />
                            <span>{new Date(apt.dateTime).toLocaleDateString()} at {new Date(apt.dateTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                          </div>
                          <div className="mt-1">
                            <span className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                              {apt.purpose || "Pet visit"}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full" onClick={() => setActiveTab("appointments")}>
                  View All Appointments
                </Button>
              </CardFooter>
            </Card>
          </div>
        </TabsContent>
        
        {/* Pets Tab */}
        <TabsContent value="pets" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Manage Pets</h2>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add New Pet
            </Button>
          </div>
          
          {isLoadingPets ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : pets.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Paw className="h-16 w-16 text-primary/20 mb-4" />
                <h3 className="text-xl font-medium mb-2">No pets listed</h3>
                <p className="text-muted-foreground mb-6 text-center max-w-md">
                  You haven't added any pets for adoption yet. Add pets to help them find their forever homes.
                </p>
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  Add Your First Pet
                </Button>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {pets.map((pet: any) => (
                <Card key={pet.id} className="overflow-hidden">
                  <div className="relative h-48 bg-primary/10">
                    {pet.mainImageUrl ? (
                      <img 
                        src={pet.mainImageUrl} 
                        alt={pet.name} 
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full">
                        <Paw className="h-12 w-12 text-primary/30" />
                      </div>
                    )}
                    <div className="absolute top-2 right-2 bg-background rounded-full px-2 py-1 text-xs font-medium shadow-sm">
                      {pet.status || "Available"}
                    </div>
                  </div>
                  <CardHeader className="pb-2">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg font-medium">{pet.name}</CardTitle>
                      <div className="text-xs bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                        {pet.type}
                      </div>
                    </div>
                    <CardDescription>{pet.breed}, {pet.age} years • {pet.gender}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <p className="text-sm line-clamp-2">{pet.description || "No description provided."}</p>
                  </CardContent>
                  <CardFooter className="flex justify-between">
                    <Button variant="outline" size="sm">
                      Edit
                    </Button>
                    <Button asChild variant="secondary" size="sm">
                      <Link href={`/adopt/${pet.id}`}>
                        View Page
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
        
        {/* Applications Tab */}
        <TabsContent value="applications" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Adoption Applications</h2>
            <div>
              <Button variant="outline" className="mr-2">
                <FileText className="h-4 w-4 mr-2" />
                Export Data
              </Button>
            </div>
          </div>
          
          {isLoadingApplications ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : applications.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <ClipboardList className="h-16 w-16 text-primary/20 mb-4" />
                <h3 className="text-xl font-medium mb-2">No applications received</h3>
                <p className="text-muted-foreground mb-6 text-center max-w-md">
                  You haven't received any adoption applications yet. Applications will appear here when users show interest in your pets.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-6">
              {/* Applications table would go here */}
              <p className="text-muted-foreground text-center py-8">
                Adoption applications will appear here once they are submitted.
              </p>
            </div>
          )}
        </TabsContent>
        
        {/* Appointments Tab */}
        <TabsContent value="appointments" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-semibold">Visit Appointments</h2>
            <Button variant="outline">
              <Calendar className="h-4 w-4 mr-2" />
              Set Availability
            </Button>
          </div>
          
          {isLoadingAppointments ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : appointments.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <Calendar className="h-16 w-16 text-primary/20 mb-4" />
                <h3 className="text-xl font-medium mb-2">No appointments</h3>
                <p className="text-muted-foreground mb-6 text-center max-w-md">
                  You don't have any scheduled appointments yet. They will appear here when visitors book a time to see your pets.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {/* Appointment list here */}
              <div className="bg-primary/5 p-4 rounded-lg">
                <h3 className="font-medium mb-4">Appointment Calendar</h3>
                <p className="text-muted-foreground">
                  Your appointment calendar will be displayed here.
                </p>
              </div>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}