import { useState, useEffect, useMemo, useRef } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Search, Heart, User, Briefcase, Building, MapPin, PawPrint, ChevronDown } from "lucide-react";
import { UserType } from "@shared/schema";

export default function HeroSection() {
  const [selectedUserType, setSelectedUserType] = useState<UserType>(UserType.PET_OWNER);
  const [isLoaded, setIsLoaded] = useState(false);
  const [showLocationPrompt, setShowLocationPrompt] = useState(true);
  const [currentBgIndex, setCurrentBgIndex] = useState(0);
  const heroRef = useRef<HTMLElement>(null);
  
  // User content based on selection with updated paths
  const userTypeContent = useMemo(() => ({
    [UserType.PET_OWNER]: {
      heading: "Your one-stop destination for all pet care needs",
      subheading: "Connect with trusted service providers, find perfect pets for adoption, and access resources to be the best pet parent.",
      cta1: { text: "Find Pet Services", icon: <Search className="mr-2 h-5 w-5" />, href: "/services" },
      cta2: { text: "Adopt a Pet", icon: <Heart className="mr-2 h-5 w-5" />, href: "/adopt" },
      bgImage: "https://images.unsplash.com/photo-1450778869180-41d0601e046e?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80"
    },
    [UserType.SERVICE_PROVIDER]: {
      heading: "Grow your pet care business with us",
      subheading: "Reach new clients, streamline bookings, and build your reputation on the leading pet services platform.",
      cta1: { text: "Register As Provider", icon: <Briefcase className="mr-2 h-5 w-5" />, href: "/auth?tab=register&type=service_provider" },
      cta2: { text: "Learn More", icon: <ChevronDown className="mr-2 h-5 w-5" />, href: "#value-proposition" },
      bgImage: "https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80"
    },
    [UserType.SHELTER]: {
      heading: "Connect more pets with loving homes",
      subheading: "Increase adoption rates, streamline applications, and join our network of animal welfare organizations.",
      cta1: { text: "Register Your Shelter", icon: <Building className="mr-2 h-5 w-5" />, href: "/auth?tab=register&type=shelter" },
      cta2: { text: "View Adoption Tools", icon: <PawPrint className="mr-2 h-5 w-5" />, href: "/shelter-resources" },
      bgImage: "https://images.unsplash.com/photo-1601758125946-6ec2ef64daf8?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80"
    }
  }), []);

  // Background images for parallax effect
  const backgroundImages = useMemo(() => [
    userTypeContent[UserType.PET_OWNER].bgImage,
    userTypeContent[UserType.SERVICE_PROVIDER].bgImage,
    userTypeContent[UserType.SHELTER].bgImage
  ], [userTypeContent]);
  
  useEffect(() => {
    setIsLoaded(true);
    
    // Parallax effect on scroll
    const handleScroll = () => {
      if (heroRef.current) {
        const scrollPosition = window.scrollY;
        const heroElement = heroRef.current;
        const offset = scrollPosition * 0.4;
        heroElement.style.backgroundPositionY = `${offset}px`;
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);
  
  // Change background when user type changes
  useEffect(() => {
    const newIndex = selectedUserType === UserType.PET_OWNER ? 0 : 
                     selectedUserType === UserType.SERVICE_PROVIDER ? 1 : 2;
    setCurrentBgIndex(newIndex);
  }, [selectedUserType]);
  
  const handleLocationPermission = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          // Successfully got location
          setShowLocationPrompt(false);
        },
        (error) => {
          console.error("Error getting location:", error);
        }
      );
    }
  };

  const content = userTypeContent[selectedUserType];

  return (
    <section 
      ref={heroRef}
      className="relative bg-primary overflow-hidden min-h-[90vh] flex items-center"
    >
      {/* Background gradient overlay with improved contrast */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary-dark/95 to-primary/90 z-10"></div>
      
      {/* Background image with parallax */}
      <div 
        className="absolute inset-0 bg-cover bg-center transition-all duration-1000 ease-in-out"
        style={{ 
          backgroundImage: `url(${backgroundImages[currentBgIndex]})`,
          transform: isLoaded ? 'scale(1.05)' : 'scale(1)',
        }}
      ></div>
      
      {/* Semi-transparent patterns overlay with reduced opacity */}
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMC4wNSI+PHBhdGggZD0iTTM2IDM0aDR2MWgtNHYtMXptMC0yaDF2NGgtMXYtNHptMTYgNGg0djFoLTR2LTF6bTAtMmgxdjRoLTF2LTR6bS0zMiA0aDE2djFIMjB2LTF6bTAtMmgxdjRoLTF2LTR6bTQtMTZWNGgxdjEyaC0xek0yMiA0aDEydjFIMjJWNHptMCA0aDEydjFIMjJWOHptMCA0aDEydjFIMjJ2LTF6bTAgOGgxMnYxSDIydi0xem0wIDRoMTJ2MUgyMnYtMXoiLz48L2c+PC9nPjwvc3ZnPg==')] z-10 opacity-20"></div>
      
      <div className="container mx-auto px-4 py-16 md:py-24 lg:py-32 relative z-20">
        <div className="max-w-2xl">
          {/* Main Heading */}
          <h1 
            className={`font-heading font-bold text-4xl md:text-5xl lg:text-6xl text-white leading-tight mb-4 transform transition-all duration-700 ${
              isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
            }`}
            style={{ textShadow: '0 2px 4px rgba(0,0,0,0.6)' }}
          >
            {content.heading}
          </h1>
          
          {/* Subheading with improved visibility */}
          <p 
            className={`text-white text-lg md:text-xl font-semibold mb-8 transform transition-all duration-700 delay-300 ${
              isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
            }`}
            style={{ textShadow: '0 1px 2px rgba(0,0,0,0.5)' }}
          >
            {content.subheading}
          </p>
          
          {/* CTA Buttons */}
          <div 
            className={`flex flex-col sm:flex-row gap-4 mb-8 transform transition-all duration-700 delay-500 ${
              isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'
            }`}
          >
            <Button 
              asChild
              className="group bg-white text-primary hover:bg-white/95 font-heading font-bold rounded-full px-7 py-6 flex items-center justify-center transition-all duration-300 shadow-xl hover:shadow-2xl transform hover:scale-105"
              size="lg"
            >
              <Link href={content.cta1.href}>
                <span className="flex items-center">
                  <span className="mr-2 transition-transform duration-300 group-hover:scale-110">
                    {content.cta1.icon}
                  </span>
                  {content.cta1.text}
                </span>
              </Link>
            </Button>
            <Button
              asChild
              className="group bg-secondary hover:bg-secondary-dark text-white font-heading font-bold rounded-full px-7 py-6 flex items-center justify-center transition-all duration-300 shadow-xl hover:shadow-2xl transform hover:scale-105"
              size="lg"
            >
              <Link href={content.cta2.href}>
                <span className="flex items-center text-sky-200">
                  <span className="mr-2 transition-transform duration-300 group-hover:scale-110 group-hover:animate-pulse">
                    {content.cta2.icon}
                  </span>
                  {content.cta2.text}
                </span>
              </Link>
            </Button>
          </div>
          
          {/* Location Permission Prompt - with animation */}
          {showLocationPrompt && (
            <div 
              className={`bg-white/10 backdrop-blur-md rounded-xl p-4 mb-8 flex items-center gap-3 shadow-lg cursor-pointer hover:bg-white/15 transition-all transform ${
                isLoaded ? 'translate-y-0 opacity-100 animate-fadeInUp delay-700' : 'translate-y-8 opacity-0'
              }`}
              onClick={handleLocationPermission}
            >
              <div className="relative">
                <MapPin className="text-white z-10 relative" />
                <span className="absolute inset-0 rounded-full animate-pulse-location"></span>
              </div>
              <div>
                <p className="text-white font-semibold text-sm">Enable location services</p>
                <p className="text-white/80 text-xs">Find services and adoptable pets near you</p>
              </div>
              <Button 
                size="sm" 
                variant="secondary" 
                className="ml-auto rounded-full text-xs py-1 px-4 hover:bg-white hover:text-primary transition-all duration-300"
                onClick={handleLocationPermission}
              >
                Allow
              </Button>
            </div>
          )}
          
          {/* User Type Selection - Enhanced */}
          <div 
            className={`bg-white/15 backdrop-blur-md rounded-xl p-5 flex flex-col sm:flex-row gap-4 transform transition-all duration-700 ${
              isLoaded ? 'translate-y-0 opacity-100 animate-fadeInUp delay-900' : 'translate-y-8 opacity-0'
            }`}
          >
            <span className="text-white font-medium">I am a:</span>
            <div className="flex flex-wrap gap-3">
              <UserTypeButton 
                type={UserType.PET_OWNER} 
                label="Pet Owner"
                icon={<User className="h-4 w-4" />}
                isSelected={selectedUserType === UserType.PET_OWNER}
                onClick={() => setSelectedUserType(UserType.PET_OWNER)}
              />
              <UserTypeButton 
                type={UserType.SERVICE_PROVIDER} 
                label="Service Provider"
                icon={<Briefcase className="h-4 w-4" />}
                isSelected={selectedUserType === UserType.SERVICE_PROVIDER}
                onClick={() => setSelectedUserType(UserType.SERVICE_PROVIDER)}
              />
              <UserTypeButton 
                type={UserType.SHELTER} 
                label="Shelter"
                icon={<Building className="h-4 w-4" />}
                isSelected={selectedUserType === UserType.SHELTER}
                onClick={() => setSelectedUserType(UserType.SHELTER)}
              />
            </div>
          </div>
          
          {/* Scroll indicator */}
          <div className={`mt-8 hidden md:flex justify-center animate-bounce-subtle transition-opacity duration-1000 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}>
            <ChevronDown className="text-white/70 h-8 w-8" />
          </div>
        </div>
      </div>
      
      {/* Animated shapes */}
      <div className="absolute bottom-0 right-0 w-1/3 h-1/3 opacity-20 z-10">
        <div className="absolute right-20 bottom-20 w-20 h-20 rounded-full bg-secondary/40 animate-float"></div>
        <div className="absolute right-40 bottom-40 w-16 h-16 rounded-full bg-primary-light/30 animate-float animation-delay-500"></div>
        <div className="absolute right-60 bottom-10 w-12 h-12 rounded-full bg-white/20 animate-float animation-delay-300"></div>
      </div>
    </section>
  );
}

interface UserTypeButtonProps {
  type: UserType;
  label: string;
  icon: React.ReactNode;
  isSelected: boolean;
  onClick: () => void;
}

function UserTypeButton({ type, label, icon, isSelected, onClick }: UserTypeButtonProps) {
  return (
    <button
      className={`group text-white font-semibold rounded-full px-4 py-2 text-sm transition-all duration-300 flex items-center transform hover:scale-105 ${
        isSelected 
          ? 'bg-white/30 shadow-md hover:bg-white/40' 
          : 'bg-white/10 hover:bg-white/20'
      }`}
      onClick={onClick}
    >
      <span className={`flex items-center justify-center w-6 h-6 rounded-full mr-2 transition-all duration-300 ${
        isSelected ? 'bg-white/20 text-white' : 'bg-transparent text-white/90'
      } group-hover:scale-110`}>
        {icon}
      </span>
      {label}
    </button>
  );
}
