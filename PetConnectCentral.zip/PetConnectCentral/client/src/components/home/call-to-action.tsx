import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function CallToAction() {
  return (
    <section className="py-12 md:py-16 bg-primary text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="font-heading font-bold text-3xl mb-4">Join Our Pet-Loving Community Today</h2>
        <p className="max-w-2xl mx-auto mb-8 opacity-90">
          Create an account to connect with services, find your perfect pet, or offer your expertise to pet owners.
        </p>
        
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Button 
            asChild
            className="bg-white text-primary hover:bg-neutral-100 font-heading font-bold rounded-full px-8 py-3 transition"
          >
            <Link href="/auth">
              Create Account
            </Link>
          </Button>
          <Button
            asChild
            variant="outline"
            className="bg-transparent border-2 border-white hover:bg-white hover:bg-opacity-10 text-white font-heading font-bold rounded-full px-8 py-3 transition"
          >
            <Link href="/about">
              Learn More
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}
