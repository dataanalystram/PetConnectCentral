import { useState } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { 
  MapPin, 
  Search, 
  Star, 
  ChevronRight, 
  ChevronLeft 
} from "lucide-react";
import { serviceCategories } from "@/data/services";

export default function ServicesDiscovery() {
  const [serviceSearch, setServiceSearch] = useState("");
  const [location, setLocation] = useState("Berlin, DE");

  return (
    <section className="py-12 md:py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-heading font-bold text-3xl text-neutral-800 mb-3">Discover Pet Services</h2>
          <p className="text-neutral-500 max-w-2xl mx-auto">
            Find trusted providers for all your pet care needs, from veterinary care to grooming, training, and more.
          </p>
        </div>
        
        {/* Service Categories */}
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-12">
          {serviceCategories.map((category, index) => (
            <div 
              key={category.value}
              className="bg-neutral-50 rounded-xl p-4 text-center transition-all duration-300 transform hover:scale-105 hover:shadow-md hover:bg-white cursor-pointer group"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="bg-primary-light bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-3 transition-all duration-300 group-hover:bg-opacity-20">
                <div className="text-2xl text-primary transition-all duration-300 hover:scale-110">
                  {category.icon}
                </div>
              </div>
              <h3 className="font-heading font-semibold text-neutral-800">{category.label}</h3>
            </div>
          ))}
        </div>
        
        {/* Service Location Search */}
        <div className="bg-neutral-50 rounded-xl p-6 mb-12 shadow-sm hover:shadow-md transition-all duration-300 transform hover:scale-[1.01]">
          <div className="max-w-3xl mx-auto">
            <h3 className="font-heading font-bold text-xl text-neutral-800 mb-4 text-center">Find services near you</h3>
            <div className="flex flex-col md:flex-row gap-3">
              <div className="flex-grow relative group">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 h-5 w-5 group-hover:text-primary transition-colors duration-300" />
                <Input 
                  type="text" 
                  className="w-full pl-10 pr-4 py-3 rounded-lg border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300 hover:border-primary" 
                  placeholder="Search service or provider name"
                  value={serviceSearch}
                  onChange={(e) => setServiceSearch(e.target.value)}
                />
                {serviceSearch && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-white rounded-lg shadow-lg p-2 z-10 animate-fadeIn">
                    <div className="p-2 hover:bg-neutral-50 rounded cursor-pointer">Veterinary Services</div>
                    <div className="p-2 hover:bg-neutral-50 rounded cursor-pointer">Pet Grooming</div>
                    <div className="p-2 hover:bg-neutral-50 rounded cursor-pointer">Dog Training</div>
                  </div>
                )}
              </div>
              <div className="relative md:w-1/3 group">
                <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-neutral-400 h-5 w-5 group-hover:text-primary transition-colors duration-300" />
                <Input 
                  type="text" 
                  className="w-full pl-10 pr-4 py-3 rounded-lg border border-neutral-200 focus:outline-none focus:ring-2 focus:ring-primary transition-all duration-300 hover:border-primary" 
                  placeholder="Location" 
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                />
              </div>
              <Button className="bg-primary hover:bg-primary-dark text-white font-heading font-semibold rounded-lg px-6 py-3 transition-all duration-300 transform hover:scale-105 hover:shadow-md">
                Search
              </Button>
            </div>
          </div>
        </div>
        
        {/* Featured Service Providers */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-heading font-bold text-2xl text-neutral-800">Featured Providers</h3>
            <div className="flex items-center">
              <Link href="/services" className="text-primary font-semibold flex items-center mr-4 group">
                <span className="group-hover:underline">View all</span>
                <ChevronRight className="ml-1 h-4 w-4 transition-transform duration-300 transform group-hover:translate-x-1" />
              </Link>
              <div className="flex items-center space-x-2">
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="bg-white border border-neutral-200 hover:border-primary hover:bg-primary hover:text-white text-neutral-600 rounded-full transition-all duration-300 transform hover:scale-110"
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="bg-white border border-neutral-200 hover:border-primary hover:bg-primary hover:text-white text-neutral-600 rounded-full transition-all duration-300 transform hover:scale-110"
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <ServiceProviderCard
              name="Pet Care Clinic Berlin"
              category="Veterinary"
              image="https://images.unsplash.com/photo-1612991635366-2410d226606a?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
              rating={4.8}
              location="Prenzlauer Berg, Berlin"
              distance="1.2 km"
              description="Full-service veterinary clinic with emergency care, specialists, and modern diagnostic equipment."
              price="From €50/visit"
            />
            
            <ServiceProviderCard
              name="Happy Paws Grooming"
              category="Grooming"
              image="https://images.unsplash.com/photo-1537151625747-768eb6cf92b2?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
              rating={4.9}
              location="Kreuzberg, Berlin"
              distance="2.8 km"
              description="Professional grooming services using natural, eco-friendly products for all breeds."
              price="From €35/session"
            />
            
            <ServiceProviderCard
              name="Pawsitive Training"
              category="Training"
              image="https://images.unsplash.com/photo-1587300003388-59208cc962cb?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80"
              rating={4.7}
              location="Mitte, Berlin"
              distance="0.5 km"
              description="Certified dog trainers offering group and private sessions using positive reinforcement methods."
              price="From €45/session"
            />
          </div>
        </div>
        
        <div className="text-center">
          <Button 
            asChild
            className="inline-block bg-white border-2 border-primary hover:bg-primary hover:border-primary text-primary hover:text-white font-heading font-semibold rounded-full px-8 py-3 transition-all duration-300 transform hover:scale-105 hover:shadow-md group"
          >
            <Link href="/services" className="flex items-center">
              Explore All Services
              <ChevronRight className="ml-2 h-4 w-4 transition-transform duration-300 transform group-hover:translate-x-1" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}

interface ServiceProviderCardProps {
  name: string;
  category: string;
  image: string;
  rating: number;
  location: string;
  distance: string;
  description: string;
  price: string;
}

function ServiceProviderCard({
  name,
  category,
  image,
  rating,
  location,
  distance,
  description,
  price,
}: ServiceProviderCardProps) {
  return (
    <Card className="overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 transform hover:scale-[1.02] cursor-pointer group">
      <div 
        className="h-40 bg-neutral-200 relative overflow-hidden"
        style={{ 
          backgroundImage: `url(${image})`, 
          backgroundSize: 'cover', 
          backgroundPosition: 'center'
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        <div className="absolute top-3 right-3 bg-white text-primary rounded-full px-3 py-1 text-sm font-semibold shadow-sm transform transition-transform duration-300 group-hover:scale-105">
          {category}
        </div>
      </div>
      <CardContent className="p-5">
        <div className="flex justify-between items-start mb-3">
          <h4 className="font-heading font-bold text-lg text-neutral-800 group-hover:text-primary transition-colors duration-300">{name}</h4>
          <div className="flex items-center">
            <Star className="h-4 w-4 fill-secondary text-secondary group-hover:animate-pulse" />
            <span className="ml-1 font-semibold">{rating}</span>
          </div>
        </div>
        <div className="flex items-center text-neutral-500 text-sm mb-3">
          <span className="relative mr-1">
            <MapPin className="h-3 w-3 text-primary z-10 relative" />
            <span className="absolute inset-0 rounded-full animate-pulse-location group-hover:animate-none"></span>
          </span>
          <span>{location} • <span className="font-semibold">{distance}</span></span>
        </div>
        <p className="text-neutral-600 text-sm mb-4 line-clamp-2">{description}</p>
        <div className="flex justify-between items-center">
          <span className="text-neutral-500 text-sm">{price}</span>
          <Button className="bg-primary bg-opacity-10 hover:bg-primary hover:text-white text-primary font-semibold rounded-full px-4 py-1.5 text-sm transition-all duration-300 transform group-hover:scale-105">
            Book Now
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
