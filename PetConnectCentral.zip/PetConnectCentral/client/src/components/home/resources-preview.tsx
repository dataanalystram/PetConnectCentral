import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { ChevronRight, Clock } from "lucide-react";
import { resources } from "@/data/resources";

export default function ResourcesPreview() {
  return (
    <section className="py-12 md:py-16 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-heading font-bold text-3xl text-neutral-800 mb-3">Pet Care Resources</h2>
          <p className="text-neutral-500 max-w-2xl mx-auto">
            Access expert advice, educational content, and community discussions to provide the best care for your pets.
          </p>
        </div>
        
        {/* Resource Categories */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <ResourceCategory 
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="text-3xl text-primary" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/></svg>}
            title="Articles & Guides"
            description="Expert-written articles on pet health, behavior, nutrition, and more."
            linkText="Browse articles"
            linkHref="/resources"
          />
          
          <ResourceCategory 
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="text-3xl text-primary" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"/><polygon points="10 8 16 12 10 16 10 8"/></svg>}
            title="Training Videos"
            description="Watch professional training tutorials and educational content."
            linkText="Watch videos"
            linkHref="/resources?tab=videos"
          />
          
          <ResourceCategory 
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="text-3xl text-primary" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>}
            title="Community Forums"
            description="Connect with other pet owners, share experiences, and get advice."
            linkText="Join discussions"
            linkHref="/resources?tab=community"
          />
        </div>
        
        {/* Trending Articles */}
        <div className="mb-12">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-heading font-bold text-2xl text-neutral-800">Trending Articles</h3>
            <Link href="/resources" className="text-primary font-semibold flex items-center hover:underline">
              View all
              <ChevronRight className="ml-1 h-4 w-4" />
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {resources.map((article, index) => (
              <ArticleCard 
                key={index}
                title={article.title}
                category={article.category}
                readTime={article.readTime}
                excerpt={article.content}
                author={article.author}
                date="May 15, 2023"
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

interface ResourceCategoryProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  linkText: string;
  linkHref: string;
}

function ResourceCategory({ 
  icon, 
  title, 
  description, 
  linkText, 
  linkHref 
}: ResourceCategoryProps) {
  return (
    <div className="bg-neutral-50 rounded-xl p-6 transition hover:shadow-md">
      <div className="mb-4">
        {icon}
      </div>
      <h3 className="font-heading font-bold text-xl text-neutral-800 mb-2">{title}</h3>
      <p className="text-neutral-600 mb-4">{description}</p>
      <Link href={linkHref} className="text-primary font-semibold hover:underline inline-flex items-center">
        {linkText}
        <ChevronRight className="ml-1 h-4 w-4" />
      </Link>
    </div>
  );
}

interface ArticleCardProps {
  title: string;
  category: string;
  readTime: number;
  excerpt: string;
  author: string;
  date: string;
}

function ArticleCard({
  title,
  category,
  readTime,
  excerpt,
  author,
  date,
}: ArticleCardProps) {
  return (
    <Card className="bg-white border border-neutral-100 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition cursor-pointer">
      <div className="h-40 bg-neutral-200"></div>
      <CardContent className="p-5">
        <div className="flex items-center text-xs text-neutral-500 mb-2">
          <span>{category}</span>
          <span className="mx-2">•</span>
          <div className="flex items-center">
            <Clock className="h-3 w-3 mr-1" />
            <span>{readTime} min read</span>
          </div>
        </div>
        <h4 className="font-heading font-bold text-lg text-neutral-800 mb-2">{title}</h4>
        <p className="text-neutral-600 text-sm mb-3 line-clamp-2">{excerpt}</p>
        <div className="flex items-center">
          <div className="w-8 h-8 rounded-full bg-neutral-300 mr-3"></div>
          <div className="text-xs">
            <div className="font-semibold text-neutral-800">{author}</div>
            <div className="text-neutral-500">{date}</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
