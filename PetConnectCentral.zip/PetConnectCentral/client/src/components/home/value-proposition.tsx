import { ReactNode } from "react";

export default function ValueProposition() {
  return (
    <section className="py-12 md:py-16 bg-neutral-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="font-heading font-bold text-3xl text-neutral-800 mb-3">Why Choose PetPal?</h2>
          <p className="text-neutral-500 max-w-2xl mx-auto">
            We're more than just a platform - we're a community passionate about improving the lives of pets and their owners.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <ValueCard
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="text-primary text-2xl" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>}
            title="Trusted Providers"
            description="All service providers undergo verification and are reviewed by real customers. We only partner with professionals committed to quality care."
          />
          
          <ValueCard
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="text-primary text-2xl" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>}
            title="Adoption Support"
            description="We facilitate responsible adoptions and provide ongoing resources to help both pets and owners adjust to their new lives together."
          />
          
          <ValueCard
            icon={<svg xmlns="http://www.w3.org/2000/svg" className="text-primary text-2xl" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"/><polyline points="12 13 12 7 16 10 12 13"/></svg>}
            title="Expert Resources"
            description="Access a wealth of educational content created by veterinarians, trainers, and animal behavior specialists to help you provide the best care."
          />
        </div>
      </div>
    </section>
  );
}

interface ValueCardProps {
  icon: ReactNode;
  title: string;
  description: string;
}

function ValueCard({ icon, title, description }: ValueCardProps) {
  return (
    <div className="text-center bg-white p-8 rounded-xl shadow-sm">
      <div className="bg-primary-light bg-opacity-10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
        {icon}
      </div>
      <h3 className="font-heading font-bold text-xl text-neutral-800 mb-3">{title}</h3>
      <p className="text-neutral-600">{description}</p>
    </div>
  );
}
