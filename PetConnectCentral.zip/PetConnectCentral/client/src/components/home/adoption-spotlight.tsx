import { useState, useRef, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Heart, 
  MapPin, 
  ChevronLeft, 
  ChevronRight,
  Search,
  FileText,
  Users
} from "lucide-react";

// Sample pet images for the carousel
const PET_IMAGES = [
  "https://images.unsplash.com/photo-1543466835-00a7907e9de1?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
  "https://images.unsplash.com/photo-1548247416-ec66f4900b2e?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
  "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
  "https://images.unsplash.com/photo-1561037404-61cd46aa615b?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60"
];

// Sample success story images
const SUCCESS_IMAGES = [
  "https://images.unsplash.com/photo-1559190394-df5a28aab5c5?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60",
  "https://images.unsplash.com/photo-1536390631643-8c5473c4220b?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60"
];

// Sample shelter logos
const SHELTER_LOGOS = [
  "https://images.unsplash.com/photo-1518791841217-8f162f1e1131?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=60",
  "https://images.unsplash.com/photo-1519052537078-e6302a4968d4?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=60",
  "https://images.unsplash.com/photo-1543852786-1cf6624b9987?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=60",
  "https://images.unsplash.com/photo-1556582305-528bffcf7af0?ixlib=rb-1.2.1&auto=format&fit=crop&w=200&q=60"
];

export default function AdoptionSpotlight() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isLoaded, setIsLoaded] = useState(false);
  const carouselRef = useRef<HTMLDivElement>(null);
  
  useEffect(() => {
    setIsLoaded(true);
    
    // Auto-advance carousel every 5 seconds
    const interval = setInterval(() => {
      nextSlide();
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);
  
  const nextSlide = () => {
    setActiveIndex((prevIndex) => (prevIndex + 1) % 4);
  };
  
  const prevSlide = () => {
    setActiveIndex((prevIndex) => (prevIndex === 0 ? 3 : prevIndex - 1));
  };
  
  return (
    <section className="py-16 md:py-24 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12 max-w-3xl mx-auto">
          <h2 className="font-heading font-bold text-3xl md:text-4xl text-neutral-800 mb-4 animate-fadeInUp">Find Your Perfect Companion</h2>
          <p className="text-neutral-600 text-lg mx-auto animate-fadeInUp animation-delay-200">
            Thousands of loving animals are waiting for their forever homes. Browse available pets from shelters and rescue organizations nationwide.
          </p>
        </div>
        
        {/* Featured Pets Carousel */}
        <div className="mb-16">
          <div className="flex justify-between items-center mb-8">
            <h3 className="font-heading font-bold text-2xl text-neutral-800">Featured Pets</h3>
            <div className="flex items-center">
              <Link href="/adopt" className="text-primary font-semibold flex items-center hover:underline mr-4 group">
                <span className="group-hover:underline">View all pets</span>
                <ChevronRight className="ml-1 h-4 w-4 transition-transform duration-300 transform group-hover:translate-x-1" />
              </Link>
              <div className="flex items-center space-x-3">
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="bg-white border border-neutral-200 hover:border-primary hover:bg-primary hover:text-white text-neutral-600 rounded-full transition-all duration-300 transform hover:scale-110"
                  onClick={prevSlide}
                >
                  <ChevronLeft className="h-4 w-4" />
                </Button>
                <Button 
                  variant="outline" 
                  size="icon" 
                  className="bg-white border border-neutral-200 hover:border-primary hover:bg-primary hover:text-white text-neutral-600 rounded-full transition-all duration-300 transform hover:scale-110"
                  onClick={nextSlide}
                >
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
          
          {/* Carousel Container */}
          <div className="relative overflow-hidden" ref={carouselRef}>
            <div 
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${activeIndex * 100}%)` }}
            >
              <div className="w-full flex-shrink-0 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <PetCard
                  name="Max"
                  status="Available"
                  breed="German Shepherd"
                  age={2}
                  gender="Male"
                  description="Friendly and active German Shepherd looking for an active family. Good with children and other dogs."
                  shelter="Berlin Animal Shelter"
                  image={PET_IMAGES[0]}
                />
                
                <PetCard
                  name="Luna"
                  status="Available"
                  breed="Tabby Cat"
                  age={1}
                  gender="Female"
                  description="Sweet and playful tabby who loves attention. Already spayed and litter trained."
                  shelter="Paws Rescue Center"
                  image={PET_IMAGES[1]}
                />
                
                <PetCard
                  name="Buddy"
                  status="Available"
                  breed="Golden Retriever"
                  age={3}
                  gender="Male"
                  description="Gentle, loving retriever who adores people and other pets. Well trained and house broken."
                  shelter="Golden Heart Rescue"
                  image={PET_IMAGES[2]}
                />
                
                <PetCard
                  name="Coco"
                  status="Available"
                  breed="French Bulldog"
                  age={4}
                  gender="Female"
                  description="Charming and affectionate Frenchie who loves cuddles and short walks. Perfect apartment companion."
                  shelter="Berlin Animal Shelter"
                  image={PET_IMAGES[3]}
                />
              </div>
              
              {/* Additional carousel pages would go here */}
            </div>
            
            {/* Carousel Indicators */}
            <div className="flex justify-center mt-6 space-x-2">
              {[0, 1, 2, 3].map((index) => (
                <button
                  key={index}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    activeIndex === index ? 'bg-primary w-6' : 'bg-neutral-300'
                  }`}
                  onClick={() => setActiveIndex(index)}
                />
              ))}
            </div>
          </div>
        </div>
        
        {/* Success Stories */}
        <div className="bg-white rounded-xl overflow-hidden shadow-lg mb-16 transform hover:shadow-xl transition-all duration-300">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-0">
            <div className="p-8 flex flex-col justify-center animate-fadeInLeft">
              <h3 className="font-heading font-bold text-2xl text-neutral-800 mb-4">Success Stories</h3>
              <div className="mb-6">
                <div className="flex items-center mb-4">
                  <img 
                    src={SUCCESS_IMAGES[0]} 
                    alt="Person with pet" 
                    className="w-12 h-12 rounded-full object-cover mr-4 border-2 border-primary"
                  />
                  <div>
                    <h4 className="font-heading font-semibold text-neutral-800">Michael S.</h4>
                    <p className="text-sm text-neutral-500">Adopted Max, German Shepherd</p>
                  </div>
                </div>
                <p className="text-neutral-600">
                  "Adopting Max through this platform was the best decision. The process was seamless,
                  and the shelter provided all the information we needed. He's been an amazing addition to our family!"
                </p>
              </div>
              <Link href="/success-stories" className="text-primary font-semibold hover:underline inline-flex items-center group">
                <span className="group-hover:underline">Read more success stories</span>
                <ChevronRight className="ml-1 h-4 w-4 transition-transform duration-300 transform group-hover:translate-x-1" />
              </Link>
            </div>
            
            {/* Before/After Images with Sliding Effect */}
            <div className="relative h-64 md:h-auto overflow-hidden group">
              <div className="absolute inset-0 bg-neutral-800 opacity-10 z-10"></div>
              <div className="absolute inset-0 z-20 flex items-center justify-center">
                <div className="absolute h-full w-1/2 left-0 overflow-hidden">
                  <img 
                    src={SUCCESS_IMAGES[0]} 
                    alt="Before adoption" 
                    className="h-full w-auto object-cover min-w-full transform scale-110 transition-transform duration-500 group-hover:scale-125"
                  />
                  <div className="absolute bottom-4 left-4 bg-black/50 text-white px-3 py-1 rounded-full text-xs">Before</div>
                </div>
                <div className="absolute h-full w-1/2 right-0 overflow-hidden">
                  <img 
                    src={SUCCESS_IMAGES[1]} 
                    alt="After adoption" 
                    className="h-full w-auto object-cover min-w-full transform scale-110 transition-transform duration-500 group-hover:scale-125" 
                  />
                  <div className="absolute bottom-4 right-4 bg-primary/80 text-white px-3 py-1 rounded-full text-xs">After</div>
                </div>
                {/* Slider Handle */}
                <div className="absolute h-full w-4 bg-white shadow-lg z-30 transition-transform duration-500 group-hover:scale-y-110">
                  <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center">
                    <ChevronLeft className="h-4 w-4 text-primary absolute left-0" />
                    <ChevronRight className="h-4 w-4 text-primary absolute right-0" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* How Adoption Works */}
        <div className="mb-16">
          <h3 className="font-heading font-bold text-2xl md:text-3xl text-neutral-800 text-center mb-12">How Adoption Works</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <AdoptionStep
              icon={<Search className="w-8 h-8 text-primary" />}
              title="Browse & Search"
              description="Find pets matching your lifestyle and preferences"
              isActive={true}
              step={1}
            />
            <AdoptionStep
              icon={<FileText className="w-8 h-8 text-primary" />}
              title="Apply"
              description="Submit your adoption application directly through the platform"
              isActive={false}
              step={2}
            />
            <AdoptionStep
              icon={<Users className="w-8 h-8 text-primary" />}
              title="Meet"
              description="Schedule a visit to meet your potential new family member"
              isActive={false}
              step={3}
            />
            <AdoptionStep
              icon={<Heart className="w-8 h-8 text-primary" />}
              title="Welcome Home"
              description="Complete the adoption process and welcome your new pet"
              isActive={false}
              step={4}
            />
          </div>
        </div>
        
        {/* Shelter Partners */}
        <div className="mb-16">
          <h3 className="font-heading font-semibold text-lg text-neutral-700 text-center mb-6">Our Shelter Partners</h3>
          <div className="flex flex-wrap justify-center items-center gap-8 md:gap-12">
            {SHELTER_LOGOS.map((logo, index) => (
              <div 
                key={index} 
                className="w-20 h-20 grayscale hover:grayscale-0 opacity-70 hover:opacity-100 transition-all duration-300 flex items-center justify-center"
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <img src={logo} alt={`Shelter partner ${index + 1}`} className="max-w-full max-h-full" />
              </div>
            ))}
          </div>
        </div>
        
        {/* CTA Button */}
        <div className="text-center">
          <Button 
            asChild
            className="group inline-block bg-secondary hover:bg-secondary-dark text-white font-heading font-semibold rounded-full px-8 py-4 transition-all duration-300 transform hover:scale-105 hover:shadow-lg text-lg"
          >
            <Link href="/adopt" className="flex items-center">
              Find Your Perfect Match
              <Heart className="ml-2 h-5 w-5 transition-all duration-300 transform group-hover:scale-110 group-hover:animate-pulse" />
            </Link>
          </Button>
        </div>
      </div>
    </section>
  );
}

interface PetCardProps {
  name: string;
  status: string;
  breed: string;
  age: number;
  gender: string;
  description: string;
  shelter: string;
  image: string;
}

function PetCard({
  name,
  status,
  breed,
  age,
  gender,
  description,
  shelter,
  image
}: PetCardProps) {
  const [isFavorite, setIsFavorite] = useState(false);
  
  return (
    <Card className="overflow-hidden shadow-sm hover:shadow-lg transition-all duration-300 transform hover:scale-[1.02] cursor-pointer group">
      <div 
        className="h-48 bg-neutral-200 relative overflow-hidden"
        style={{ 
          backgroundImage: `url(${image})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center' 
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
        
        {/* Status Badge */}
        <Badge className="absolute top-3 left-3 text-xs font-semibold bg-white text-primary ring-1 ring-primary rounded-full px-2 py-1 shadow-md transform transition-transform duration-300 group-hover:scale-105">
          {status}
        </Badge>
        
        {/* Favorite Button */}
        <Button
          variant="outline"
          size="icon"
          className={`absolute top-3 right-3 rounded-full p-1.5 border-none shadow-md transition-all duration-300 ${
            isFavorite 
              ? 'bg-secondary text-white' 
              : 'bg-white text-neutral-400 hover:bg-white hover:text-secondary'
          }`}
          onClick={(e) => {
            e.stopPropagation();
            setIsFavorite(!isFavorite);
          }}
        >
          <Heart className={`h-4 w-4 ${isFavorite ? 'fill-current' : ''}`} />
        </Button>
        
        {/* Sliding info on hover */}
        <div className="absolute left-0 right-0 bottom-0 p-3 transform translate-y-full group-hover:translate-y-0 transition-transform duration-300">
          <div className="flex flex-wrap gap-2">
            <span className="text-xs bg-black/30 text-white rounded-full px-2 py-0.5 backdrop-blur-sm">
              {breed}
            </span>
            <span className="text-xs bg-black/30 text-white rounded-full px-2 py-0.5 backdrop-blur-sm">
              {age} {age === 1 ? "year" : "years"}
            </span>
            <span className="text-xs bg-black/30 text-white rounded-full px-2 py-0.5 backdrop-blur-sm">
              {gender}
            </span>
          </div>
        </div>
      </div>
      
      <CardContent className="p-4">
        <h4 className="font-heading font-bold text-lg text-neutral-800 mb-2 group-hover:text-primary transition-colors duration-300">{name}</h4>
        <p className="text-neutral-600 text-sm mb-3 line-clamp-2">{description}</p>
        <div className="flex justify-between items-center">
          <div className="flex items-center text-neutral-500 text-xs">
            <span className="relative mr-1">
              <MapPin className="h-3 w-3 text-primary z-10 relative" />
              <span className="absolute inset-0 rounded-full animate-pulse-location group-hover:animate-none"></span>
            </span>
            <span>{shelter}</span>
          </div>
          <Link 
            href={`/adopt/pet/${name.toLowerCase()}`} 
            className="text-primary hover:text-primary-dark font-semibold text-sm flex items-center group-hover:underline transition-colors duration-300"
          >
            View Details
            <ChevronRight className="ml-1 h-3 w-3 transition-transform duration-300 transform group-hover:translate-x-1" />
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}

interface AdoptionStepProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  isActive: boolean;
  step: number;
}

function AdoptionStep({ icon, title, description, isActive, step }: AdoptionStepProps) {
  return (
    <div className="text-center group relative">
      {/* Step number indicator */}
      <div className="absolute -top-3 -left-3 w-8 h-8 rounded-full bg-neutral-100 text-primary font-bold flex items-center justify-center border-2 border-white shadow-md">
        {step}
      </div>
      
      {/* Icon container with hover effect */}
      <div className={`w-20 h-20 rounded-full mx-auto mb-4 flex items-center justify-center transition-all duration-300 transform group-hover:scale-110 ${
        isActive 
          ? 'bg-primary text-white shadow-lg' 
          : 'bg-primary/10 text-primary group-hover:bg-primary/20'
      }`}>
        <div className="transform transition-transform duration-300 group-hover:scale-110">
          {icon}
        </div>
      </div>
      
      {/* Title with underline animation */}
      <h4 className="font-heading font-semibold text-xl text-neutral-800 mb-2 relative inline-block">
        {title}
        <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-primary group-hover:w-full transition-all duration-300"></span>
      </h4>
      
      {/* Description */}
      <p className="text-neutral-600 text-sm max-w-xs mx-auto">{description}</p>
      
      {/* Connector line between steps (hidden on mobile) */}
      {step < 4 && (
        <div className="hidden lg:block absolute top-10 left-[calc(50%+40px)] right-0 h-0.5 bg-neutral-200 w-[calc(100%-80px)]">
          {/* Animated progress dot */}
          <div className="absolute top-1/2 left-0 transform -translate-y-1/2 w-2 h-2 rounded-full bg-primary animate-pulse"></div>
        </div>
      )}
    </div>
  );
}
