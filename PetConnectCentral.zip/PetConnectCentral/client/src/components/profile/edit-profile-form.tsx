import { useMutation } from '@tanstack/react-query';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { Loader2 } from 'lucide-react';
import { apiRequest } from '@/lib/queryClient';
import { UserType } from '@shared/schema';

// Form schema defined based on user type
const createFormSchema = (userType: UserType) => {
  const baseSchema = z.object({
    name: z.string().min(2, 'Name must be at least 2 characters'),
    location: z.string().optional(),
  });

  // Add fields based on user type
  switch (userType) {
    case UserType.PET_OWNER:
      return baseSchema.extend({
        bio: z.string().optional(),
      });
    case UserType.SERVICE_PROVIDER:
      return baseSchema.extend({
        businessName: z.string().min(2, 'Business name must be at least 2 characters'),
        category: z.string().min(1, 'Please select a category'),
        description: z.string().optional(),
        phone: z.string().optional(),
        address: z.string().optional(),
      });
    case UserType.SHELTER:
      return baseSchema.extend({
        organizationName: z.string().min(2, 'Organization name must be at least 2 characters'),
        mission: z.string().optional(),
        phone: z.string().optional(),
        address: z.string().optional(),
      });
    default:
      return baseSchema;
  }
};

type EditProfileFormProps = {
  userProfile: any; // Using any type for simplicity
  onSuccess: () => void;
};

export default function EditProfileForm({ userProfile, onSuccess }: EditProfileFormProps) {
  const { toast } = useToast();
  const formSchema = createFormSchema(userProfile.userType as UserType);
  
  type FormValues = z.infer<typeof formSchema>;
  
  // Set up form with user's existing data
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: userProfile.name || '',
      location: userProfile.location || '',
      ...(userProfile.userType === UserType.PET_OWNER && {
        bio: userProfile.bio || '',
      }),
      ...(userProfile.userType === UserType.SERVICE_PROVIDER && {
        businessName: userProfile.businessName || '',
        category: userProfile.category || '',
        description: userProfile.description || '',
        phone: userProfile.phone || '',
        address: userProfile.address || '',
      }),
      ...(userProfile.userType === UserType.SHELTER && {
        organizationName: userProfile.organizationName || '',
        mission: userProfile.mission || '',
        phone: userProfile.phone || '',
        address: userProfile.address || '',
      }),
    },
  });
  
  // Mutation for handling the form submission
  const mutation = useMutation({
    mutationFn: async (values: FormValues) => {
      const res = await apiRequest('PUT', '/api/user/profile', values);
      if (!res.ok) {
        const error = await res.json();
        throw new Error(error.message || 'Failed to update profile');
      }
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: 'Profile updated',
        description: 'Your profile has been updated successfully.',
      });
      onSuccess();
    },
    onError: (error: Error) => {
      toast({
        title: 'Update failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });
  
  const onSubmit = (values: FormValues) => {
    mutation.mutate(values);
  };
  
  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        {/* Base fields for all user types */}
        <FormField
          control={form.control}
          name="name"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Name</FormLabel>
              <FormControl>
                <Input {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        <FormField
          control={form.control}
          name="location"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Location</FormLabel>
              <FormControl>
                <Input {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />
        
        {/* Pet Owner specific fields */}
        {userProfile.userType === UserType.PET_OWNER && (
          <FormField
            control={form.control}
            name="bio"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Bio</FormLabel>
                <FormControl>
                  <Textarea 
                    {...field} 
                    placeholder="Tell us about yourself and your pets..."
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        )}
        
        {/* Service Provider specific fields */}
        {userProfile.userType === UserType.SERVICE_PROVIDER && (
          <>
            <FormField
              control={form.control}
              name="businessName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Business Name</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="category"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Category</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Description</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      placeholder="Describe your services..."
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="address"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Address</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </>
        )}
        
        {/* Shelter specific fields */}
        {userProfile.userType === UserType.SHELTER && (
          <>
            <FormField
              control={form.control}
              name="organizationName"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Organization Name</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="mission"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Mission</FormLabel>
                  <FormControl>
                    <Textarea 
                      {...field} 
                      placeholder="Describe your organization's mission..."
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="phone"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Phone</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="address"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Address</FormLabel>
                  <FormControl>
                    <Input {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </>
        )}
        
        <div className="flex justify-end">
          <Button type="submit" disabled={mutation.isPending}>
            {mutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Save Changes
          </Button>
        </div>
      </form>
    </Form>
  );
}