import { Link } from "wouter";
import { PawPrint, Facebook, Twitter, Instagram, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export default function Footer() {
  return (
    <footer className="bg-neutral-800 text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          <div>
            <div className="flex items-center mb-4">
              <PawPrint className="text-primary text-3xl mr-2" />
              <span className="font-heading font-bold text-2xl">PetPal</span>
            </div>
            <p className="text-neutral-300 mb-6">
              The complete platform for pet care, adoption, and resources - connecting pets, owners, and service providers.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-neutral-300 hover:text-primary transition">
                <Facebook />
              </a>
              <a href="#" className="text-neutral-300 hover:text-primary transition">
                <Twitter />
              </a>
              <a href="#" className="text-neutral-300 hover:text-primary transition">
                <Instagram />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="font-heading font-bold text-lg mb-4">For Pet Owners</h3>
            <ul className="space-y-2">
              <li><Link href="/services" className="text-neutral-300 hover:text-white transition">Find Services</Link></li>
              <li><Link href="/adopt" className="text-neutral-300 hover:text-white transition">Adopt a Pet</Link></li>
              <li><Link href="/resources" className="text-neutral-300 hover:text-white transition">Pet Care Resources</Link></li>
              <li><Link href="/emergency" className="text-neutral-300 hover:text-white transition">Emergency Services</Link></li>
              <li><Link href="/community" className="text-neutral-300 hover:text-white transition">Community Forums</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-heading font-bold text-lg mb-4">For Businesses</h3>
            <ul className="space-y-2">
              <li><Link href="/providers" className="text-neutral-300 hover:text-white transition">List Your Services</Link></li>
              <li><Link href="/business-plans" className="text-neutral-300 hover:text-white transition">Business Plans</Link></li>
              <li><Link href="/marketing" className="text-neutral-300 hover:text-white transition">Marketing Tools</Link></li>
              <li><Link href="/success-stories" className="text-neutral-300 hover:text-white transition">Success Stories</Link></li>
              <li><Link href="/support" className="text-neutral-300 hover:text-white transition">Support Center</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-heading font-bold text-lg mb-4">Shelters & Rescues</h3>
            <ul className="space-y-2">
              <li><Link href="/partnerships" className="text-neutral-300 hover:text-white transition">Partnership Program</Link></li>
              <li><Link href="/adoption-management" className="text-neutral-300 hover:text-white transition">Adoption Management</Link></li>
              <li><Link href="/donations" className="text-neutral-300 hover:text-white transition">Donation Tools</Link></li>
              <li><Link href="/volunteer" className="text-neutral-300 hover:text-white transition">Volunteer Connections</Link></li>
              <li><Link href="/shelter-resources" className="text-neutral-300 hover:text-white transition">Resources & Support</Link></li>
            </ul>
          </div>
        </div>
        
        {/* Newsletter */}
        <div className="max-w-md mx-auto text-center mb-12">
          <h3 className="font-heading font-bold text-xl mb-4">Stay Updated</h3>
          <p className="text-neutral-300 mb-4">Subscribe to our newsletter for pet care tips, updates, and special offers.</p>
          <div className="flex">
            <Input 
              type="email" 
              placeholder="Your email address" 
              className="flex-grow rounded-l-lg focus:outline-none focus:ring-2 focus:ring-primary bg-neutral-700 text-white border-none"
            />
            <Button className="bg-primary hover:bg-primary-dark text-white font-heading font-semibold rounded-r-lg">
              Subscribe
            </Button>
          </div>
        </div>
        
        <div className="border-t border-neutral-700 pt-6 text-sm text-neutral-400">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="flex flex-wrap justify-center md:justify-start gap-4">
              <Link href="/terms" className="hover:text-neutral-300 transition">Terms of Service</Link>
              <Link href="/privacy" className="hover:text-neutral-300 transition">Privacy Policy</Link>
              <Link href="/cookies" className="hover:text-neutral-300 transition">Cookie Policy</Link>
              <Link href="/accessibility" className="hover:text-neutral-300 transition">Accessibility</Link>
            </div>
            <div>
              © 2023 PetPal. All rights reserved.
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
