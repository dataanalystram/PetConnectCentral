import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  PawPrint,
  Menu,
  Search,
  MapPin,
  LogIn,
  LogOut,
  User as UserIcon,
  ChevronDown
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function Header() {
  const [location] = useLocation();
  const { currentUser, userProfile, logout } = useAuth();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = async () => {
    try {
      await logout();
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-white shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between py-3">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center group">
              <PawPrint className="h-7 w-7 text-primary mr-2 group-hover:animate-bounce-subtle transition-all duration-300" />
              <span className="font-heading font-bold text-2xl text-primary-dark group-hover:text-primary transition-colors duration-300">PetPal</span>
            </Link>
          </div>
          
          {/* Main Navigation - Desktop */}
          <nav className="hidden md:flex items-center space-x-8">
            <NavLink href="/services" active={location === "/services"}>Find Services</NavLink>
            <NavLink href="/adopt" active={location === "/adopt"}>Adopt</NavLink>
            <NavLink href="/resources" active={location === "/resources"}>Resources</NavLink>
            <NavLink href="/providers" active={location === "/providers"}>Become a Provider</NavLink>
          </nav>
          
          {/* User Actions */}
          <div className="flex items-center space-x-4">
            <div className="hidden md:flex items-center text-neutral-500 bg-neutral-50 hover:bg-neutral-100 rounded-full px-3 py-1 cursor-pointer transition-all duration-300 group">
              <MapPin className="h-4 w-4 mr-1 text-primary animate-pulse group-hover:animate-none" />
              <span className="text-sm">Berlin, DE</span>
            </div>
            
            {currentUser ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" size="sm" className="rounded-full">
                    <UserIcon className="h-4 w-4 mr-2" />
                    {currentUser.displayName?.split(' ')[0] || currentUser.email?.split('@')[0]}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>Profile</DropdownMenuItem>
                  <DropdownMenuItem>Dashboard</DropdownMenuItem>
                  <DropdownMenuItem>Settings</DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={handleLogout}>
                    <LogOut className="h-4 w-4 mr-2" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button 
                asChild 
                className="hidden md:flex bg-primary hover:bg-primary-dark text-white font-heading font-semibold rounded-full"
              >
                <Link href="/auth">
                  <LogIn className="h-4 w-4 mr-2" />
                  Sign In
                </Link>
              </Button>
            )}
            
            <Button 
              variant="ghost" 
              size="icon" 
              className="md:hidden"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              <Menu className="h-6 w-6 text-neutral-600" />
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white shadow-md p-4">
          <nav className="flex flex-col space-y-4">
            <MobileNavLink href="/services" active={location === "/services"}>Find Services</MobileNavLink>
            <MobileNavLink href="/adopt" active={location === "/adopt"}>Adopt</MobileNavLink>
            <MobileNavLink href="/resources" active={location === "/resources"}>Resources</MobileNavLink>
            <MobileNavLink href="/providers" active={location === "/providers"}>Become a Provider</MobileNavLink>
            <div className="flex items-center text-neutral-500 py-1 rounded-full px-3 bg-neutral-50 cursor-pointer">
              <MapPin className="h-4 w-4 mr-1 text-primary animate-pulse" />
              <span className="text-sm">Berlin, DE</span>
            </div>
            {!currentUser && (
              <Button 
                asChild 
                className="bg-primary hover:bg-primary-dark text-white font-heading font-semibold rounded-full w-full"
              >
                <Link href="/auth">
                  <LogIn className="h-4 w-4 mr-2" />
                  Sign In
                </Link>
              </Button>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}

function NavLink({ href, active, children }: { href: string; active: boolean; children: React.ReactNode }) {
  const [isHovered, setIsHovered] = useState(false);
  const hasDropdown = href === "/services" || href === "/adopt" || href === "/resources";
  
  return (
    <div 
      className="relative group"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <Link 
        href={href} 
        className={`font-heading font-semibold ${active ? 'text-primary' : 'text-primary-dark hover:text-primary'} transition-all duration-300 flex items-center`}
      >
        {children}
        {hasDropdown && <ChevronDown className={`ml-1 h-4 w-4 transition-transform duration-300 ${isHovered ? 'rotate-180' : ''}`} />}
      </Link>
      
      {hasDropdown && isHovered && (
        <div className="absolute top-full left-0 mt-1 bg-white shadow-lg rounded-lg py-2 px-4 min-w-[200px] z-50 transform opacity-0 group-hover:opacity-100 transition-all duration-300 ease-out">
          {href === "/services" && (
            <>
              <Link href="/services/veterinary" className="block py-2 text-primary-dark hover:text-primary transition-colors">Veterinary Services</Link>
              <Link href="/services/grooming" className="block py-2 text-primary-dark hover:text-primary transition-colors">Grooming</Link>
              <Link href="/services/training" className="block py-2 text-primary-dark hover:text-primary transition-colors">Training</Link>
              <Link href="/services/sitting" className="block py-2 text-primary-dark hover:text-primary transition-colors">Pet Sitting & Walking</Link>
              <Link href="/services/boarding" className="block py-2 text-primary-dark hover:text-primary transition-colors">Boarding</Link>
              <Link href="/services/retail" className="block py-2 text-primary-dark hover:text-primary transition-colors">Retail & Supplies</Link>
            </>
          )}
          
          {href === "/adopt" && (
            <>
              <Link href="/adopt/dogs" className="block py-2 text-primary-dark hover:text-primary transition-colors">Dogs</Link>
              <Link href="/adopt/cats" className="block py-2 text-primary-dark hover:text-primary transition-colors">Cats</Link>
              <Link href="/adopt/small-pets" className="block py-2 text-primary-dark hover:text-primary transition-colors">Small Pets</Link>
              <Link href="/adopt/shelters" className="block py-2 text-primary-dark hover:text-primary transition-colors">Find Shelters</Link>
              <Link href="/adopt/success-stories" className="block py-2 text-primary-dark hover:text-primary transition-colors">Success Stories</Link>
            </>
          )}
          
          {href === "/resources" && (
            <>
              <Link href="/resources/articles" className="block py-2 text-primary-dark hover:text-primary transition-colors">Articles & Guides</Link>
              <Link href="/resources/videos" className="block py-2 text-primary-dark hover:text-primary transition-colors">Training Videos</Link>
              <Link href="/resources/faqs" className="block py-2 text-primary-dark hover:text-primary transition-colors">FAQs</Link>
              <Link href="/resources/community" className="block py-2 text-primary-dark hover:text-primary transition-colors">Community Forum</Link>
            </>
          )}
        </div>
      )}
    </div>
  );
}

function MobileNavLink({ href, active, children }: { href: string; active: boolean; children: React.ReactNode }) {
  const [isExpanded, setIsExpanded] = useState(false);
  const hasDropdown = href === "/services" || href === "/adopt" || href === "/resources";
  
  return (
    <div className="space-y-2">
      <div className="flex justify-between items-center">
        <Link href={href} className={`font-heading font-semibold text-lg ${active ? 'text-primary' : 'text-primary-dark'}`}>
          {children}
        </Link>
        {hasDropdown && (
          <Button 
            variant="ghost" 
            size="sm" 
            className="p-1" 
            onClick={(e) => { 
              e.preventDefault();
              setIsExpanded(!isExpanded);
            }}
          >
            <ChevronDown className={`h-4 w-4 transition-transform duration-300 ${isExpanded ? 'rotate-180' : ''}`} />
          </Button>
        )}
      </div>
      
      {hasDropdown && isExpanded && (
        <div className="pl-4 border-l-2 border-primary-light space-y-2 py-2 animate-fadeIn">
          {href === "/services" && (
            <>
              <Link href="/services/veterinary" className="block text-primary-dark hover:text-primary text-sm transition-colors">Veterinary Services</Link>
              <Link href="/services/grooming" className="block text-primary-dark hover:text-primary text-sm transition-colors">Grooming</Link>
              <Link href="/services/training" className="block text-primary-dark hover:text-primary text-sm transition-colors">Training</Link>
              <Link href="/services/sitting" className="block text-primary-dark hover:text-primary text-sm transition-colors">Pet Sitting & Walking</Link>
              <Link href="/services/boarding" className="block text-primary-dark hover:text-primary text-sm transition-colors">Boarding</Link>
              <Link href="/services/retail" className="block text-primary-dark hover:text-primary text-sm transition-colors">Retail & Supplies</Link>
            </>
          )}
          
          {href === "/adopt" && (
            <>
              <Link href="/adopt/dogs" className="block text-primary-dark hover:text-primary text-sm transition-colors">Dogs</Link>
              <Link href="/adopt/cats" className="block text-primary-dark hover:text-primary text-sm transition-colors">Cats</Link>
              <Link href="/adopt/small-pets" className="block text-primary-dark hover:text-primary text-sm transition-colors">Small Pets</Link>
              <Link href="/adopt/shelters" className="block text-primary-dark hover:text-primary text-sm transition-colors">Find Shelters</Link>
              <Link href="/adopt/success-stories" className="block text-primary-dark hover:text-primary text-sm transition-colors">Success Stories</Link>
            </>
          )}
          
          {href === "/resources" && (
            <>
              <Link href="/resources/articles" className="block text-primary-dark hover:text-primary text-sm transition-colors">Articles & Guides</Link>
              <Link href="/resources/videos" className="block text-primary-dark hover:text-primary text-sm transition-colors">Training Videos</Link>
              <Link href="/resources/faqs" className="block text-primary-dark hover:text-primary text-sm transition-colors">FAQs</Link>
              <Link href="/resources/community" className="block text-primary-dark hover:text-primary text-sm transition-colors">Community Forum</Link>
            </>
          )}
        </div>
      )}
    </div>
  );
}
