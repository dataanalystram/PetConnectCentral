import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { 
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle, 
} from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/contexts/AuthContext";
import { Loader2, AlertTriangle, Info } from "lucide-react";

export function AccountDeletion() {
  const { toast } = useToast();
  const { logoutMutation } = useAuth();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("deactivate");

  const handleDeactivateAccount = async () => {
    setIsLoading(true);
    try {
      const response = await apiRequest("POST", "/api/user/deactivate", {});
      
      if (!response.ok) {
        throw new Error("Failed to deactivate account");
      }
      
      toast({
        title: "Account Deactivated",
        description: "Your account has been deactivated. You can reactivate it by signing in again.",
      });
      
      // Log the user out
      await logoutMutation.mutateAsync();
      
      // Close the dialog
      setIsDialogOpen(false);
    } catch (error) {
      console.error("Error deactivating account:", error);
      toast({
        title: "Error",
        description: "There was a problem deactivating your account. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteAccount = async () => {
    setIsLoading(true);
    try {
      const response = await apiRequest("DELETE", "/api/user", {});
      
      if (!response.ok) {
        throw new Error("Failed to delete account");
      }
      
      toast({
        title: "Account Deleted",
        description: "Your account and all associated data have been permanently deleted.",
      });
      
      // Log the user out
      await logoutMutation.mutateAsync();
      
      // Close the dialog
      setIsDialogOpen(false);
    } catch (error) {
      console.error("Error deleting account:", error);
      toast({
        title: "Error",
        description: "There was a problem deleting your account. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-medium">Manage Account</h3>
      <p className="text-muted-foreground text-sm">
        Options for deactivating or permanently deleting your account
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Option 1: Deactivate Account (Temporary) */}
        <Card className="border-blue-200">
          <CardHeader className="bg-blue-50 border-b border-blue-200">
            <div className="flex items-start gap-2">
              <Info className="h-5 w-5 text-blue-500 shrink-0 mt-1" />
              <div>
                <CardTitle className="text-lg">Temporarily Deactivate</CardTitle>
                <CardDescription>Hide your profile temporarily</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="space-y-4">
              <div className="text-sm text-muted-foreground">
                <ul className="space-y-2 list-disc list-inside">
                  <li>Your profile will be hidden from other users</li>
                  <li>You can reactivate by logging in again</li>
                  <li>Your data will be preserved according to our data retention policies</li>
                  <li>All your pets, appointments, and settings will be maintained</li>
                </ul>
              </div>
              
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" className="w-full mt-2">Deactivate My Account</Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Confirm Deactivation</AlertDialogTitle>
                    <AlertDialogDescription>
                      Your account will be deactivated and hidden from other users.
                      You can reactivate it at any time by logging in again.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDeactivateAccount} disabled={isLoading}>
                      {isLoading ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : null}
                      Deactivate
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </CardContent>
        </Card>
        
        {/* Option 2: Permanently Delete Account (GDPR Right to Erasure) */}
        <Card className="border-red-200">
          <CardHeader className="bg-red-50 border-b border-red-200">
            <div className="flex items-start gap-2">
              <AlertTriangle className="h-5 w-5 text-red-500 shrink-0 mt-1" />
              <div>
                <CardTitle className="text-lg">Permanently Delete</CardTitle>
                <CardDescription>GDPR Right to Erasure (Irreversible)</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="space-y-4">
              <div className="text-sm text-muted-foreground">
                <ul className="space-y-2 list-disc list-inside">
                  <li>Your account and all data will be permanently deleted</li>
                  <li>This action is irreversible - no way to recover your data</li>
                  <li>Deletion will be processed within 30 days as per GDPR</li>
                  <li>All pets, appointments, settings, and history will be erased</li>
                </ul>
              </div>
              
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" className="w-full mt-2">Permanently Delete My Account</Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Confirm Permanent Deletion</AlertDialogTitle>
                    <AlertDialogDescription>
                      <p className="mb-2">This action will permanently delete your account and all data associated with it in accordance with GDPR Right to Erasure.</p>
                      <p className="mb-2">This action CANNOT be undone, and you will lose all your data including:</p>
                      <ul className="list-disc pl-5 mb-2">
                        <li>Your profile information</li>
                        <li>Pets and their records</li>
                        <li>Appointments and history</li>
                        <li>Preferences and settings</li>
                        <li>All other user data</li>
                      </ul>
                      <p className="font-semibold">Are you absolutely sure you want to proceed?</p>
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDeleteAccount} className="bg-red-500 hover:bg-red-600" disabled={isLoading}>
                      {isLoading ? (
                        <Loader2 className="h-4 w-4 animate-spin mr-2" />
                      ) : null}
                      Permanently Delete
                    </AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}