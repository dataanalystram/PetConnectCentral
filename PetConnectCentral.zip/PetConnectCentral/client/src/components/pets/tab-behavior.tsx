import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle } from "lucide-react";

interface BehaviorTabProps {
  pet: any;
}

export default function BehaviorTab({ pet }: BehaviorTabProps) {
  return (
    <div className="space-y-6 pt-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Behavior Profile</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-1">
                  <span>Energy Level</span>
                  <span className="font-semibold">
                    {pet.behavior?.energy ? pet.behavior.energy + "/5" : "N/A"}
                  </span>
                </div>
                <Progress 
                  value={pet.behavior?.energy ? (pet.behavior.energy / 5) * 100 : 0} 
                  className="h-2" 
                />
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Sociability</span>
                  <span className="font-semibold">
                    {pet.behavior?.sociability ? pet.behavior.sociability + "/5" : "N/A"}
                  </span>
                </div>
                <Progress 
                  value={pet.behavior?.sociability ? (pet.behavior.sociability / 5) * 100 : 0} 
                  className="h-2" 
                />
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Independence</span>
                  <span className="font-semibold">
                    {pet.behavior?.independence ? pet.behavior.independence + "/5" : "N/A"}
                  </span>
                </div>
                <Progress 
                  value={pet.behavior?.independence ? (pet.behavior.independence / 5) * 100 : 0} 
                  className="h-2" 
                />
              </div>
            </div>
            <div className="space-y-4">
              <div>
                <div className="flex justify-between mb-1">
                  <span>Vocalization</span>
                  <span className="font-semibold">
                    {pet.behavior?.vocalization ? pet.behavior.vocalization + "/5" : "N/A"}
                  </span>
                </div>
                <Progress 
                  value={pet.behavior?.vocalization ? (pet.behavior.vocalization / 5) * 100 : 0} 
                  className="h-2" 
                />
              </div>
              <div>
                <div className="flex justify-between mb-1">
                  <span>Trainability</span>
                  <span className="font-semibold">
                    {pet.behavior?.training ? pet.behavior.training + "/5" : "N/A"}
                  </span>
                </div>
                <Progress 
                  value={pet.behavior?.training ? (pet.behavior.training / 5) * 100 : 0} 
                  className="h-2" 
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Training Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex items-center p-3 bg-muted rounded-lg">
              <CheckCircle className={`h-5 w-5 mr-3 ${pet.training?.isHousetrained ? "text-green-500" : "text-gray-300"}`} />
              <span>Housetrained</span>
            </div>
            <div className="flex items-center p-3 bg-muted rounded-lg">
              <CheckCircle className={`h-5 w-5 mr-3 ${pet.training?.knowsBasicCommands ? "text-green-500" : "text-gray-300"}`} />
              <span>Basic Commands</span>
            </div>
            <div className="flex items-center p-3 bg-muted rounded-lg">
              <CheckCircle className={`h-5 w-5 mr-3 ${pet.training?.isLeashTrained ? "text-green-500" : "text-gray-300"}`} />
              <span>Leash Trained</span>
            </div>
            <div className="flex items-center p-3 bg-muted rounded-lg">
              <CheckCircle className={`h-5 w-5 mr-3 ${pet.training?.advancedTraining ? "text-green-500" : "text-gray-300"}`} />
              <span>Advanced Training</span>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Compatibility</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="flex flex-col items-center justify-center p-4 bg-muted rounded-lg">
              <span className="text-3xl mb-2">👶</span>
              <span className="text-sm font-medium">Children</span>
              <span className="text-xs text-muted-foreground">{pet.compatibility?.goodWithChildren ? "Good" : "Not Recommended"}</span>
            </div>
            <div className="flex flex-col items-center justify-center p-4 bg-muted rounded-lg">
              <span className="text-3xl mb-2">🐕</span>
              <span className="text-sm font-medium">Dogs</span>
              <span className="text-xs text-muted-foreground">{pet.compatibility?.goodWithDogs ? "Good" : "Not Recommended"}</span>
            </div>
            <div className="flex flex-col items-center justify-center p-4 bg-muted rounded-lg">
              <span className="text-3xl mb-2">🐈</span>
              <span className="text-sm font-medium">Cats</span>
              <span className="text-xs text-muted-foreground">{pet.compatibility?.goodWithCats ? "Good" : "Not Recommended"}</span>
            </div>
            <div className="flex flex-col items-center justify-center p-4 bg-muted rounded-lg">
              <span className="text-3xl mb-2">🏢</span>
              <span className="text-sm font-medium">Apartment</span>
              <span className="text-xs text-muted-foreground">
                {pet.compatibility?.apartmentFriendly ? 
                  pet.compatibility?.apartmentFriendly + "/5" : 
                  "N/A"
                }
              </span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}