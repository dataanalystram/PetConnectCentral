import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { FileText, Shield, Download, Upload } from "lucide-react";

interface DocumentsTabProps {
  pet: any;
}

export default function DocumentsTab({ pet }: DocumentsTabProps) {
  const { toast } = useToast();
  
  const handleUploadDocument = () => {
    toast({
      title: "Coming soon",
      description: "Document upload functionality will be available soon!",
    });
  };
  
  return (
    <div className="space-y-6 pt-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Pet Documents</h3>
        <Button variant="outline" size="sm" onClick={handleUploadDocument}>
          <Upload className="h-4 w-4 mr-2" />
          Upload Document
        </Button>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Medical Records</CardTitle>
        </CardHeader>
        <CardContent>
          {pet.healthStatus?.medicalRecords && pet.healthStatus.medicalRecords.length > 0 ? (
            <div className="space-y-4">
              {pet.healthStatus.medicalRecords.map((record: any, index: number) => (
                <div key={index} className="flex items-start justify-between p-4 border rounded-lg">
                  <div className="flex items-start">
                    <FileText className="h-5 w-5 mr-3 text-primary mt-1" />
                    <div>
                      <h4 className="font-medium">{record.title}</h4>
                      <p className="text-sm text-muted-foreground">{new Date(record.date).toLocaleDateString()}</p>
                      <p className="text-sm mt-1">{record.notes}</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>No medical records uploaded yet</p>
              <Button variant="link" size="sm" onClick={handleUploadDocument}>
                Upload Medical Records
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Vaccination Certificates</CardTitle>
        </CardHeader>
        <CardContent>
          {pet.healthStatus?.vaccinations && pet.healthStatus.vaccinations.length > 0 ? (
            <div className="space-y-4">
              {pet.healthStatus.vaccinations.map((vaccination: any, index: number) => (
                <div key={index} className="flex items-start justify-between p-4 border rounded-lg">
                  <div className="flex items-start">
                    <Shield className="h-5 w-5 mr-3 text-primary mt-1" />
                    <div>
                      <h4 className="font-medium">{vaccination.name} Certificate</h4>
                      <p className="text-sm text-muted-foreground">
                        Administered: {new Date(vaccination.date).toLocaleDateString()}
                      </p>
                      <p className="text-sm mt-1">Next Due: {new Date(vaccination.dueDate).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="icon">
                    <Download className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <Shield className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>No vaccination certificates uploaded yet</p>
              <Button variant="link" size="sm" onClick={handleUploadDocument}>
                Upload Vaccination Certificates
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Other Documents</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
            <p>No additional documents uploaded yet</p>
            <Button variant="link" size="sm" onClick={handleUploadDocument}>
              Upload Documents
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}