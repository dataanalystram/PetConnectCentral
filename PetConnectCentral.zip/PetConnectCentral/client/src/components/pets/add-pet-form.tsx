import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/contexts/AuthContext";
import { useLocation } from "wouter";
import { Pet, UserType } from "@shared/schema";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { petTypes, petBreeds } from "@/data/pets";
import { Plus, Loader2, Image, Upload, Info, AlertTriangle } from "lucide-react";
import { TagInput } from "@/components/ui/tag-input";

// Form schema
const petFormSchema = z.object({
  name: z.string().min(1, "Pet name is required"),
  type: z.string().min(1, "Pet type is required"),
  breed: z.string().min(1, "Breed is required"),
  age: z.coerce.number().min(0, "Age must be a positive number"),
  gender: z.string().min(1, "Gender is required"),
  size: z.string().min(1, "Size is required"),
  color: z.string().min(1, "Color is required"),
  weight: z.string().min(1, "Weight is required"),
  description: z.string().min(10, "Please provide a description of at least 10 characters"),
  notes: z.string().optional(), // Added notes field shown in pet detail page
  adoptionFee: z.coerce.number().optional(), // Added from database schema
  isAdopted: z.boolean().optional().default(false), // Added from database schema
  isFeatured: z.boolean().optional().default(false), // Added from database schema
  healthStatus: z.object({
    isVaccinated: z.boolean().default(false),
    isNeutered: z.boolean().default(false),
    isMicrochipped: z.boolean().default(false),
    hasSpecialNeeds: z.boolean().default(false),
    specialNeedsDescription: z.string().optional(),
    lastCheckup: z.string().optional(), // Added to match detail view
    medications: z.array(z.string()).optional().default([]), // Added to match detail view
    allergies: z.array(z.string()).optional().default([]), // Added to match detail view
  }),
  compatibility: z.object({
    goodWithChildren: z.boolean().default(false),
    goodWithDogs: z.boolean().default(false),
    goodWithCats: z.boolean().default(false),
    goodWithOtherPets: z.boolean().default(false),
    apartmentFriendly: z.coerce.number().min(1).max(5).optional(), // Added to match detail view
  }),
  training: z.object({
    isHousetrained: z.boolean().default(false),
    knowsBasicCommands: z.boolean().default(false),
    isLeashTrained: z.boolean().default(false),
    advancedTraining: z.boolean().default(false), // Added to match detail view
  }),
  activityLevel: z.string().min(1, "Activity level is required"),
  background: z.string().optional(), 
  behavior: z.object({ // Added to match detail view
    energy: z.coerce.number().min(1).max(5).optional(),
    sociability: z.coerce.number().min(1).max(5).optional(),
    independence: z.coerce.number().min(1).max(5).optional(),
    vocalization: z.coerce.number().min(1).max(5).optional(),
    training: z.coerce.number().min(1).max(5).optional()
  }).optional().default({}),
  diet: z.object({ // Added to match detail view
    foodType: z.string().optional(),
    specialDiet: z.boolean().default(false),
    feedingSchedule: z.string().optional(),
    treats: z.string().optional()
  }).optional().default({}),
  care: z.object({ // Added to match detail view
    grooming: z.string().optional(),
    exercise: z.string().optional(),
    activities: z.array(z.string()).optional().default([])
  }).optional().default({})
});

type PetFormValues = z.infer<typeof petFormSchema>;

interface AddPetFormProps {
  isEditMode?: boolean;
  petId?: number;
  initialData?: any;
}

export default function AddPetForm({ isEditMode = false, petId, initialData }: AddPetFormProps) {
  const { toast } = useToast();
  const { userProfile } = useAuth();
  const [, navigate] = useLocation();
  const [currentTab, setCurrentTab] = useState("basic");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [files, setFiles] = useState<File[]>([]);

  // Set default values based on initialData if in edit mode
  const form = useForm<PetFormValues>({
    resolver: zodResolver(petFormSchema),
    defaultValues: {
      name: initialData?.name || "",
      type: initialData?.type || "",
      breed: initialData?.breed || "",
      age: initialData?.age || 0,
      gender: initialData?.gender || "",
      size: initialData?.size || "",
      color: initialData?.color || "",
      weight: initialData?.weight || "",
      description: initialData?.description || "",
      notes: initialData?.notes || "",
      adoptionFee: initialData?.adoptionFee || undefined,
      isAdopted: initialData?.isAdopted || false,
      isFeatured: initialData?.isFeatured || false,
      healthStatus: {
        isVaccinated: initialData?.isVaccinated === true,
        isNeutered: initialData?.isNeutered === true,
        isMicrochipped: initialData?.isMicrochipped === true,
        hasSpecialNeeds: initialData?.healthStatus?.hasSpecialNeeds === true || false,
        specialNeedsDescription: initialData?.healthStatus?.specialNeedsDescription || "",
        lastCheckup: initialData?.healthStatus?.lastCheckup || "",
        medications: initialData?.healthStatus?.medications || [],
        allergies: initialData?.healthStatus?.allergies || [],
      },
      compatibility: {
        goodWithChildren: initialData?.compatibility?.goodWithChildren === true || initialData?.goodWith?.includes("children") || false,
        goodWithDogs: initialData?.compatibility?.goodWithDogs === true || initialData?.goodWith?.includes("dogs") || false,
        goodWithCats: initialData?.compatibility?.goodWithCats === true || initialData?.goodWith?.includes("cats") || false,
        goodWithOtherPets: initialData?.compatibility?.goodWithOtherPets === true || initialData?.goodWith?.includes("other pets") || false,
        apartmentFriendly: initialData?.compatibility?.apartmentFriendly || undefined,
      },
      training: {
        isHousetrained: initialData?.training?.isHousetrained === true || initialData?.personality?.includes("housetrained") || false,
        knowsBasicCommands: initialData?.training?.knowsBasicCommands === true || initialData?.personality?.includes("trained") || false,
        isLeashTrained: initialData?.training?.isLeashTrained === true || false,
        advancedTraining: initialData?.training?.advancedTraining === true || false,
      },
      activityLevel: initialData?.activityLevel || "",
      background: initialData?.background || "",
      behavior: {
        energy: initialData?.behavior?.energy || undefined,
        sociability: initialData?.behavior?.sociability || undefined,
        independence: initialData?.behavior?.independence || undefined,
        vocalization: initialData?.behavior?.vocalization || undefined,
        training: initialData?.behavior?.training || undefined,
      },
      diet: {
        foodType: initialData?.diet?.foodType || "",
        specialDiet: initialData?.diet?.specialDiet === true || false,
        feedingSchedule: initialData?.diet?.feedingSchedule || "",
        treats: initialData?.diet?.treats || "",
      },
      care: {
        grooming: initialData?.care?.grooming || "",
        exercise: initialData?.care?.exercise || "",
        activities: initialData?.care?.activities || [],
      },
    },
  });

  const petType = form.watch("type");

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setFiles(prevFiles => [...prevFiles, ...newFiles]);
      
      // Make sure the "photos" tab is selected when files are added
      setCurrentTab("photos");
    }
  };

  const removeFile = (index: number) => {
    setFiles(prevFiles => prevFiles.filter((_, i) => i !== index));
  };

  // Function to upload an image and return its URL
  const uploadImage = async (file: File): Promise<string> => {
    const formData = new FormData();
    formData.append('image', file);
    
    try {
      // Get the Firebase token for authentication from localStorage
      // This is set in AuthContext when a user logs in
      const authHeader = localStorage.getItem('firebaseToken');
      
      const headers: HeadersInit = {};
      if (authHeader) {
        headers['Authorization'] = `Bearer ${authHeader}`;
      }
      
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
        headers,
        credentials: 'include',
      });
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const errorMessage = errorData.error || 'Failed to upload image';
        throw new Error(errorMessage);
      }
      
      const data = await response.json();
      return data.imageUrl;
    } catch (error) {
      console.error('Error uploading image:', error);
      throw error;
    }
  };

  const onSubmit = async (data: PetFormValues) => {
    if (!userProfile) {
      toast({
        title: "Error",
        description: "You must be logged in to add or edit a pet",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      let mainImageUrl = initialData?.mainImageUrl || null;
      let imageUrls: string[] = initialData?.imageUrls || [];
      
      // Upload images if files exist
      if (files.length > 0) {
        try {
          // Upload the first image as the main image
          mainImageUrl = await uploadImage(files[0]);
          
          // Upload all images and collect their URLs
          const uploadPromises = files.map(file => uploadImage(file));
          imageUrls = await Promise.all(uploadPromises);
        } catch (uploadError) {
          console.error("Error uploading images:", uploadError);
          toast({
            title: "Error uploading images",
            description: "There was a problem uploading your images. Your pet info will be saved without images.",
            variant: "destructive",
          });
        }
      }
      
      // Create pet payload with all the fields from our form
      const petPayload = {
        name: data.name,
        type: data.type,
        breed: data.breed,
        age: data.age,
        gender: data.gender,
        size: data.size,
        color: data.color,
        description: data.description,
        notes: data.notes,
        adoptionFee: data.adoptionFee,
        isAdopted: data.isAdopted,
        isFeatured: data.isFeatured,
        healthStatus: "Good", // General health status field
        isVaccinated: data.healthStatus.isVaccinated === true,
        isNeutered: data.healthStatus.isNeutered === true,
        isMicrochipped: data.healthStatus.isMicrochipped === true,
        personality: [
          data.healthStatus.hasSpecialNeeds ? "special needs" : "",
          data.training.isHousetrained ? "housetrained" : "",
          data.training.knowsBasicCommands ? "trained" : "",
          data.training.isLeashTrained ? "leash trained" : "",
          data.training.advancedTraining ? "advanced training" : "",
        ].filter(Boolean),
        goodWith: [
          data.compatibility.goodWithChildren ? "children" : "",
          data.compatibility.goodWithDogs ? "dogs" : "",
          data.compatibility.goodWithCats ? "cats" : "",
          data.compatibility.goodWithOtherPets ? "other pets" : "",
        ].filter(Boolean),
        activityLevel: data.activityLevel,
        imageUrls: imageUrls.length > 0 ? imageUrls : initialData?.imageUrls || [],
        mainImageUrl: mainImageUrl || initialData?.mainImageUrl || null,
        
        // Additional metadata for detailed pet profile
        metadata: {
          healthStatus: {
            lastCheckup: data.healthStatus.lastCheckup,
            medications: data.healthStatus.medications,
            allergies: data.healthStatus.allergies,
            specialNeedsDescription: data.healthStatus.specialNeedsDescription,
          },
          compatibility: {
            apartmentFriendly: data.compatibility.apartmentFriendly,
          },
          behavior: data.behavior,
          diet: data.diet,
          care: data.care,
          background: data.background,
        },
        
        // Let the server handle the shelterId and ownerId assignment based on user type
        // The server will properly set these fields based on the authenticated user's type
      };
      
      // Get the Firebase token for authentication from localStorage
      const authHeader = localStorage.getItem('firebaseToken');
      
      const headers: HeadersInit = {
        'Content-Type': 'application/json'
      };
      
      if (authHeader) {
        headers['Authorization'] = `Bearer ${authHeader}`;
      }
      
      let response;
      
      if (isEditMode && petId) {
        // Update existing pet
        response = await fetch(`/api/pets/${petId}`, {
          method: 'PUT',
          headers,
          body: JSON.stringify(petPayload),
          credentials: 'include',
        });
        
        if (!response.ok) {
          const data = await response.json().catch(() => ({}));
          throw new Error(data.error || "Failed to update pet");
        }
        
        // Invalidate relevant queries to update the UI
        queryClient.invalidateQueries({ queryKey: ["/api/pets"] });
        queryClient.invalidateQueries({ queryKey: ["/api/pets", petId] });
        queryClient.invalidateQueries({ queryKey: ["/api/pets/recommended"] });
        
        toast({
          title: "Success!",
          description: `${data.name} has been updated successfully`,
        });
      } else {
        // Create new pet
        response = await fetch("/api/pets", {
          method: 'POST',
          headers,
          body: JSON.stringify(petPayload),
          credentials: 'include',
        });
        
        if (!response.ok) {
          const data = await response.json().catch(() => ({}));
          throw new Error(data.error || "Failed to add pet");
        }
        
        // Invalidate relevant queries to update the UI
        queryClient.invalidateQueries({ queryKey: ["/api/pets"] });
        queryClient.invalidateQueries({ queryKey: ["/api/pets/recommended"] });
        
        toast({
          title: "Success!",
          description: `${data.name} has been added successfully`,
        });
      }

      // Navigate to the dashboard after success
      navigate("/dashboard");
    } catch (error: any) {
      console.error("Error with pet operation:", error);
      toast({
        title: isEditMode ? "Error updating pet" : "Error adding pet",
        description: error.message || `There was an error ${isEditMode ? 'updating' : 'adding'} your pet. Please try again.`,
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const nextTab = () => {
    if (currentTab === "basic") setCurrentTab("health");
    else if (currentTab === "health") setCurrentTab("behavior");
    else if (currentTab === "behavior") setCurrentTab("photos");
  };

  const prevTab = () => {
    if (currentTab === "photos") setCurrentTab("behavior");
    else if (currentTab === "behavior") setCurrentTab("health");
    else if (currentTab === "health") setCurrentTab("basic");
  };

  const validateCurrentTab = async (): Promise<boolean> => {
    if (currentTab === "basic") {
      const result = await form.trigger(["name", "type", "breed", "age", "gender", "size", "color", "weight", "description"]);
      return result;
    } else if (currentTab === "health") {
      return true; // Health fields are optional
    } else if (currentTab === "behavior") {
      return true; // Behavior fields are optional
    }
    return true;
  };

  const handleNext = async () => {
    const isValid = await validateCurrentTab();
    if (isValid) nextTab();
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl font-bold">
              {isEditMode ? `Edit ${initialData?.name || 'Pet'}` : 'Add Your Pet'}
            </CardTitle>
            <CardDescription>
              {isEditMode 
                ? 'Update your pet information to keep records current.'
                : 'Tell us about your pet so we can provide the best care recommendations.'}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs value={currentTab} onValueChange={setCurrentTab} className="space-y-6">
              <TabsList className="grid grid-cols-4 w-full">
                <TabsTrigger value="basic">Basic Info</TabsTrigger>
                <TabsTrigger value="health">Health</TabsTrigger>
                <TabsTrigger value="behavior">Behavior & Training</TabsTrigger>
                <TabsTrigger value="photos">Photos</TabsTrigger>
              </TabsList>

              {/* Basic Info Tab */}
              <TabsContent value="basic" className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Pet Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Type</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select pet type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {petTypes.map((type) => (
                              <SelectItem key={type.value} value={type.value}>
                                {type.label}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="breed"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Breed</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                          disabled={!petType}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder={petType ? "Select breed" : "Select pet type first"} />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {petType && petBreeds[petType as keyof typeof petBreeds]?.map((breed) => (
                              <SelectItem key={breed} value={breed}>
                                {breed}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="age"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Age (Years)</FormLabel>
                        <FormControl>
                          <Input type="number" min="0" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="gender"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Gender</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select gender" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="male">Male</SelectItem>
                            <SelectItem value="female">Female</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="size"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Size</FormLabel>
                        <Select 
                          onValueChange={field.onChange} 
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select size" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="small">Small</SelectItem>
                            <SelectItem value="medium">Medium</SelectItem>
                            <SelectItem value="large">Large</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="color"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Color</FormLabel>
                        <FormControl>
                          <Input placeholder="Color" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="weight"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Weight</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., 15 kg" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="md:col-span-2">
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Tell us about your pet..." 
                              className="min-h-[120px]" 
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription>
                            Tell us about your pet's personality, habits, and what makes them special.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <FormField
                    control={form.control}
                    name="adoptionFee"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Adoption Fee</FormLabel>
                        <FormControl>
                          <Input 
                            type="number" 
                            min="0" 
                            placeholder="100"
                            {...field} 
                            value={field.value === undefined ? '' : field.value}
                            onChange={(e) => {
                              const value = e.target.value !== '' 
                                ? parseInt(e.target.value) 
                                : undefined;
                              field.onChange(value);
                            }}
                          />
                        </FormControl>
                        <FormDescription>Leave empty if not applicable</FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="md:col-span-2 space-y-4">
                    <div className="flex flex-col space-y-1.5">
                      <h3 className="text-sm font-medium">Pet Status</h3>
                      <p className="text-xs text-muted-foreground">Manage the status of this pet</p>
                    </div>
                    <div className="flex flex-row space-x-4">
                      <FormField
                        control={form.control}
                        name="isAdopted"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <FormLabel className="font-normal">
                              Mark as Adopted
                            </FormLabel>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="isFeatured"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <FormLabel className="font-normal">
                              Feature this Pet
                            </FormLabel>
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  
                  <div className="md:col-span-2">
                    <FormField
                      control={form.control}
                      name="notes"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Additional Notes</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Any additional notes about the pet..." 
                              className="min-h-[80px]" 
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription>
                            Add any extra information not covered in other sections
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              </TabsContent>

              {/* Health Tab */}
              <TabsContent value="health" className="space-y-6">
                <div className="grid gap-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="healthStatus.isVaccinated"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Vaccinated</FormLabel>
                            <FormDescription>
                              Has your pet received all required vaccinations?
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="healthStatus.isNeutered"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Neutered/Spayed</FormLabel>
                            <FormDescription>
                              Is your pet neutered or spayed?
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="healthStatus.isMicrochipped"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Microchipped</FormLabel>
                            <FormDescription>
                              Does your pet have a microchip?
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="healthStatus.hasSpecialNeeds"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Special Needs</FormLabel>
                            <FormDescription>
                              Does your pet have any special health needs or conditions?
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                  </div>

                  {form.watch("healthStatus.hasSpecialNeeds") && (
                    <FormField
                      control={form.control}
                      name="healthStatus.specialNeedsDescription"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Special Needs Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe any special health needs or conditions..." 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}
                  
                  <FormField
                    control={form.control}
                    name="healthStatus.lastCheckup"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Last Checkup</FormLabel>
                        <FormControl>
                          <Input 
                            type="date" 
                            {...field} 
                          />
                        </FormControl>
                        <FormDescription>
                          When was your pet's last veterinary checkup?
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <div className="md:col-span-2">
                    <div className="flex flex-col space-y-4">
                      <div>
                        <Label>Medications</Label>
                        <div className="mt-2">
                          <TagInput
                            placeholder="Enter medication and press Enter"
                            tags={form.watch("healthStatus.medications") || []}
                            setTags={(newTags: string[]) => form.setValue("healthStatus.medications", newTags)}
                            className="w-full"
                          />
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          Enter any medications your pet is currently taking
                        </p>
                      </div>
                      
                      <div>
                        <Label>Allergies</Label>
                        <div className="mt-2">
                          <TagInput
                            placeholder="Enter allergy and press Enter"
                            tags={form.watch("healthStatus.allergies") || []}
                            setTags={(newTags: string[]) => form.setValue("healthStatus.allergies", newTags)}
                            className="w-full"
                          />
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          List any known allergies your pet has
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              {/* Behavior & Training Tab */}
              <TabsContent value="behavior" className="space-y-6">
                <div className="space-y-6">
                  <h3 className="font-semibold text-lg">Compatibility</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="compatibility.goodWithChildren"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Good with Children</FormLabel>
                            <FormDescription>
                              Is your pet comfortable around children?
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="compatibility.goodWithDogs"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Good with Dogs</FormLabel>
                            <FormDescription>
                              Is your pet comfortable around other dogs?
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="compatibility.goodWithCats"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Good with Cats</FormLabel>
                            <FormDescription>
                              Is your pet comfortable around cats?
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="compatibility.goodWithOtherPets"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Good with Other Pets</FormLabel>
                            <FormDescription>
                              Is your pet comfortable around other small animals?
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                  </div>

                  <h3 className="font-semibold text-lg mt-6">Training</h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <FormField
                      control={form.control}
                      name="training.isHousetrained"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Housetrained</FormLabel>
                            <FormDescription>
                              Is your pet housetrained?
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="training.knowsBasicCommands"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Knows Basic Commands</FormLabel>
                            <FormDescription>
                              Does your pet respond to basic commands?
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="training.isLeashTrained"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>Leash Trained</FormLabel>
                            <FormDescription>
                              Is your pet trained to walk on a leash?
                            </FormDescription>
                          </div>
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="mt-6">
                    <FormField
                      control={form.control}
                      name="activityLevel"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Activity Level</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select activity level" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="low">Low - Couch Potato</SelectItem>
                              <SelectItem value="medium">Medium - Enjoys Regular Activity</SelectItem>
                              <SelectItem value="high">High - Very Active</SelectItem>
                              <SelectItem value="very-high">Very High - Extremely Energetic</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormDescription>
                            How much exercise does your pet need daily?
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Behavior ratings */}
                  <div className="mt-6 space-y-6">
                    <h3 className="font-semibold text-lg">Behavior Ratings</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="behavior.energy"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Energy Level (1-5)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min="1" 
                                max="5"
                                placeholder="3"
                                {...field} 
                                value={field.value === undefined ? '' : field.value}
                                onChange={(e) => {
                                  const value = e.target.value !== '' 
                                    ? parseInt(e.target.value) 
                                    : undefined;
                                  field.onChange(value);
                                }}
                              />
                            </FormControl>
                            <FormDescription>1 = Very Low, 5 = Very High</FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="behavior.sociability"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Sociability (1-5)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min="1" 
                                max="5"
                                placeholder="3"
                                {...field} 
                                value={field.value === undefined ? '' : field.value}
                                onChange={(e) => {
                                  const value = e.target.value !== '' 
                                    ? parseInt(e.target.value) 
                                    : undefined;
                                  field.onChange(value);
                                }}
                              />
                            </FormControl>
                            <FormDescription>1 = Very Shy, 5 = Very Social</FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="compatibility.apartmentFriendly"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Apartment Friendly (1-5)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min="1" 
                                max="5"
                                placeholder="3"
                                {...field} 
                                value={field.value === undefined ? '' : field.value}
                                onChange={(e) => {
                                  const value = e.target.value !== '' 
                                    ? parseInt(e.target.value) 
                                    : undefined;
                                  field.onChange(value);
                                }}
                              />
                            </FormControl>
                            <FormDescription>1 = Not Suitable, 5 = Very Suitable</FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                  
                  {/* Diet Information */}
                  <div className="mt-6 space-y-6">
                    <h3 className="font-semibold text-lg">Diet Information</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="diet.foodType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Food Type</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., Dry kibble, wet food, etc." {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="diet.specialDiet"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-center space-x-2 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <FormLabel className="font-normal">
                              Special Diet Requirements
                            </FormLabel>
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="diet.feedingSchedule"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Feeding Schedule</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., Twice daily, morning and evening" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  {/* Care Instructions */}
                  <div className="mt-6 space-y-6">
                    <h3 className="font-semibold text-lg">Care Instructions</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="care.grooming"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Grooming Needs</FormLabel>
                            <FormControl>
                              <Textarea placeholder="Describe grooming requirements" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="care.exercise"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Exercise Requirements</FormLabel>
                            <FormControl>
                              <Textarea placeholder="Describe exercise needs" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <div>
                      <Label>Favorite Activities</Label>
                      <div className="mt-2">
                        <TagInput
                          placeholder="Enter activity and press Enter"
                          tags={form.watch("care.activities") || []}
                          setTags={(newTags: string[]) => form.setValue("care.activities", newTags)}
                          className="w-full"
                        />
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">
                        Enter your pet's favorite activities or exercises
                      </p>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <FormField
                      control={form.control}
                      name="background"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Background Story (Optional)</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Share your pet's history or any additional information..." 
                              className="min-h-[120px]" 
                              {...field} 
                            />
                          </FormControl>
                          <FormDescription>
                            Share any additional information about your pet's background or history.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              </TabsContent>

              {/* Photos Tab */}
              <TabsContent value="photos" className="space-y-6">
                <div className="space-y-6">
                  <div className="border-2 border-dashed border-neutral-200 rounded-lg p-8 text-center">
                    <div className="flex flex-col items-center space-y-4">
                      <Image className="h-16 w-16 text-neutral-300" />
                      <div>
                        <h3 className="font-semibold text-lg">Upload Pet Photos</h3>
                        <p className="text-sm max-w-md mx-auto mt-1 text-neutral-500">
                          Photos are optional but recommended. The first photo will be used as the main profile picture.
                        </p>
                      </div>
                      <Button
                        variant="outline"
                        onClick={() => document.getElementById("pet-photos")?.click()}
                        type="button"
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        Browse Photos
                      </Button>
                      <input
                        id="pet-photos"
                        type="file"
                        multiple
                        accept="image/*"
                        className="hidden"
                        onChange={handleFileChange}
                      />
                    </div>
                  </div>

                  {files.length > 0 && (
                    <div className="space-y-4">
                      <h3 className="font-semibold text-lg">Selected Photos</h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {files.map((file, index) => (
                          <div key={index} className="relative group">
                            <div className="h-40 border rounded-lg overflow-hidden bg-neutral-50 flex items-center justify-center">
                              <img
                                src={URL.createObjectURL(file)}
                                alt={`Pet photo ${index + 1}`}
                                className="h-full w-full object-cover"
                              />
                            </div>
                            <Button
                              variant="destructive"
                              size="sm"
                              className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                              onClick={() => removeFile(index)}
                              type="button"
                            >
                              Remove
                            </Button>
                            {index === 0 && (
                              <div className="absolute bottom-2 left-2 bg-primary text-white text-xs px-2 py-1 rounded">
                                Main Photo
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start space-x-3 text-blue-800">
                    <Info className="h-5 w-5 flex-shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-semibold">Photo Tips</h4>
                      <ul className="text-sm mt-1 space-y-1 list-disc list-inside">
                        <li>Upload clear, well-lit photos that show your pet's appearance.</li>
                        <li>Include at least one photo that shows their face clearly.</li>
                        <li>Photos in natural settings often work best.</li>
                        <li>If possible, include photos showing your pet's size/scale.</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>

            <div className="flex justify-between mt-8">
              <Button
                type="button"
                variant="outline"
                onClick={prevTab}
                disabled={currentTab === "basic"}
              >
                Previous Step
              </Button>

              {currentTab !== "photos" ? (
                <Button type="button" onClick={handleNext}>
                  Next Step
                </Button>
              ) : (
                <Button 
                  type="submit" 
                  disabled={isSubmitting}
                  className="bg-primary hover:bg-primary/90"
                  size="lg"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      {files.length > 0 && <Image className="mr-2 h-4 w-4" />}
                      Save Pet Profile
                    </>
                  )}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </form>
    </Form>
  );
}