import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Camera } from "lucide-react";

interface GalleryTabProps {
  pet: any;
  petTypeColor: string;
}

export default function GalleryTab({ pet, petTypeColor }: GalleryTabProps) {
  const { toast } = useToast();
  
  const handleUploadPhotos = () => {
    toast({
      title: "Coming soon",
      description: "Photo upload functionality will be available soon!",
    });
  };
  
  return (
    <div className="space-y-6 pt-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Photo Gallery</h3>
        <Button variant="outline" size="sm" onClick={handleUploadPhotos}>
          <Camera className="h-4 w-4 mr-2" />
          Add Photos
        </Button>
      </div>
      
      {pet.imageUrls && pet.imageUrls.length > 0 ? (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {pet.imageUrls.map((url: string, index: number) => (
            <div key={index} className="relative aspect-square rounded-md overflow-hidden border">
              <img 
                src={url} 
                alt={`${pet.name} photo ${index + 1}`} 
                className="object-cover w-full h-full"
              />
            </div>
          ))}
        </div>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Camera className="h-16 w-16 text-primary/20 mb-4" />
            <h3 className="text-xl font-medium mb-2">No photos yet</h3>
            <p className="text-muted-foreground mb-6 text-center max-w-md">
              Add photos of your pet to keep track of their growth and share their adorable moments.
            </p>
            <Button onClick={handleUploadPhotos}>
              <Camera className="h-4 w-4 mr-2" />
              Upload Photos
            </Button>
          </CardContent>
        </Card>
      )}
      
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Default Photo</CardTitle>
          <CardDescription>This is the main photo used throughout the app</CardDescription>
        </CardHeader>
        <CardContent className="flex justify-center">
          <div className="relative w-48 h-48 rounded-md overflow-hidden border">
            {pet.mainImageUrl ? (
              <img 
                src={pet.mainImageUrl} 
                alt={pet.name} 
                className="w-full h-full object-cover"
              />
            ) : (
              <div className={`w-full h-full ${petTypeColor} flex items-center justify-center`}>
                <span className="text-5xl font-bold text-gray-500">{pet.name.charAt(0)}</span>
              </div>
            )}
          </div>
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button variant="outline" onClick={handleUploadPhotos}>
            Change Default Photo
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}