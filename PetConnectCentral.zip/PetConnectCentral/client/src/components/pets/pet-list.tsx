import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Pet } from "@shared/schema";
import { 
  Loader2, 
  Plus, 
  MoreHorizontal, 
  Edit3, 
  Trash2, 
  Calendar, 
  HeartPulse, 
  Shield 
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export function PetList() {
  const { userProfile } = useAuth();
  const { toast } = useToast();
  const [, navigate] = useLocation();

  // Fetch user's pets from the real API
  const { data: pets, isLoading, error } = useQuery<PetWithShelterInfo[]>({
    queryKey: ['/api/pets'],
    enabled: !!userProfile,
    queryFn: async () => {
      return await (await apiRequest("GET", "/api/pets")).json();
    }
  });

  // Delete pet mutation using the real API
  const deleteMutation = useMutation({
    mutationFn: async (petId: number) => {
      await apiRequest("DELETE", `/api/pets/${petId}`);
    },
    onSuccess: () => {
      toast({
        title: "Pet deleted",
        description: "The pet has been successfully removed from your profile.",
      });
      // Invalidate the pets query to refresh the list
      queryClient.invalidateQueries({ queryKey: ['/api/pets'] });
    },
    onError: (error) => {
      console.error("Error deleting pet:", error);
      toast({
        title: "Error",
        description: "Failed to delete pet. Please try again.",
        variant: "destructive",
      });
    }
  });

  const handleDeletePet = async (petId: number) => {
    try {
      deleteMutation.mutate(petId);
    } catch (error) {
      console.error("Error deleting pet:", error);
      toast({
        title: "Error",
        description: "Failed to delete pet. Please try again.",
        variant: "destructive",
      });
    }
  };

  const confirmDelete = (petId: number, petName: string) => {
    if (window.confirm(`Are you sure you want to delete ${petName}? This action cannot be undone.`)) {
      handleDeletePet(petId);
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center py-12">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-500 mb-4">Failed to load your pets</p>
        <Button variant="outline" onClick={() => window.location.reload()}>
          Try Again
        </Button>
      </div>
    );
  }

  if (!pets || pets.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-lg shadow-sm border">
        <div className="max-w-md mx-auto">
          <h3 className="text-xl font-semibold mb-3">No Pets Added Yet</h3>
          <p className="text-muted-foreground mb-6">
            Add your pets to get personalized care recommendations, track health records, and manage appointments.
          </p>
          <Button onClick={() => navigate("/pets/add")}>
            <Plus className="mr-2 h-4 w-4" />
            Add Your First Pet
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Your Pets</h2>
        <Button onClick={() => navigate("/pets/add")}>
          <Plus className="mr-2 h-4 w-4" />
          Add Pet
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {pets.map((pet: PetWithShelterInfo) => (
          <PetCard 
            key={pet.id} 
            pet={pet} 
            onEdit={() => navigate(`/pets/${pet.id}/edit`)}
            onDelete={() => confirmDelete(pet.id, pet.name)}
          />
        ))}
      </div>
    </div>
  );
}

// Define an extended Pet type that includes shelter information and additional optional fields
interface PetWithShelterInfo extends Pet {
  shelterName?: string;
  weight?: string;
}

interface PetCardProps {
  pet: PetWithShelterInfo;
  onEdit: () => void;
  onDelete: () => void;
}

function PetCard({ pet, onEdit, onDelete }: PetCardProps) {
  const [activeTab, setActiveTab] = useState("overview");

  // Create a placeholder image with the pet's initial
  const placeholderBgColors = {
    dog: "bg-blue-100",
    cat: "bg-green-100",
    bird: "bg-yellow-100",
    rabbit: "bg-purple-100",
    fish: "bg-cyan-100",
    hamster: "bg-pink-100",
    reptile: "bg-amber-100",
    other: "bg-gray-100"
  };

  const petTypeColor = placeholderBgColors[pet.type as keyof typeof placeholderBgColors] || "bg-gray-100";

  return (
    <Card className="overflow-hidden">
      <div className="relative">
        {pet.mainImageUrl ? (
          <img 
            src={pet.mainImageUrl} 
            alt={pet.name} 
            className="w-full h-48 object-cover"
          />
        ) : (
          <div className={`w-full h-48 ${petTypeColor} flex items-center justify-center`}>
            <span className="text-4xl font-bold text-gray-500">{pet.name.charAt(0)}</span>
          </div>
        )}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button 
              variant="ghost" 
              size="icon" 
              className="absolute top-2 right-2 bg-white/80 hover:bg-white"
            >
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={onEdit}>
              <Edit3 className="mr-2 h-4 w-4" />
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem 
              onClick={onDelete}
              className="text-red-500 focus:text-red-500"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-xl">{pet.name}</CardTitle>
          <Badge variant="outline" className="capitalize">
            {pet.type}
          </Badge>
        </div>
        <CardDescription>
          {pet.breed}, {pet.age} {pet.age === 1 ? 'year' : 'years'} old
        </CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="w-full grid grid-cols-3">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="health">Health</TabsTrigger>
            <TabsTrigger value="care">Care</TabsTrigger>
          </TabsList>
          <div className="p-4">
            <TabsContent value="overview" className="m-0">
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <div className="text-sm">
                    <span className="text-muted-foreground">Gender:</span>{" "}
                    <span className="capitalize">{pet.gender}</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-muted-foreground">Size:</span>{" "}
                    <span className="capitalize">{pet.size}</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-muted-foreground">Color:</span>{" "}
                    <span>{pet.color}</span>
                  </div>
                  <div className="text-sm">
                    <span className="text-muted-foreground">Weight:</span>{" "}
                    <span>{pet.weight || "Not specified"}</span>
                  </div>
                </div>
                <Button variant="link" size="sm" className="px-0" asChild>
                  <Link href={`/pets/${pet.id}`}>View Full Profile</Link>
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="health" className="m-0">
              <div className="space-y-3">
                <div className="flex items-center text-sm">
                  <HeartPulse className="h-4 w-4 mr-2 text-primary" />
                  <div>
                    <span className="text-muted-foreground">Vaccinated:</span>{" "}
                    <span>{pet.isVaccinated ? "Yes" : "No"}</span>
                  </div>
                </div>
                <div className="flex items-center text-sm">
                  <HeartPulse className="h-4 w-4 mr-2 text-primary" />
                  <div>
                    <span className="text-muted-foreground">Health Status:</span>{" "}
                    <span>{pet.healthStatus}</span>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="w-full" asChild>
                  <Link href={`/pets/${pet.id}/health`}>Manage Health Records</Link>
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="care" className="m-0">
              <div className="space-y-3">
                <div className="flex items-center text-sm">
                  <Shield className="h-4 w-4 mr-2 text-primary" />
                  <div>
                    <span className="text-muted-foreground">Activity Level:</span>{" "}
                    <span>{pet.activityLevel || "Not specified"}</span>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="w-full" asChild>
                  <Link href={`/pets/${pet.id}/care`}>View Care Recommendations</Link>
                </Button>
              </div>
            </TabsContent>
          </div>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-between pt-4">
        <Button variant="outline" size="sm" asChild>
          <Link href={`/services/book?petId=${pet.id}`}>Book Service</Link>
        </Button>
        <Button variant="outline" size="sm" asChild>
          <Link href={`/appointments?petId=${pet.id}`}>View Appointments</Link>
        </Button>
      </CardFooter>
    </Card>
  );
}

export default PetList;