import { storage } from './server/storage';
import { UserType } from './shared/schema';
import { scrypt, randomBytes } from 'crypto';
import { promisify } from 'util';

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString('hex');
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString('hex')}.${salt}`;
}

async function createTestUsers() {
  console.log('Creating test users...');
  
  try {
    // 1. Create a Pet Owner User
    const petOwnerUser = await storage.createUser({
      username: "pet_owner",
      password: await hashPassword("password123"),
      email: "petowner@example.com",
      name: "Pet Owner User",
      userType: UserType.PET_OWNER,
      location: "New York, NY",
      firebaseUid: "test-firebase-uid-petowner"
    });
    
    console.log('Created pet owner user:', petOwnerUser.id);
    
    // Create pet owner profile
    const petOwner = await storage.createPetOwner({
      userId: petOwnerUser.id,
      bio: "I love pets and am looking to adopt a friendly companion."
    });
    
    console.log('Created pet owner profile:', petOwner.id);
    
    // 2. Create a Service Provider User
    const serviceProviderUser = await storage.createUser({
      username: "service_provider",
      password: await hashPassword("password123"),
      email: "serviceprovider@example.com",
      name: "Service Provider User",
      userType: UserType.SERVICE_PROVIDER,
      location: "Boston, MA",
      firebaseUid: "test-firebase-uid-provider"
    });
    
    console.log('Created service provider user:', serviceProviderUser.id);
    
    // Create service provider profile
    const serviceProvider = await storage.createServiceProvider({
      userId: serviceProviderUser.id,
      businessName: "Happy Paws Grooming",
      category: "grooming",
      description: "Professional pet grooming services with 10+ years of experience.",
      phone: "555-123-4567",
      address: "123 Main St, Boston, MA",
      website: "happypawsgrooming.com"
    });
    
    console.log('Created service provider profile:', serviceProvider.id);
    
    // Add some services for this provider
    await storage.createService({
      providerId: serviceProvider.id,
      title: "Basic Grooming Package",
      description: "Bath, brush, nail trim, and ear cleaning for your pet.",
      price: "$50",
      duration: "60 min",
      category: "grooming",
      availability: "Mon-Fri, 9am-5pm"
    });
    
    // 3. Create a Shelter User
    const shelterUser = await storage.createUser({
      username: "shelter",
      password: await hashPassword("password123"),
      email: "shelter@example.com",
      name: "Animal Rescue Shelter",
      userType: UserType.SHELTER,
      location: "Chicago, IL",
      firebaseUid: "test-firebase-uid-shelter"
    });
    
    console.log('Created shelter user:', shelterUser.id);
    
    // Create shelter profile
    const shelter = await storage.createShelter({
      userId: shelterUser.id,
      organizationName: "Second Chance Animal Rescue",
      mission: "Finding loving homes for animals in need.",
      phone: "555-987-6543",
      address: "456 Oak Ave, Chicago, IL",
      website: "secondchancerescue.org"
    });
    
    console.log('Created shelter profile:', shelter.id);
    
    // Add some pets for this shelter
    await storage.createPet({
      shelterId: shelter.id,
      name: "Max",
      type: "Dog",
      breed: "Labrador Mix",
      age: 3,
      gender: "Male",
      size: "Large",
      color: "Black",
      description: "Max is a friendly and energetic lab mix who loves going for walks and playing fetch.",
      healthStatus: "Excellent",
      isVaccinated: true,
      isNeutered: true,
      isHouseTrained: true,
      goodWithKids: true,
      goodWithDogs: true,
      goodWithCats: false,
      adoptionStatus: "available",
      adoptionFee: "$150",
      mainImageUrl: "https://images.unsplash.com/photo-1543466835-00a7907e9de1?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
    });
    
    await storage.createPet({
      shelterId: shelter.id,
      name: "Whiskers",
      type: "Cat",
      breed: "Domestic Shorthair",
      age: 2,
      gender: "Female",
      size: "Medium",
      color: "Tabby",
      description: "Whiskers is a sweet cat who loves to curl up in laps and purr. She's playful but not too demanding.",
      healthStatus: "Good",
      isVaccinated: true,
      isNeutered: true,
      isHouseTrained: true,
      goodWithKids: true,
      goodWithDogs: false,
      goodWithCats: true,
      adoptionStatus: "available",
      adoptionFee: "$100",
      mainImageUrl: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80"
    });
    
    console.log('Created test pets for shelter');
    
    console.log('All test users and profiles created successfully!');
    
    // Return login details for each user
    return {
      petOwner: {
        username: "pet_owner",
        password: "password123",
        email: "petowner@example.com",
        firebaseUid: "test-firebase-uid-petowner"
      },
      serviceProvider: {
        username: "service_provider",
        password: "password123",
        email: "serviceprovider@example.com",
        firebaseUid: "test-firebase-uid-provider"
      },
      shelter: {
        username: "shelter",
        password: "password123",
        email: "shelter@example.com",
        firebaseUid: "test-firebase-uid-shelter"
      }
    };
    
  } catch (error) {
    console.error('Error creating test users:', error);
    throw error;
  }
}

createTestUsers()
  .then(users => {
    console.log('\n---------------------------------------');
    console.log('TEST USER LOGIN CREDENTIALS:');
    console.log('---------------------------------------');
    console.log('Pet Owner:');
    console.log(`  Username: ${users.petOwner.username}`);
    console.log(`  Password: ${users.petOwner.password}`);
    console.log(`  Email: ${users.petOwner.email}`);
    console.log(`  Firebase UID: ${users.petOwner.firebaseUid}`);
    console.log('---------------------------------------');
    console.log('Service Provider:');
    console.log(`  Username: ${users.serviceProvider.username}`);
    console.log(`  Password: ${users.serviceProvider.password}`);
    console.log(`  Email: ${users.serviceProvider.email}`);
    console.log(`  Firebase UID: ${users.serviceProvider.firebaseUid}`);
    console.log('---------------------------------------');
    console.log('Shelter:');
    console.log(`  Username: ${users.shelter.username}`);
    console.log(`  Password: ${users.shelter.password}`);
    console.log(`  Email: ${users.shelter.email}`);
    console.log(`  Firebase UID: ${users.shelter.firebaseUid}`);
    console.log('---------------------------------------');
    console.log('\nTo simulate login with these users in the API, use their respective Firebase UIDs in the Authorization header as Bearer tokens.');
    process.exit(0);
  })
  .catch(error => {
    console.error('Failed to create test users:', error);
    process.exit(1);
  });