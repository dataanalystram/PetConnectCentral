import { storage } from "./server/storage";

async function main() {
    try {
        // Initialize resources
        await storage.initializeResources();
        console.log("Resources initialized successfully");
    } catch (error) {
        console.error("Error initializing resources:", error);
    }
}

main();