import { pgTable, text, serial, integer, boolean, timestamp, json, date, decimal } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User types
export enum UserType {
  PET_OWNER = "pet_owner",
  SERVICE_PROVIDER = "service_provider",
  SHELTER = "shelter"
}

// Base user table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  firebaseUid: text("firebase_uid").unique(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  userType: text("user_type").notNull().$type<UserType>(),
  location: text("location"),
  isActive: boolean("is_active").notNull().default(true),
  // isDeleted column was defined but not migrated to the database
  // isDeleted: boolean("is_deleted").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Pet owners additional info
export const petOwners = pgTable("pet_owners", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  bio: text("bio"),
  preferences: json("preferences")
});

// Service providers additional info
export const serviceProviders = pgTable("service_providers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  businessName: text("business_name").notNull(),
  category: text("category").notNull(),
  description: text("description"),
  address: text("address"),
  phone: text("phone"),
  rating: integer("rating"),
  priceRange: text("price_range"),
});

// Shelters additional info
export const shelters = pgTable("shelters", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  organizationName: text("organization_name").notNull(),
  mission: text("mission"),
  address: text("address"),
  phone: text("phone"),
});

// Pets table
export const pets = pgTable("pets", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // dog, cat, bird, etc.
  breed: text("breed").notNull(),
  age: integer("age").notNull(),
  gender: text("gender").notNull(),
  size: text("size").notNull(), // small, medium, large
  description: text("description").notNull(),
  healthStatus: text("health_status").notNull(),
  isVaccinated: boolean("is_vaccinated").notNull().default(false),
  isNeutered: boolean("is_neutered").notNull().default(false),
  isAdopted: boolean("is_adopted").notNull().default(false),
  isFeatured: boolean("is_featured").notNull().default(false),
  personality: text("personality").array(),
  goodWith: text("good_with").array(), // children, other pets, etc
  activityLevel: text("activity_level"), // low, medium, high
  color: text("color").notNull(),
  adoptionFee: integer("adoption_fee"),
  imageUrls: text("image_urls").array(),
  mainImageUrl: text("main_image_url"),
  ownerId: integer("owner_id").references(() => users.id),
  shelterId: integer("shelter_id").references(() => shelters.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Services table
export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  price: text("price"),
  duration: text("duration"),
  providerId: integer("provider_id").references(() => serviceProviders.id),
  category: text("category").notNull(),
  available: boolean("available").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Resources table
export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  category: text("category").notNull(),
  author: text("author"),
  readTime: integer("read_time"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Favorites table for pet owners to save pets they like
export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  petOwnerId: integer("pet_owner_id").notNull().references(() => petOwners.id),
  petId: integer("pet_id").notNull().references(() => pets.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Appointments table for adoption visits or service bookings
export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  status: text("status").notNull().default("pending"), // pending, confirmed, completed, cancelled
  userId: integer("user_id").notNull().references(() => users.id), // The user who created the appointment
  petId: integer("pet_id").references(() => pets.id), // Optional - if appointment is for a specific pet
  serviceId: integer("service_id").references(() => services.id), // Optional - if appointment is for a service
  providerId: integer("provider_id").references(() => serviceProviders.id), // Optional - service provider
  shelterId: integer("shelter_id").references(() => shelters.id), // Optional - shelter
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Health Records table for tracking pet health history
export const petHealthRecords = pgTable("pet_health_records", {
  id: serial("id").primaryKey(),
  petId: integer("pet_id").notNull().references(() => pets.id),
  recordDate: date("record_date").notNull(),
  recordType: text("record_type").notNull(), // vet_visit, vaccination, medication, surgery, etc.
  title: text("title").notNull(),
  description: text("description"),
  veterinarianName: text("veterinarian_name"),
  clinicName: text("clinic_name"),
  diagnosis: text("diagnosis"),
  treatment: text("treatment"),
  notes: text("notes"),
  followUpDate: date("follow_up_date"),
  documentUrls: text("document_urls").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Vaccinations table for detailed tracking of pet vaccinations
export const petVaccinations = pgTable("pet_vaccinations", {
  id: serial("id").primaryKey(),
  petId: integer("pet_id").notNull().references(() => pets.id),
  healthRecordId: integer("health_record_id").references(() => petHealthRecords.id),
  vaccineName: text("vaccine_name").notNull(),
  vaccineType: text("vaccine_type"), // core, non-core
  administeredDate: date("administered_date").notNull(),
  expirationDate: date("expiration_date"),
  dueDate: date("due_date"), // For next vaccination due date
  batchNumber: text("batch_number"),
  manufacturer: text("manufacturer"),
  administeredBy: text("administered_by"),
  location: text("location"), // clinic name, etc.
  notes: text("notes"),
  documentUrl: text("document_url"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Medications table for tracking pet medications
export const petMedications = pgTable("pet_medications", {
  id: serial("id").primaryKey(),
  petId: integer("pet_id").notNull().references(() => pets.id),
  healthRecordId: integer("health_record_id").references(() => petHealthRecords.id),
  medicationName: text("medication_name").notNull(),
  dosage: text("dosage").notNull(),
  frequency: text("frequency").notNull(), // once daily, twice daily, etc.
  startDate: date("start_date").notNull(),
  endDate: date("end_date"),
  prescribedBy: text("prescribed_by"),
  condition: text("condition"), // what condition is being treated
  instructions: text("instructions"),
  sideEffects: text("side_effects"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Weight history table for tracking pet weight over time
export const petWeightHistory = pgTable("pet_weight_history", {
  id: serial("id").primaryKey(),
  petId: integer("pet_id").notNull().references(() => pets.id),
  recordDate: date("record_date").notNull(),
  weight: decimal("weight").notNull(), // in pounds or kilograms
  notes: text("notes"),
  recordedBy: text("recorded_by"), // vet, owner
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Pet health metrics table for more detailed health tracking
export const petHealthMetrics = pgTable("pet_health_metrics", {
  id: serial("id").primaryKey(),
  petId: integer("pet_id").notNull().references(() => pets.id),
  healthRecordId: integer("health_record_id").references(() => petHealthRecords.id),
  metricType: text("metric_type").notNull(), // temperature, heart_rate, blood_pressure, etc.
  metricValue: decimal("metric_value").notNull(),
  unit: text("unit").notNull(), // kg, cm, bpm, etc.
  recordDate: date("record_date").notNull(),
  recordTime: text("record_time"), // Time in 24-hour format (HH:MM)
  notes: text("notes"),
  createdBy: integer("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  isDeleted: boolean("is_deleted").default(false),
});

// User notifications table
export const userNotifications = pgTable("user_notifications", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  message: text("message").notNull(),
  type: text("type").notNull(), // system, booking, pet_care, promotion, etc.
  isRead: boolean("is_read").default(false),
  actionUrl: text("action_url"), // URL to navigate to when clicked
  createdAt: timestamp("created_at").defaultNow().notNull(),
  expiresAt: timestamp("expires_at"), // When notification should expire/be auto-deleted
});

// Pet care reminders table
export const petCareReminders = pgTable("pet_care_reminders", {
  id: serial("id").primaryKey(),
  petId: integer("pet_id").notNull().references(() => pets.id),
  userId: integer("user_id").notNull().references(() => users.id),
  title: text("title").notNull(),
  description: text("description"),
  reminderType: text("reminder_type").notNull(), // medication, feeding, exercise, grooming, vet_visit, etc.
  startDate: date("start_date").notNull(),
  endDate: date("end_date"), // Optional for one-time reminders
  frequency: text("frequency").notNull(), // daily, weekly, monthly, once, etc.
  timeOfDay: text("time_of_day"), // morning, afternoon, evening, or specific time
  isActive: boolean("is_active").default(true),
  isCompleted: boolean("is_completed").default(false), // For one-time reminders
  lastTriggered: timestamp("last_triggered"), // Last time notification was sent
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// User consent tracking table
export const userConsents = pgTable("user_consents", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  consentType: text("consent_type").notNull(), // marketing, location_data, data_sharing, etc.
  isGranted: boolean("is_granted").notNull(),
  consentVersion: text("consent_version").notNull(), // Version of the consent text agreed to
  ipAddress: text("ip_address"), // IP address when consent was given/modified
  userAgent: text("user_agent"), // User agent when consent was given/modified
  grantedAt: timestamp("granted_at").defaultNow().notNull(),
});

// Notification preferences table
export const notificationPreferences = pgTable("notification_preferences", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  notificationType: text("notification_type").notNull(), // reminders, bookings, system, marketing, etc.
  viaApp: boolean("via_app").default(true),
  viaEmail: boolean("via_email").default(true),
  viaSms: boolean("via_sms").default(false),
  viaPush: boolean("via_push").default(true),
  quietHoursStart: text("quiet_hours_start"), // Time in 24-hour format (HH:MM)
  quietHoursEnd: text("quiet_hours_end"), // Time in 24-hour format (HH:MM)
  isPaused: boolean("is_paused").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Reminder notifications table
export const reminderNotifications = pgTable("reminder_notifications", {
  id: serial("id").primaryKey(),
  reminderId: integer("reminder_id").notNull().references(() => petCareReminders.id),
  userId: integer("user_id").notNull().references(() => users.id),
  scheduledAt: timestamp("scheduled_at").notNull(),
  sentAt: timestamp("sent_at"),
  deliveryChannel: text("delivery_channel").notNull(), // app, email, sms, push
  status: text("status").default("pending"), // pending, sent, failed, cancelled
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Document storage table for pet-related documents
export const petDocuments = pgTable("pet_documents", {
  id: serial("id").primaryKey(),
  petId: integer("pet_id").notNull().references(() => pets.id),
  healthRecordId: integer("health_record_id").references(() => petHealthRecords.id),
  documentType: text("document_type").notNull(), // vaccination_certificate, medical_report, insurance, etc.
  title: text("title").notNull(),
  description: text("description"),
  fileUrl: text("file_url").notNull(),
  fileType: text("file_type"), // pdf, jpg, png, etc.
  fileSize: integer("file_size"), // in bytes
  uploadedBy: integer("uploaded_by").references(() => users.id),
  isVerified: boolean("is_verified").default(false), // If document has been verified by admin/vet
  verifiedBy: text("verified_by"), // Who verified the document
  verificationDate: timestamp("verification_date"), // When document was verified
  expiryDate: date("expiry_date"), // When document expires (if applicable)
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Pet behavior tracking table to record behavioral issues, training progress, etc.
export const petBehaviorRecords = pgTable("pet_behavior_records", {
  id: serial("id").primaryKey(),
  petId: integer("pet_id").notNull().references(() => pets.id),
  recordDate: date("record_date").notNull(),
  behaviorType: text("behavior_type").notNull(), // aggression, anxiety, training progress, etc.
  description: text("description").notNull(),
  triggerFactors: text("trigger_factors"),
  intervention: text("intervention"),
  trainerName: text("trainer_name"),
  progressStatus: text("progress_status"), // improved, unchanged, worsened
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  isDeleted: boolean("is_deleted").default(false),
});

// Provider settings table for storing provider-specific configuration
export const providerSettings = pgTable("provider_settings", {
  id: serial("id").primaryKey(),
  providerId: integer("provider_id").notNull().references(() => serviceProviders.id),
  settingCategory: text("setting_category").notNull(), // notifications, bookings, payments, etc.
  settingName: text("setting_name").notNull(),
  settingValue: json("setting_value").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Compliance checks table for regulatory compliance tracking
export const complianceChecks = pgTable("compliance_checks", {
  id: serial("id").primaryKey(),
  providerId: integer("provider_id").notNull().references(() => serviceProviders.id),
  checkType: text("check_type").notNull(), // document_verification, data_protection, etc.
  status: text("status").notNull(), // passed, failed, pending
  checkedAt: timestamp("checked_at").defaultNow().notNull(),
  checkedBy: integer("checked_by"), // Optional reference to admin user
  notes: text("notes"),
  nextCheckDate: date("next_check_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  isDeleted: boolean("is_deleted").default(false),
});

// Regulatory updates for tracking changes in regulations
export const regulatoryUpdates = pgTable("regulatory_updates", {
  id: serial("id").primaryKey(),
  country: text("country").notNull(),
  regulationName: text("regulation_name").notNull(),
  description: text("description").notNull(),
  effectiveDate: date("effective_date").notNull(),
  category: text("category").notNull(), // animal_welfare, data_protection, business, etc.
  affectedProviderTypes: json("affected_provider_types"), // Array of provider types affected
  detailsUrl: text("details_url"),
  actionsRequired: text("actions_required"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  isActive: boolean("is_active").default(true),
});

// Provider acknowledgements of regulatory updates
export const providerRegulatoryAcknowledgements = pgTable("provider_regulatory_acknowledgements", {
  id: serial("id").primaryKey(),
  providerId: integer("provider_id").notNull().references(() => serviceProviders.id),
  updateId: integer("update_id").notNull().references(() => regulatoryUpdates.id),
  acknowledgedBy: integer("acknowledged_by").references(() => users.id),
  acknowledgedAt: timestamp("acknowledged_at").defaultNow().notNull(),
  implementationStatus: text("implementation_status").default("pending"), // pending, in_progress, completed
  implementationNotes: text("implementation_notes"),
  implementationDate: date("implementation_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Provider data processing records for GDPR compliance
export const providerDataProcessingRecords = pgTable("provider_data_processing_records", {
  id: serial("id").primaryKey(),
  providerId: integer("provider_id").notNull().references(() => serviceProviders.id),
  processingPurpose: text("processing_purpose").notNull(),
  dataCategories: text("data_categories").notNull(), // What types of data are processed
  recipientCategories: text("recipient_categories"), // Who data is shared with
  retentionPeriod: text("retention_period"), // How long data is kept
  securityMeasures: text("security_measures"), // What security measures are in place
  lawfulBasis: text("lawful_basis").notNull(), // legal_obligation, contract, consent, etc.
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  isDeleted: boolean("is_deleted").default(false),
});

// Service bookings connection table
export const serviceBookings = pgTable("service_bookings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id), // Pet Owner
  providerId: integer("provider_id").references(() => serviceProviders.id), // Service Provider
  serviceId: integer("service_id").references(() => services.id),
  petId: integer("pet_id").references(() => pets.id), // Pet Owner's pet
  bookingDate: timestamp("booking_date").notNull(),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  status: text("status").notNull().default("pending"), // pending, confirmed, completed, cancelled
  notes: text("notes"),
  totalPrice: decimal("total_price"),
  paymentStatus: text("payment_status").default("unpaid"), // unpaid, paid, refunded
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Service reviews table
export const serviceReviews = pgTable("service_reviews", {
  id: serial("id").primaryKey(),
  bookingId: integer("booking_id").references(() => serviceBookings.id),
  userId: integer("user_id").references(() => users.id), // Pet Owner
  providerId: integer("provider_id").references(() => serviceProviders.id), // Service Provider
  rating: integer("rating").notNull(),
  review: text("review"),
  responseText: text("response_text"),
  responseDate: timestamp("response_date"),
  isPublic: boolean("is_public").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Insert schemas
// Note: isDeleted is commented in the schema but we still need to omit it from the insert schema
export const insertUserSchema = createInsertSchema(users).omit({ id: true, createdAt: true, isDeleted: true });
export const insertPetOwnerSchema = createInsertSchema(petOwners).omit({ id: true });
export const insertServiceProviderSchema = createInsertSchema(serviceProviders).omit({ id: true });
export const insertShelterSchema = createInsertSchema(shelters).omit({ id: true });
export const insertPetSchema = createInsertSchema(pets).omit({ id: true, createdAt: true });
export const insertServiceSchema = createInsertSchema(services).omit({ id: true, createdAt: true });
export const insertResourceSchema = createInsertSchema(resources).omit({ id: true, createdAt: true });
export const insertFavoriteSchema = createInsertSchema(favorites).omit({ id: true, createdAt: true });
export const insertAppointmentSchema = createInsertSchema(appointments).omit({ id: true, createdAt: true });
export const insertPetHealthRecordSchema = createInsertSchema(petHealthRecords).omit({ id: true, createdAt: true, updatedAt: true });
export const insertPetVaccinationSchema = createInsertSchema(petVaccinations).omit({ id: true, createdAt: true });
export const insertPetMedicationSchema = createInsertSchema(petMedications).omit({ id: true, createdAt: true });
export const insertPetWeightHistorySchema = createInsertSchema(petWeightHistory).omit({ id: true, createdAt: true });
export const insertPetHealthMetricsSchema = createInsertSchema(petHealthMetrics).omit({ id: true, createdAt: true, updatedAt: true, isDeleted: true });
export const insertUserNotificationSchema = createInsertSchema(userNotifications).omit({ id: true, createdAt: true });
export const insertPetCareReminderSchema = createInsertSchema(petCareReminders).omit({ id: true, createdAt: true });
export const insertUserConsentSchema = createInsertSchema(userConsents).omit({ id: true, grantedAt: true });
export const insertPetDocumentSchema = createInsertSchema(petDocuments).omit({ id: true, createdAt: true });
export const insertPetBehaviorRecordSchema = createInsertSchema(petBehaviorRecords).omit({ id: true, createdAt: true, updatedAt: true, isDeleted: true });
export const insertNotificationPreferenceSchema = createInsertSchema(notificationPreferences).omit({ id: true, createdAt: true, updatedAt: true });
export const insertReminderNotificationSchema = createInsertSchema(reminderNotifications).omit({ id: true, createdAt: true, updatedAt: true });

// Service provider specific schemas
export const insertProviderSettingsSchema = createInsertSchema(providerSettings).omit({ id: true, createdAt: true, updatedAt: true });
export const insertComplianceCheckSchema = createInsertSchema(complianceChecks).omit({ id: true, createdAt: true, updatedAt: true, checkedAt: true, isDeleted: true });
export const insertRegulatoryUpdateSchema = createInsertSchema(regulatoryUpdates).omit({ id: true, createdAt: true, updatedAt: true });
export const insertProviderRegulatoryAcknowledgementSchema = createInsertSchema(providerRegulatoryAcknowledgements).omit({ id: true, createdAt: true, updatedAt: true, acknowledgedAt: true });
export const insertProviderDataProcessingRecordSchema = createInsertSchema(providerDataProcessingRecords).omit({ id: true, createdAt: true, updatedAt: true, isDeleted: true });
export const insertServiceBookingSchema = createInsertSchema(serviceBookings).omit({ id: true, createdAt: true, updatedAt: true });
export const insertServiceReviewSchema = createInsertSchema(serviceReviews).omit({ id: true, createdAt: true, updatedAt: true });

// Type definitions
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type PetOwner = typeof petOwners.$inferSelect;
export type InsertPetOwner = z.infer<typeof insertPetOwnerSchema>;

export type ServiceProvider = typeof serviceProviders.$inferSelect;
export type InsertServiceProvider = z.infer<typeof insertServiceProviderSchema>;

export type Shelter = typeof shelters.$inferSelect;
export type InsertShelter = z.infer<typeof insertShelterSchema>;

export type Pet = typeof pets.$inferSelect;
export type InsertPet = z.infer<typeof insertPetSchema>;

export type Service = typeof services.$inferSelect;
export type InsertService = z.infer<typeof insertServiceSchema>;

export type Resource = typeof resources.$inferSelect;
export type InsertResource = z.infer<typeof insertResourceSchema>;

export type Favorite = typeof favorites.$inferSelect;
export type InsertFavorite = z.infer<typeof insertFavoriteSchema>;

export type Appointment = typeof appointments.$inferSelect;
export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;

export type PetHealthRecord = typeof petHealthRecords.$inferSelect;
export type InsertPetHealthRecord = z.infer<typeof insertPetHealthRecordSchema>;

export type PetVaccination = typeof petVaccinations.$inferSelect;
export type InsertPetVaccination = z.infer<typeof insertPetVaccinationSchema>;

export type PetMedication = typeof petMedications.$inferSelect;
export type InsertPetMedication = z.infer<typeof insertPetMedicationSchema>;

export type PetWeightHistory = typeof petWeightHistory.$inferSelect;
export type InsertPetWeightHistory = z.infer<typeof insertPetWeightHistorySchema>;

export type PetHealthMetric = typeof petHealthMetrics.$inferSelect;
export type InsertPetHealthMetric = z.infer<typeof insertPetHealthMetricsSchema>;

export type UserNotification = typeof userNotifications.$inferSelect;
export type InsertUserNotification = z.infer<typeof insertUserNotificationSchema>;

export type PetCareReminder = typeof petCareReminders.$inferSelect;
export type InsertPetCareReminder = z.infer<typeof insertPetCareReminderSchema>;

export type UserConsent = typeof userConsents.$inferSelect;
export type InsertUserConsent = z.infer<typeof insertUserConsentSchema>;

export type PetDocument = typeof petDocuments.$inferSelect;
export type InsertPetDocument = z.infer<typeof insertPetDocumentSchema>;

export type PetBehaviorRecord = typeof petBehaviorRecords.$inferSelect;
export type InsertPetBehaviorRecord = z.infer<typeof insertPetBehaviorRecordSchema>;

export type NotificationPreference = typeof notificationPreferences.$inferSelect;
export type InsertNotificationPreference = z.infer<typeof insertNotificationPreferenceSchema>;

export type ReminderNotification = typeof reminderNotifications.$inferSelect;
export type InsertReminderNotification = z.infer<typeof insertReminderNotificationSchema>;

// Service provider specific types
export type ProviderSetting = typeof providerSettings.$inferSelect;
export type InsertProviderSetting = z.infer<typeof insertProviderSettingsSchema>;

export type ComplianceCheck = typeof complianceChecks.$inferSelect;
export type InsertComplianceCheck = z.infer<typeof insertComplianceCheckSchema>;

export type RegulatoryUpdate = typeof regulatoryUpdates.$inferSelect;
export type InsertRegulatoryUpdate = z.infer<typeof insertRegulatoryUpdateSchema>;

export type ProviderRegulatoryAcknowledgement = typeof providerRegulatoryAcknowledgements.$inferSelect;
export type InsertProviderRegulatoryAcknowledgement = z.infer<typeof insertProviderRegulatoryAcknowledgementSchema>;

export type ProviderDataProcessingRecord = typeof providerDataProcessingRecords.$inferSelect;
export type InsertProviderDataProcessingRecord = z.infer<typeof insertProviderDataProcessingRecordSchema>;

export type ServiceBooking = typeof serviceBookings.$inferSelect;
export type InsertServiceBooking = z.infer<typeof insertServiceBookingSchema>;

export type ServiceReview = typeof serviceReviews.$inferSelect;
export type InsertServiceReview = z.infer<typeof insertServiceReviewSchema>;

// Extended registration schema for frontend
export const registerSchema = insertUserSchema.extend({
  confirmPassword: z.string(),
  // Additional fields based on user type
  businessName: z.string().optional(),
  category: z.string().optional(),
  organizationName: z.string().optional(),
  mission: z.string().optional(),
}).refine(data => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

export type RegisterData = z.infer<typeof registerSchema>;

// Login schema
export const loginSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export type LoginData = z.infer<typeof loginSchema>;
